﻿namespace ERP
{


    partial class mainDataSet
    {
    }
}

namespace ERP.mainDataSetTableAdapters {
    
    
    public partial class tblExpenseTableAdapter {
    }
}
