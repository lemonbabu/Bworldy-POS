﻿
namespace ERP
{
    partial class frmAddNewProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAddNewProduct));
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties13 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties14 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties15 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties16 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            this.tblLyPnlMain = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnClear = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnAddNewProduct = new Bunifu.Framework.UI.BunifuThinButton2();
            this.txtProductDetails = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.txtProductSize = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.txtProductCtg = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.txtProductName = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.lblTitle = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.tblLyPnlMain.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tblLyPnlMain
            // 
            this.tblLyPnlMain.ColumnCount = 1;
            this.tblLyPnlMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblLyPnlMain.Controls.Add(this.panel1, 0, 1);
            this.tblLyPnlMain.Controls.Add(this.lblTitle, 0, 0);
            this.tblLyPnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblLyPnlMain.ForeColor = System.Drawing.Color.Black;
            this.tblLyPnlMain.Location = new System.Drawing.Point(0, 0);
            this.tblLyPnlMain.Name = "tblLyPnlMain";
            this.tblLyPnlMain.RowCount = 2;
            this.tblLyPnlMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tblLyPnlMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 85F));
            this.tblLyPnlMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblLyPnlMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblLyPnlMain.Size = new System.Drawing.Size(550, 450);
            this.tblLyPnlMain.TabIndex = 10;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.btnClear);
            this.panel1.Controls.Add(this.btnAddNewProduct);
            this.panel1.Controls.Add(this.txtProductDetails);
            this.panel1.Controls.Add(this.txtProductSize);
            this.panel1.Controls.Add(this.txtProductCtg);
            this.panel1.Controls.Add(this.txtProductName);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 70);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(544, 377);
            this.panel1.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(18)))), ((int)(((byte)(18)))));
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(66, 204);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(158, 30);
            this.label4.TabIndex = 10;
            this.label4.Text = "DESCRIPTION :";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(18)))), ((int)(((byte)(18)))));
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(158, 148);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 30);
            this.label3.TabIndex = 9;
            this.label3.Text = "SIZE :";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(18)))), ((int)(((byte)(18)))));
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(35, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(189, 30);
            this.label2.TabIndex = 8;
            this.label2.Text = "PRODUCT NAME :";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(18)))), ((int)(((byte)(18)))));
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(89, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(135, 30);
            this.label1.TabIndex = 7;
            this.label1.Text = "CATEGORIE :";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnClear
            // 
            this.btnClear.ActiveBorderThickness = 1;
            this.btnClear.ActiveCornerRadius = 1;
            this.btnClear.ActiveFillColor = System.Drawing.Color.Red;
            this.btnClear.ActiveForecolor = System.Drawing.Color.White;
            this.btnClear.ActiveLineColor = System.Drawing.Color.Red;
            this.btnClear.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnClear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnClear.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnClear.BackgroundImage")));
            this.btnClear.ButtonText = "CLEAR";
            this.btnClear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClear.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.ForeColor = System.Drawing.Color.Red;
            this.btnClear.IdleBorderThickness = 1;
            this.btnClear.IdleCornerRadius = 1;
            this.btnClear.IdleFillColor = System.Drawing.Color.White;
            this.btnClear.IdleForecolor = System.Drawing.Color.DodgerBlue;
            this.btnClear.IdleLineColor = System.Drawing.Color.DodgerBlue;
            this.btnClear.Location = new System.Drawing.Point(163, 281);
            this.btnClear.Margin = new System.Windows.Forms.Padding(1);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(65, 50);
            this.btnClear.TabIndex = 6;
            this.btnClear.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnAddNewProduct
            // 
            this.btnAddNewProduct.ActiveBorderThickness = 1;
            this.btnAddNewProduct.ActiveCornerRadius = 1;
            this.btnAddNewProduct.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnAddNewProduct.ActiveForecolor = System.Drawing.Color.White;
            this.btnAddNewProduct.ActiveLineColor = System.Drawing.Color.DodgerBlue;
            this.btnAddNewProduct.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnAddNewProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnAddNewProduct.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAddNewProduct.BackgroundImage")));
            this.btnAddNewProduct.ButtonText = "ADD PRODUCT";
            this.btnAddNewProduct.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddNewProduct.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddNewProduct.ForeColor = System.Drawing.Color.DodgerBlue;
            this.btnAddNewProduct.IdleBorderThickness = 1;
            this.btnAddNewProduct.IdleCornerRadius = 1;
            this.btnAddNewProduct.IdleFillColor = System.Drawing.Color.White;
            this.btnAddNewProduct.IdleForecolor = System.Drawing.Color.DodgerBlue;
            this.btnAddNewProduct.IdleLineColor = System.Drawing.Color.DodgerBlue;
            this.btnAddNewProduct.Location = new System.Drawing.Point(257, 281);
            this.btnAddNewProduct.Margin = new System.Windows.Forms.Padding(1);
            this.btnAddNewProduct.Name = "btnAddNewProduct";
            this.btnAddNewProduct.Size = new System.Drawing.Size(166, 50);
            this.btnAddNewProduct.TabIndex = 5;
            this.btnAddNewProduct.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAddNewProduct.Click += new System.EventHandler(this.btnAddNewProduct_Click);
            // 
            // txtProductDetails
            // 
            this.txtProductDetails.AcceptsReturn = false;
            this.txtProductDetails.AcceptsTab = false;
            this.txtProductDetails.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtProductDetails.AnimationSpeed = 200;
            this.txtProductDetails.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtProductDetails.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtProductDetails.BackColor = System.Drawing.Color.Transparent;
            this.txtProductDetails.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtProductDetails.BackgroundImage")));
            this.txtProductDetails.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtProductDetails.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.txtProductDetails.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtProductDetails.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtProductDetails.BorderRadius = 1;
            this.txtProductDetails.BorderThickness = 1;
            this.txtProductDetails.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtProductDetails.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtProductDetails.DefaultFont = new System.Drawing.Font("Segoe UI", 10F);
            this.txtProductDetails.DefaultText = "";
            this.txtProductDetails.FillColor = System.Drawing.Color.White;
            this.txtProductDetails.HideSelection = true;
            this.txtProductDetails.IconLeft = null;
            this.txtProductDetails.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtProductDetails.IconPadding = 10;
            this.txtProductDetails.IconRight = null;
            this.txtProductDetails.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtProductDetails.Lines = new string[0];
            this.txtProductDetails.Location = new System.Drawing.Point(257, 200);
            this.txtProductDetails.MaxLength = 32767;
            this.txtProductDetails.MinimumSize = new System.Drawing.Size(100, 35);
            this.txtProductDetails.Modified = false;
            this.txtProductDetails.Multiline = true;
            this.txtProductDetails.Name = "txtProductDetails";
            stateProperties1.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtProductDetails.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.Empty;
            stateProperties2.FillColor = System.Drawing.Color.White;
            stateProperties2.ForeColor = System.Drawing.Color.Empty;
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtProductDetails.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtProductDetails.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.Silver;
            stateProperties4.FillColor = System.Drawing.Color.White;
            stateProperties4.ForeColor = System.Drawing.Color.Empty;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtProductDetails.OnIdleState = stateProperties4;
            this.txtProductDetails.PasswordChar = '\0';
            this.txtProductDetails.PlaceholderForeColor = System.Drawing.Color.DimGray;
            this.txtProductDetails.PlaceholderText = "Imported\r\n100% Coton\r\n\r\n";
            this.txtProductDetails.ReadOnly = false;
            this.txtProductDetails.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtProductDetails.SelectedText = "";
            this.txtProductDetails.SelectionLength = 0;
            this.txtProductDetails.SelectionStart = 0;
            this.txtProductDetails.ShortcutsEnabled = true;
            this.txtProductDetails.Size = new System.Drawing.Size(224, 46);
            this.txtProductDetails.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtProductDetails.TabIndex = 3;
            this.txtProductDetails.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtProductDetails.TextMarginBottom = 0;
            this.txtProductDetails.TextMarginLeft = 5;
            this.txtProductDetails.TextMarginTop = 0;
            this.txtProductDetails.TextPlaceholder = "Imported\r\n100% Coton\r\n\r\n";
            this.txtProductDetails.UseSystemPasswordChar = false;
            this.txtProductDetails.WordWrap = true;
            this.txtProductDetails.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtProductDetails_KeyDown);
            // 
            // txtProductSize
            // 
            this.txtProductSize.AcceptsReturn = false;
            this.txtProductSize.AcceptsTab = false;
            this.txtProductSize.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtProductSize.AnimationSpeed = 200;
            this.txtProductSize.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtProductSize.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtProductSize.BackColor = System.Drawing.Color.Transparent;
            this.txtProductSize.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtProductSize.BackgroundImage")));
            this.txtProductSize.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtProductSize.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.txtProductSize.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtProductSize.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtProductSize.BorderRadius = 1;
            this.txtProductSize.BorderThickness = 1;
            this.txtProductSize.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtProductSize.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtProductSize.DefaultFont = new System.Drawing.Font("Segoe UI", 10F);
            this.txtProductSize.DefaultText = "";
            this.txtProductSize.FillColor = System.Drawing.Color.White;
            this.txtProductSize.HideSelection = true;
            this.txtProductSize.IconLeft = null;
            this.txtProductSize.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtProductSize.IconPadding = 10;
            this.txtProductSize.IconRight = null;
            this.txtProductSize.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtProductSize.Lines = new string[0];
            this.txtProductSize.Location = new System.Drawing.Point(257, 146);
            this.txtProductSize.MaxLength = 32767;
            this.txtProductSize.MinimumSize = new System.Drawing.Size(100, 35);
            this.txtProductSize.Modified = false;
            this.txtProductSize.Multiline = false;
            this.txtProductSize.Name = "txtProductSize";
            stateProperties5.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtProductSize.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.Empty;
            stateProperties6.FillColor = System.Drawing.Color.White;
            stateProperties6.ForeColor = System.Drawing.Color.Empty;
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtProductSize.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtProductSize.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.Silver;
            stateProperties8.FillColor = System.Drawing.Color.White;
            stateProperties8.ForeColor = System.Drawing.Color.Empty;
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtProductSize.OnIdleState = stateProperties8;
            this.txtProductSize.PasswordChar = '\0';
            this.txtProductSize.PlaceholderForeColor = System.Drawing.Color.DimGray;
            this.txtProductSize.PlaceholderText = "XXL";
            this.txtProductSize.ReadOnly = false;
            this.txtProductSize.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtProductSize.SelectedText = "";
            this.txtProductSize.SelectionLength = 0;
            this.txtProductSize.SelectionStart = 0;
            this.txtProductSize.ShortcutsEnabled = true;
            this.txtProductSize.Size = new System.Drawing.Size(224, 35);
            this.txtProductSize.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtProductSize.TabIndex = 3;
            this.txtProductSize.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtProductSize.TextMarginBottom = 0;
            this.txtProductSize.TextMarginLeft = 5;
            this.txtProductSize.TextMarginTop = 0;
            this.txtProductSize.TextPlaceholder = "XXL";
            this.txtProductSize.UseSystemPasswordChar = false;
            this.txtProductSize.WordWrap = true;
            this.txtProductSize.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtProductSize_KeyDown);
            // 
            // txtProductCtg
            // 
            this.txtProductCtg.AcceptsReturn = false;
            this.txtProductCtg.AcceptsTab = false;
            this.txtProductCtg.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtProductCtg.AnimationSpeed = 200;
            this.txtProductCtg.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtProductCtg.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtProductCtg.BackColor = System.Drawing.Color.White;
            this.txtProductCtg.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtProductCtg.BackgroundImage")));
            this.txtProductCtg.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtProductCtg.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.txtProductCtg.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtProductCtg.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtProductCtg.BorderRadius = 1;
            this.txtProductCtg.BorderThickness = 1;
            this.txtProductCtg.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtProductCtg.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtProductCtg.DefaultFont = new System.Drawing.Font("Segoe UI", 10F);
            this.txtProductCtg.DefaultText = "";
            this.txtProductCtg.FillColor = System.Drawing.Color.White;
            this.txtProductCtg.HideSelection = true;
            this.txtProductCtg.IconLeft = null;
            this.txtProductCtg.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtProductCtg.IconPadding = 10;
            this.txtProductCtg.IconRight = null;
            this.txtProductCtg.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtProductCtg.Lines = new string[0];
            this.txtProductCtg.Location = new System.Drawing.Point(257, 38);
            this.txtProductCtg.MaxLength = 32767;
            this.txtProductCtg.MinimumSize = new System.Drawing.Size(100, 35);
            this.txtProductCtg.Modified = false;
            this.txtProductCtg.Multiline = false;
            this.txtProductCtg.Name = "txtProductCtg";
            stateProperties9.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties9.FillColor = System.Drawing.Color.Empty;
            stateProperties9.ForeColor = System.Drawing.Color.Empty;
            stateProperties9.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtProductCtg.OnActiveState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.Empty;
            stateProperties10.FillColor = System.Drawing.Color.White;
            stateProperties10.ForeColor = System.Drawing.Color.Empty;
            stateProperties10.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtProductCtg.OnDisabledState = stateProperties10;
            stateProperties11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties11.FillColor = System.Drawing.Color.Empty;
            stateProperties11.ForeColor = System.Drawing.Color.Empty;
            stateProperties11.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtProductCtg.OnHoverState = stateProperties11;
            stateProperties12.BorderColor = System.Drawing.Color.Silver;
            stateProperties12.FillColor = System.Drawing.Color.White;
            stateProperties12.ForeColor = System.Drawing.Color.Empty;
            stateProperties12.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtProductCtg.OnIdleState = stateProperties12;
            this.txtProductCtg.PasswordChar = '\0';
            this.txtProductCtg.PlaceholderForeColor = System.Drawing.Color.DimGray;
            this.txtProductCtg.PlaceholderText = "Shirt";
            this.txtProductCtg.ReadOnly = false;
            this.txtProductCtg.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtProductCtg.SelectedText = "";
            this.txtProductCtg.SelectionLength = 0;
            this.txtProductCtg.SelectionStart = 0;
            this.txtProductCtg.ShortcutsEnabled = true;
            this.txtProductCtg.Size = new System.Drawing.Size(224, 35);
            this.txtProductCtg.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtProductCtg.TabIndex = 6;
            this.txtProductCtg.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtProductCtg.TextMarginBottom = 0;
            this.txtProductCtg.TextMarginLeft = 5;
            this.txtProductCtg.TextMarginTop = 0;
            this.txtProductCtg.TextPlaceholder = "Shirt";
            this.txtProductCtg.UseSystemPasswordChar = false;
            this.txtProductCtg.WordWrap = true;
            this.txtProductCtg.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtProductCtg_KeyDown);
            // 
            // txtProductName
            // 
            this.txtProductName.AcceptsReturn = false;
            this.txtProductName.AcceptsTab = false;
            this.txtProductName.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtProductName.AnimationSpeed = 200;
            this.txtProductName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtProductName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtProductName.BackColor = System.Drawing.Color.White;
            this.txtProductName.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtProductName.BackgroundImage")));
            this.txtProductName.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtProductName.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.txtProductName.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtProductName.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtProductName.BorderRadius = 1;
            this.txtProductName.BorderThickness = 1;
            this.txtProductName.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtProductName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtProductName.DefaultFont = new System.Drawing.Font("Segoe UI", 10F);
            this.txtProductName.DefaultText = "";
            this.txtProductName.FillColor = System.Drawing.Color.White;
            this.txtProductName.HideSelection = true;
            this.txtProductName.IconLeft = null;
            this.txtProductName.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtProductName.IconPadding = 10;
            this.txtProductName.IconRight = null;
            this.txtProductName.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtProductName.Lines = new string[0];
            this.txtProductName.Location = new System.Drawing.Point(257, 92);
            this.txtProductName.MaxLength = 32767;
            this.txtProductName.MinimumSize = new System.Drawing.Size(100, 35);
            this.txtProductName.Modified = false;
            this.txtProductName.Multiline = false;
            this.txtProductName.Name = "txtProductName";
            stateProperties13.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties13.FillColor = System.Drawing.Color.Empty;
            stateProperties13.ForeColor = System.Drawing.Color.Empty;
            stateProperties13.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtProductName.OnActiveState = stateProperties13;
            stateProperties14.BorderColor = System.Drawing.Color.Empty;
            stateProperties14.FillColor = System.Drawing.Color.White;
            stateProperties14.ForeColor = System.Drawing.Color.Empty;
            stateProperties14.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtProductName.OnDisabledState = stateProperties14;
            stateProperties15.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties15.FillColor = System.Drawing.Color.Empty;
            stateProperties15.ForeColor = System.Drawing.Color.Empty;
            stateProperties15.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtProductName.OnHoverState = stateProperties15;
            stateProperties16.BorderColor = System.Drawing.Color.Silver;
            stateProperties16.FillColor = System.Drawing.Color.White;
            stateProperties16.ForeColor = System.Drawing.Color.Empty;
            stateProperties16.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtProductName.OnIdleState = stateProperties16;
            this.txtProductName.PasswordChar = '\0';
            this.txtProductName.PlaceholderForeColor = System.Drawing.Color.DimGray;
            this.txtProductName.PlaceholderText = "Lined Rugged Shirt";
            this.txtProductName.ReadOnly = false;
            this.txtProductName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtProductName.SelectedText = "";
            this.txtProductName.SelectionLength = 0;
            this.txtProductName.SelectionStart = 0;
            this.txtProductName.ShortcutsEnabled = true;
            this.txtProductName.Size = new System.Drawing.Size(224, 35);
            this.txtProductName.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtProductName.TabIndex = 2;
            this.txtProductName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtProductName.TextMarginBottom = 0;
            this.txtProductName.TextMarginLeft = 5;
            this.txtProductName.TextMarginTop = 0;
            this.txtProductName.TextPlaceholder = "Lined Rugged Shirt";
            this.txtProductName.UseSystemPasswordChar = false;
            this.txtProductName.WordWrap = true;
            this.txtProductName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtProductName_KeyDown);
            this.txtProductName.Click += new System.EventHandler(this.txtProductName_Click);
            // 
            // lblTitle
            // 
            this.lblTitle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(127, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(295, 67);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "ADD NEW PRODUCT";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frmAddNewProduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.ClientSize = new System.Drawing.Size(550, 450);
            this.Controls.Add(this.tblLyPnlMain);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmAddNewProduct";
            this.Text = "frmAddNewProduct";
            this.tblLyPnlMain.ResumeLayout(false);
            this.tblLyPnlMain.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tblLyPnlMain;
        private System.Windows.Forms.Panel panel1;
        private Bunifu.Framework.UI.BunifuThinButton2 btnAddNewProduct;
        private Bunifu.Framework.UI.BunifuThinButton2 btnClear;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtProductSize;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtProductName;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtProductDetails;
        private Bunifu.Framework.UI.BunifuCustomLabel lblTitle;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtProductCtg;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
    }
}