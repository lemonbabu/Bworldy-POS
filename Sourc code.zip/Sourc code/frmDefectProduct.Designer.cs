﻿
namespace ERP
{
    partial class frmDefectProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDefectProduct));
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tblLyPnlMain = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tblPnlDefectProduct = new System.Windows.Forms.TableLayoutPanel();
            this.pnlCntSales = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.pnlProductDetails = new System.Windows.Forms.Panel();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblStock = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel8 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lblDiscount = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel7 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lblPdcDetails = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lblPdcSize = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lblPdcName = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lblCtgName = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lblSalePrice = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel5 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel3 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel4 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.pnlDatagridView = new System.Windows.Forms.Panel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnViewDefects = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnConfirm = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuLabel1 = new Bunifu.UI.WinForms.BunifuLabel();
            this.txtDetails = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.pnlBarcdeReader = new System.Windows.Forms.Panel();
            this.txtBarcode = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.pnlDefectProductView = new System.Windows.Forms.Panel();
            this.dataGridViewDefectProductView = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.ctgNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pSizeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.detailsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblDefectProductsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.appData = new ERP.AppData();
            this.lblTitle = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.tblDefectProductsTableAdapter = new ERP.AppDataTableAdapters.tblDefectProductsTableAdapter();
            this.tblLyPnlMain.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tblPnlDefectProduct.SuspendLayout();
            this.pnlCntSales.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.pnlProductDetails.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.panel2.SuspendLayout();
            this.pnlDatagridView.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.pnlBarcdeReader.SuspendLayout();
            this.pnlDefectProductView.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDefectProductView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblDefectProductsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.appData)).BeginInit();
            this.SuspendLayout();
            // 
            // tblLyPnlMain
            // 
            this.tblLyPnlMain.ColumnCount = 1;
            this.tblLyPnlMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblLyPnlMain.Controls.Add(this.panel1, 0, 1);
            this.tblLyPnlMain.Controls.Add(this.lblTitle, 0, 0);
            this.tblLyPnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblLyPnlMain.ForeColor = System.Drawing.Color.Black;
            this.tblLyPnlMain.Location = new System.Drawing.Point(0, 0);
            this.tblLyPnlMain.Name = "tblLyPnlMain";
            this.tblLyPnlMain.RowCount = 2;
            this.tblLyPnlMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tblLyPnlMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tblLyPnlMain.Size = new System.Drawing.Size(550, 450);
            this.tblLyPnlMain.TabIndex = 12;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tblPnlDefectProduct);
            this.panel1.Controls.Add(this.pnlDefectProductView);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 48);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(544, 399);
            this.panel1.TabIndex = 0;
            // 
            // tblPnlDefectProduct
            // 
            this.tblPnlDefectProduct.ColumnCount = 3;
            this.tblPnlDefectProduct.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tblPnlDefectProduct.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tblPnlDefectProduct.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tblPnlDefectProduct.Controls.Add(this.pnlCntSales, 1, 1);
            this.tblPnlDefectProduct.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblPnlDefectProduct.Location = new System.Drawing.Point(0, 0);
            this.tblPnlDefectProduct.Name = "tblPnlDefectProduct";
            this.tblPnlDefectProduct.RowCount = 3;
            this.tblPnlDefectProduct.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 1F));
            this.tblPnlDefectProduct.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 97F));
            this.tblPnlDefectProduct.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2F));
            this.tblPnlDefectProduct.Size = new System.Drawing.Size(544, 399);
            this.tblPnlDefectProduct.TabIndex = 7;
            // 
            // pnlCntSales
            // 
            this.pnlCntSales.Controls.Add(this.tableLayoutPanel2);
            this.pnlCntSales.Controls.Add(this.pnlBarcdeReader);
            this.pnlCntSales.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlCntSales.Location = new System.Drawing.Point(30, 6);
            this.pnlCntSales.Name = "pnlCntSales";
            this.pnlCntSales.Size = new System.Drawing.Size(483, 381);
            this.pnlCntSales.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.pnlProductDetails, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.pnlDatagridView, 1, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 70);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(483, 311);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // pnlProductDetails
            // 
            this.pnlProductDetails.Controls.Add(this.tableLayoutPanel5);
            this.pnlProductDetails.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlProductDetails.Location = new System.Drawing.Point(3, 3);
            this.pnlProductDetails.Name = "pnlProductDetails";
            this.pnlProductDetails.Size = new System.Drawing.Size(235, 305);
            this.pnlProductDetails.TabIndex = 0;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 1;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 235F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel5.Controls.Add(this.panel2, 0, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(235, 305);
            this.tableLayoutPanel5.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel2.Controls.Add(this.lblStock);
            this.panel2.Controls.Add(this.bunifuCustomLabel8);
            this.panel2.Controls.Add(this.lblDiscount);
            this.panel2.Controls.Add(this.bunifuCustomLabel7);
            this.panel2.Controls.Add(this.lblPdcDetails);
            this.panel2.Controls.Add(this.lblPdcSize);
            this.panel2.Controls.Add(this.lblPdcName);
            this.panel2.Controls.Add(this.lblCtgName);
            this.panel2.Controls.Add(this.lblSalePrice);
            this.panel2.Controls.Add(this.bunifuCustomLabel5);
            this.panel2.Controls.Add(this.bunifuCustomLabel3);
            this.panel2.Controls.Add(this.bunifuCustomLabel4);
            this.panel2.Controls.Add(this.bunifuCustomLabel2);
            this.panel2.Controls.Add(this.bunifuCustomLabel1);
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(229, 267);
            this.panel2.TabIndex = 0;
            // 
            // lblStock
            // 
            this.lblStock.AccessibleName = "lblDiscount";
            this.lblStock.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblStock.AutoSize = true;
            this.lblStock.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStock.ForeColor = System.Drawing.Color.Crimson;
            this.lblStock.Location = new System.Drawing.Point(109, 195);
            this.lblStock.Name = "lblStock";
            this.lblStock.Size = new System.Drawing.Size(19, 21);
            this.lblStock.TabIndex = 13;
            this.lblStock.Text = "0";
            this.lblStock.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // bunifuCustomLabel8
            // 
            this.bunifuCustomLabel8.AccessibleName = "lblDiscount";
            this.bunifuCustomLabel8.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuCustomLabel8.AutoSize = true;
            this.bunifuCustomLabel8.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel8.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel8.Location = new System.Drawing.Point(50, 195);
            this.bunifuCustomLabel8.Name = "bunifuCustomLabel8";
            this.bunifuCustomLabel8.Size = new System.Drawing.Size(54, 21);
            this.bunifuCustomLabel8.TabIndex = 12;
            this.bunifuCustomLabel8.Text = "Stock: ";
            this.bunifuCustomLabel8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDiscount
            // 
            this.lblDiscount.AccessibleName = "lblDiscount";
            this.lblDiscount.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblDiscount.AutoSize = true;
            this.lblDiscount.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDiscount.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblDiscount.Location = new System.Drawing.Point(109, 169);
            this.lblDiscount.Name = "lblDiscount";
            this.lblDiscount.Size = new System.Drawing.Size(19, 21);
            this.lblDiscount.TabIndex = 11;
            this.lblDiscount.Text = "0";
            this.lblDiscount.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // bunifuCustomLabel7
            // 
            this.bunifuCustomLabel7.AccessibleName = "lblDiscount";
            this.bunifuCustomLabel7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuCustomLabel7.AutoSize = true;
            this.bunifuCustomLabel7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel7.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel7.Location = new System.Drawing.Point(26, 169);
            this.bunifuCustomLabel7.Name = "bunifuCustomLabel7";
            this.bunifuCustomLabel7.Size = new System.Drawing.Size(78, 21);
            this.bunifuCustomLabel7.TabIndex = 10;
            this.bunifuCustomLabel7.Text = "Discount: ";
            this.bunifuCustomLabel7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPdcDetails
            // 
            this.lblPdcDetails.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblPdcDetails.AutoSize = true;
            this.lblPdcDetails.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPdcDetails.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblPdcDetails.Location = new System.Drawing.Point(109, 143);
            this.lblPdcDetails.Name = "lblPdcDetails";
            this.lblPdcDetails.Size = new System.Drawing.Size(19, 21);
            this.lblPdcDetails.TabIndex = 9;
            this.lblPdcDetails.Text = "0";
            this.lblPdcDetails.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblPdcSize
            // 
            this.lblPdcSize.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblPdcSize.AutoSize = true;
            this.lblPdcSize.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPdcSize.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblPdcSize.Location = new System.Drawing.Point(109, 117);
            this.lblPdcSize.Name = "lblPdcSize";
            this.lblPdcSize.Size = new System.Drawing.Size(19, 21);
            this.lblPdcSize.TabIndex = 8;
            this.lblPdcSize.Text = "0";
            this.lblPdcSize.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblPdcName
            // 
            this.lblPdcName.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblPdcName.AutoSize = true;
            this.lblPdcName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPdcName.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblPdcName.Location = new System.Drawing.Point(109, 91);
            this.lblPdcName.Name = "lblPdcName";
            this.lblPdcName.Size = new System.Drawing.Size(19, 21);
            this.lblPdcName.TabIndex = 7;
            this.lblPdcName.Text = "0";
            this.lblPdcName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblCtgName
            // 
            this.lblCtgName.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblCtgName.AutoSize = true;
            this.lblCtgName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCtgName.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblCtgName.Location = new System.Drawing.Point(109, 65);
            this.lblCtgName.Name = "lblCtgName";
            this.lblCtgName.Size = new System.Drawing.Size(19, 21);
            this.lblCtgName.TabIndex = 6;
            this.lblCtgName.Text = "0";
            this.lblCtgName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblSalePrice
            // 
            this.lblSalePrice.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblSalePrice.AutoSize = true;
            this.lblSalePrice.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalePrice.ForeColor = System.Drawing.Color.DeepSkyBlue;
            this.lblSalePrice.Location = new System.Drawing.Point(109, 39);
            this.lblSalePrice.Name = "lblSalePrice";
            this.lblSalePrice.Size = new System.Drawing.Size(19, 21);
            this.lblSalePrice.TabIndex = 5;
            this.lblSalePrice.Text = "0";
            this.lblSalePrice.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // bunifuCustomLabel5
            // 
            this.bunifuCustomLabel5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuCustomLabel5.AutoSize = true;
            this.bunifuCustomLabel5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel5.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel5.Location = new System.Drawing.Point(20, 39);
            this.bunifuCustomLabel5.Name = "bunifuCustomLabel5";
            this.bunifuCustomLabel5.Size = new System.Drawing.Size(84, 21);
            this.bunifuCustomLabel5.TabIndex = 4;
            this.bunifuCustomLabel5.Text = "Sale Price: ";
            this.bunifuCustomLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bunifuCustomLabel3
            // 
            this.bunifuCustomLabel3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuCustomLabel3.AutoSize = true;
            this.bunifuCustomLabel3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel3.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel3.Location = new System.Drawing.Point(40, 143);
            this.bunifuCustomLabel3.Name = "bunifuCustomLabel3";
            this.bunifuCustomLabel3.Size = new System.Drawing.Size(64, 21);
            this.bunifuCustomLabel3.TabIndex = 3;
            this.bunifuCustomLabel3.Text = "Details: ";
            this.bunifuCustomLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bunifuCustomLabel4
            // 
            this.bunifuCustomLabel4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuCustomLabel4.AutoSize = true;
            this.bunifuCustomLabel4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel4.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel4.Location = new System.Drawing.Point(59, 117);
            this.bunifuCustomLabel4.Name = "bunifuCustomLabel4";
            this.bunifuCustomLabel4.Size = new System.Drawing.Size(45, 21);
            this.bunifuCustomLabel4.TabIndex = 2;
            this.bunifuCustomLabel4.Text = "Size: ";
            this.bunifuCustomLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(45, 91);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(59, 21);
            this.bunifuCustomLabel2.TabIndex = 1;
            this.bunifuCustomLabel2.Text = "Name: ";
            this.bunifuCustomLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(20, 65);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(84, 21);
            this.bunifuCustomLabel1.TabIndex = 0;
            this.bunifuCustomLabel1.Text = "Categorie: ";
            this.bunifuCustomLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlDatagridView
            // 
            this.pnlDatagridView.Controls.Add(this.tableLayoutPanel4);
            this.pnlDatagridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlDatagridView.Location = new System.Drawing.Point(244, 3);
            this.pnlDatagridView.Name = "pnlDatagridView";
            this.pnlDatagridView.Size = new System.Drawing.Size(236, 305);
            this.pnlDatagridView.TabIndex = 1;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Controls.Add(this.panel3, 0, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(236, 305);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.btnViewDefects);
            this.panel3.Controls.Add(this.btnConfirm);
            this.panel3.Controls.Add(this.bunifuLabel1);
            this.panel3.Controls.Add(this.txtDetails);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(230, 264);
            this.panel3.TabIndex = 1;
            // 
            // btnViewDefects
            // 
            this.btnViewDefects.Active = false;
            this.btnViewDefects.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(180)))), ((int)(((byte)(0)))));
            this.btnViewDefects.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnViewDefects.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.btnViewDefects.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnViewDefects.BorderRadius = 0;
            this.btnViewDefects.ButtonText = "View Defects";
            this.btnViewDefects.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnViewDefects.DisabledColor = System.Drawing.Color.Gray;
            this.btnViewDefects.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewDefects.Iconcolor = System.Drawing.Color.Transparent;
            this.btnViewDefects.Iconimage = global::ERP.Properties.Resources.viewIcon_25;
            this.btnViewDefects.Iconimage_right = null;
            this.btnViewDefects.Iconimage_right_Selected = null;
            this.btnViewDefects.Iconimage_Selected = null;
            this.btnViewDefects.IconMarginLeft = 0;
            this.btnViewDefects.IconMarginRight = 0;
            this.btnViewDefects.IconRightVisible = true;
            this.btnViewDefects.IconRightZoom = 0D;
            this.btnViewDefects.IconVisible = true;
            this.btnViewDefects.IconZoom = 60D;
            this.btnViewDefects.IsTab = false;
            this.btnViewDefects.Location = new System.Drawing.Point(50, 195);
            this.btnViewDefects.Name = "btnViewDefects";
            this.btnViewDefects.Normalcolor = System.Drawing.Color.DarkGoldenrod;
            this.btnViewDefects.OnHovercolor = System.Drawing.Color.Orange;
            this.btnViewDefects.OnHoverTextColor = System.Drawing.Color.White;
            this.btnViewDefects.selected = false;
            this.btnViewDefects.Size = new System.Drawing.Size(132, 39);
            this.btnViewDefects.TabIndex = 2;
            this.btnViewDefects.Text = "View Defects";
            this.btnViewDefects.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnViewDefects.Textcolor = System.Drawing.Color.White;
            this.btnViewDefects.TextFont = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnViewDefects.Click += new System.EventHandler(this.btnViewDefects_Click);
            // 
            // btnConfirm
            // 
            this.btnConfirm.Active = false;
            this.btnConfirm.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(180)))), ((int)(((byte)(0)))));
            this.btnConfirm.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnConfirm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnConfirm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnConfirm.BorderRadius = 0;
            this.btnConfirm.ButtonText = "Confirm >>";
            this.btnConfirm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnConfirm.DisabledColor = System.Drawing.Color.Gray;
            this.btnConfirm.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfirm.Iconcolor = System.Drawing.Color.Transparent;
            this.btnConfirm.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnConfirm.Iconimage")));
            this.btnConfirm.Iconimage_right = null;
            this.btnConfirm.Iconimage_right_Selected = null;
            this.btnConfirm.Iconimage_Selected = null;
            this.btnConfirm.IconMarginLeft = 0;
            this.btnConfirm.IconMarginRight = 0;
            this.btnConfirm.IconRightVisible = true;
            this.btnConfirm.IconRightZoom = 0D;
            this.btnConfirm.IconVisible = true;
            this.btnConfirm.IconZoom = 100D;
            this.btnConfirm.IsTab = false;
            this.btnConfirm.Location = new System.Drawing.Point(50, 143);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnConfirm.OnHovercolor = System.Drawing.Color.DeepSkyBlue;
            this.btnConfirm.OnHoverTextColor = System.Drawing.Color.White;
            this.btnConfirm.selected = false;
            this.btnConfirm.Size = new System.Drawing.Size(132, 39);
            this.btnConfirm.TabIndex = 0;
            this.btnConfirm.Text = "Confirm >>";
            this.btnConfirm.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnConfirm.Textcolor = System.Drawing.Color.White;
            this.btnConfirm.TextFont = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // bunifuLabel1
            // 
            this.bunifuLabel1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuLabel1.AutoEllipsis = false;
            this.bunifuLabel1.CursorType = null;
            this.bunifuLabel1.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel1.Location = new System.Drawing.Point(82, 2);
            this.bunifuLabel1.Name = "bunifuLabel1";
            this.bunifuLabel1.Padding = new System.Windows.Forms.Padding(0, 5, 0, 0);
            this.bunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel1.Size = new System.Drawing.Size(74, 36);
            this.bunifuLabel1.TabIndex = 1;
            this.bunifuLabel1.Text = "REASON";
            this.bunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuLabel1.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // txtDetails
            // 
            this.txtDetails.AcceptsReturn = false;
            this.txtDetails.AcceptsTab = false;
            this.txtDetails.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtDetails.AnimationSpeed = 200;
            this.txtDetails.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtDetails.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtDetails.BackColor = System.Drawing.Color.White;
            this.txtDetails.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtDetails.BackgroundImage")));
            this.txtDetails.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtDetails.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.txtDetails.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtDetails.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtDetails.BorderRadius = 1;
            this.txtDetails.BorderThickness = 1;
            this.txtDetails.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtDetails.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtDetails.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.txtDetails.DefaultText = "";
            this.txtDetails.FillColor = System.Drawing.Color.White;
            this.txtDetails.HideSelection = true;
            this.txtDetails.IconLeft = null;
            this.txtDetails.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtDetails.IconPadding = 10;
            this.txtDetails.IconRight = null;
            this.txtDetails.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtDetails.Lines = new string[0];
            this.txtDetails.Location = new System.Drawing.Point(18, 51);
            this.txtDetails.MaxLength = 32767;
            this.txtDetails.MinimumSize = new System.Drawing.Size(100, 35);
            this.txtDetails.Modified = false;
            this.txtDetails.Multiline = false;
            this.txtDetails.Name = "txtDetails";
            stateProperties1.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtDetails.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.Empty;
            stateProperties2.FillColor = System.Drawing.Color.White;
            stateProperties2.ForeColor = System.Drawing.Color.Empty;
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtDetails.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtDetails.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.Silver;
            stateProperties4.FillColor = System.Drawing.Color.White;
            stateProperties4.ForeColor = System.Drawing.Color.Empty;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtDetails.OnIdleState = stateProperties4;
            this.txtDetails.PasswordChar = '\0';
            this.txtDetails.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtDetails.PlaceholderText = "Details";
            this.txtDetails.ReadOnly = false;
            this.txtDetails.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtDetails.SelectedText = "";
            this.txtDetails.SelectionLength = 0;
            this.txtDetails.SelectionStart = 0;
            this.txtDetails.ShortcutsEnabled = true;
            this.txtDetails.Size = new System.Drawing.Size(196, 35);
            this.txtDetails.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Material;
            this.txtDetails.TabIndex = 0;
            this.txtDetails.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtDetails.TextMarginBottom = 0;
            this.txtDetails.TextMarginLeft = 5;
            this.txtDetails.TextMarginTop = 0;
            this.txtDetails.TextPlaceholder = "Details";
            this.txtDetails.UseSystemPasswordChar = false;
            this.txtDetails.WordWrap = true;
            this.txtDetails.TextChanged += new System.EventHandler(this.txtDetails_TextChanged);
            this.txtDetails.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtDetails_KeyDown);
            // 
            // pnlBarcdeReader
            // 
            this.pnlBarcdeReader.Controls.Add(this.txtBarcode);
            this.pnlBarcdeReader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlBarcdeReader.Location = new System.Drawing.Point(0, 0);
            this.pnlBarcdeReader.Name = "pnlBarcdeReader";
            this.pnlBarcdeReader.Size = new System.Drawing.Size(483, 70);
            this.pnlBarcdeReader.TabIndex = 0;
            // 
            // txtBarcode
            // 
            this.txtBarcode.AcceptsReturn = false;
            this.txtBarcode.AcceptsTab = false;
            this.txtBarcode.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtBarcode.AnimationSpeed = 200;
            this.txtBarcode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtBarcode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtBarcode.BackColor = System.Drawing.Color.Transparent;
            this.txtBarcode.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtBarcode.BackgroundImage")));
            this.txtBarcode.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtBarcode.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.txtBarcode.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtBarcode.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtBarcode.BorderRadius = 1;
            this.txtBarcode.BorderThickness = 1;
            this.txtBarcode.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtBarcode.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtBarcode.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 12F);
            this.txtBarcode.DefaultText = "";
            this.txtBarcode.FillColor = System.Drawing.Color.White;
            this.txtBarcode.HideSelection = true;
            this.txtBarcode.IconLeft = null;
            this.txtBarcode.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtBarcode.IconPadding = 10;
            this.txtBarcode.IconRight = null;
            this.txtBarcode.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtBarcode.Lines = new string[0];
            this.txtBarcode.Location = new System.Drawing.Point(64, 17);
            this.txtBarcode.MaxLength = 32767;
            this.txtBarcode.MinimumSize = new System.Drawing.Size(100, 35);
            this.txtBarcode.Modified = false;
            this.txtBarcode.Multiline = false;
            this.txtBarcode.Name = "txtBarcode";
            stateProperties5.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtBarcode.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.Empty;
            stateProperties6.FillColor = System.Drawing.Color.White;
            stateProperties6.ForeColor = System.Drawing.Color.Empty;
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtBarcode.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtBarcode.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.Silver;
            stateProperties8.FillColor = System.Drawing.Color.White;
            stateProperties8.ForeColor = System.Drawing.Color.Empty;
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtBarcode.OnIdleState = stateProperties8;
            this.txtBarcode.PasswordChar = '\0';
            this.txtBarcode.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtBarcode.PlaceholderText = "Scan Barcode";
            this.txtBarcode.ReadOnly = false;
            this.txtBarcode.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtBarcode.SelectedText = "";
            this.txtBarcode.SelectionLength = 0;
            this.txtBarcode.SelectionStart = 0;
            this.txtBarcode.ShortcutsEnabled = true;
            this.txtBarcode.Size = new System.Drawing.Size(337, 35);
            this.txtBarcode.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtBarcode.TabIndex = 2;
            this.txtBarcode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtBarcode.TextMarginBottom = 0;
            this.txtBarcode.TextMarginLeft = 5;
            this.txtBarcode.TextMarginTop = 0;
            this.txtBarcode.TextPlaceholder = "Scan Barcode";
            this.txtBarcode.UseSystemPasswordChar = false;
            this.txtBarcode.WordWrap = true;
            this.txtBarcode.TextChanged += new System.EventHandler(this.txtBarcode_TextChanged);
            this.txtBarcode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtBarcode_KeyDown);
            // 
            // pnlDefectProductView
            // 
            this.pnlDefectProductView.Controls.Add(this.dataGridViewDefectProductView);
            this.pnlDefectProductView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlDefectProductView.Location = new System.Drawing.Point(0, 0);
            this.pnlDefectProductView.Name = "pnlDefectProductView";
            this.pnlDefectProductView.Padding = new System.Windows.Forms.Padding(20);
            this.pnlDefectProductView.Size = new System.Drawing.Size(544, 399);
            this.pnlDefectProductView.TabIndex = 8;
            // 
            // dataGridViewDefectProductView
            // 
            this.dataGridViewDefectProductView.AllowCustomTheming = false;
            this.dataGridViewDefectProductView.AllowUserToAddRows = false;
            this.dataGridViewDefectProductView.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewDefectProductView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewDefectProductView.AutoGenerateColumns = false;
            this.dataGridViewDefectProductView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewDefectProductView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewDefectProductView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dataGridViewDefectProductView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.DodgerBlue;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewDefectProductView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewDefectProductView.ColumnHeadersHeight = 40;
            this.dataGridViewDefectProductView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ctgNameDataGridViewTextBoxColumn,
            this.pNameDataGridViewTextBoxColumn,
            this.pSizeDataGridViewTextBoxColumn,
            this.quantityDataGridViewTextBoxColumn,
            this.detailsDataGridViewTextBoxColumn,
            this.dateDataGridViewTextBoxColumn});
            this.dataGridViewDefectProductView.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(248)))), ((int)(((byte)(251)))), ((int)(((byte)(255)))));
            this.dataGridViewDefectProductView.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.dataGridViewDefectProductView.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewDefectProductView.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.dataGridViewDefectProductView.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridViewDefectProductView.CurrentTheme.BackColor = System.Drawing.Color.White;
            this.dataGridViewDefectProductView.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.dataGridViewDefectProductView.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.DodgerBlue;
            this.dataGridViewDefectProductView.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 11.75F, System.Drawing.FontStyle.Bold);
            this.dataGridViewDefectProductView.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.dataGridViewDefectProductView.CurrentTheme.Name = null;
            this.dataGridViewDefectProductView.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.White;
            this.dataGridViewDefectProductView.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.dataGridViewDefectProductView.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewDefectProductView.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            this.dataGridViewDefectProductView.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridViewDefectProductView.DataSource = this.tblDefectProductsBindingSource;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(232)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewDefectProductView.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewDefectProductView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewDefectProductView.EnableHeadersVisualStyles = false;
            this.dataGridViewDefectProductView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(221)))), ((int)(((byte)(238)))), ((int)(((byte)(255)))));
            this.dataGridViewDefectProductView.HeaderBackColor = System.Drawing.Color.DodgerBlue;
            this.dataGridViewDefectProductView.HeaderBgColor = System.Drawing.Color.Empty;
            this.dataGridViewDefectProductView.HeaderForeColor = System.Drawing.Color.White;
            this.dataGridViewDefectProductView.Location = new System.Drawing.Point(20, 20);
            this.dataGridViewDefectProductView.Name = "dataGridViewDefectProductView";
            this.dataGridViewDefectProductView.ReadOnly = true;
            this.dataGridViewDefectProductView.RowHeadersVisible = false;
            this.dataGridViewDefectProductView.RowTemplate.Height = 40;
            this.dataGridViewDefectProductView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewDefectProductView.Size = new System.Drawing.Size(504, 359);
            this.dataGridViewDefectProductView.TabIndex = 0;
            this.dataGridViewDefectProductView.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.Light;
            // 
            // ctgNameDataGridViewTextBoxColumn
            // 
            this.ctgNameDataGridViewTextBoxColumn.DataPropertyName = "ctgName";
            this.ctgNameDataGridViewTextBoxColumn.HeaderText = "Categorie";
            this.ctgNameDataGridViewTextBoxColumn.Name = "ctgNameDataGridViewTextBoxColumn";
            this.ctgNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // pNameDataGridViewTextBoxColumn
            // 
            this.pNameDataGridViewTextBoxColumn.DataPropertyName = "pName";
            this.pNameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.pNameDataGridViewTextBoxColumn.Name = "pNameDataGridViewTextBoxColumn";
            this.pNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // pSizeDataGridViewTextBoxColumn
            // 
            this.pSizeDataGridViewTextBoxColumn.DataPropertyName = "pSize";
            this.pSizeDataGridViewTextBoxColumn.HeaderText = "Size";
            this.pSizeDataGridViewTextBoxColumn.Name = "pSizeDataGridViewTextBoxColumn";
            this.pSizeDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // quantityDataGridViewTextBoxColumn
            // 
            this.quantityDataGridViewTextBoxColumn.DataPropertyName = "quantity";
            this.quantityDataGridViewTextBoxColumn.HeaderText = "Quantity";
            this.quantityDataGridViewTextBoxColumn.Name = "quantityDataGridViewTextBoxColumn";
            this.quantityDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // detailsDataGridViewTextBoxColumn
            // 
            this.detailsDataGridViewTextBoxColumn.DataPropertyName = "details";
            this.detailsDataGridViewTextBoxColumn.HeaderText = "Details";
            this.detailsDataGridViewTextBoxColumn.Name = "detailsDataGridViewTextBoxColumn";
            this.detailsDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dateDataGridViewTextBoxColumn
            // 
            this.dateDataGridViewTextBoxColumn.DataPropertyName = "date";
            this.dateDataGridViewTextBoxColumn.HeaderText = "Date";
            this.dateDataGridViewTextBoxColumn.Name = "dateDataGridViewTextBoxColumn";
            this.dateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // tblDefectProductsBindingSource
            // 
            this.tblDefectProductsBindingSource.DataMember = "tblDefectProducts";
            this.tblDefectProductsBindingSource.DataSource = this.appData;
            // 
            // appData
            // 
            this.appData.DataSetName = "AppData";
            this.appData.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lblTitle
            // 
            this.lblTitle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI Semibold", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(146, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(257, 45);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "DEFECT PRODUCT";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tblDefectProductsTableAdapter
            // 
            this.tblDefectProductsTableAdapter.ClearBeforeFill = true;
            // 
            // frmDefectProduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.ClientSize = new System.Drawing.Size(550, 450);
            this.Controls.Add(this.tblLyPnlMain);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmDefectProduct";
            this.Text = "frmDefectProduct";
            this.Load += new System.EventHandler(this.frmDefectProduct_Load);
            this.tblLyPnlMain.ResumeLayout(false);
            this.tblLyPnlMain.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tblPnlDefectProduct.ResumeLayout(false);
            this.pnlCntSales.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.pnlProductDetails.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.pnlDatagridView.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.pnlBarcdeReader.ResumeLayout(false);
            this.pnlDefectProductView.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDefectProductView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblDefectProductsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.appData)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tblLyPnlMain;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tblPnlDefectProduct;
        private System.Windows.Forms.Panel pnlCntSales;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel pnlProductDetails;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Panel panel2;
        private Bunifu.Framework.UI.BunifuCustomLabel lblStock;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel8;
        private Bunifu.Framework.UI.BunifuCustomLabel lblDiscount;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel7;
        private Bunifu.Framework.UI.BunifuCustomLabel lblPdcDetails;
        private Bunifu.Framework.UI.BunifuCustomLabel lblPdcSize;
        private Bunifu.Framework.UI.BunifuCustomLabel lblPdcName;
        private Bunifu.Framework.UI.BunifuCustomLabel lblCtgName;
        private Bunifu.Framework.UI.BunifuCustomLabel lblSalePrice;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel5;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel3;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel4;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private System.Windows.Forms.Panel pnlDatagridView;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Panel panel3;
        private Bunifu.Framework.UI.BunifuFlatButton btnConfirm;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel1;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtDetails;
        private System.Windows.Forms.Panel pnlBarcdeReader;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtBarcode;
        private Bunifu.Framework.UI.BunifuCustomLabel lblTitle;
        private System.Windows.Forms.Panel pnlDefectProductView;
        private Bunifu.UI.WinForms.BunifuDataGridView dataGridViewDefectProductView;
        private Bunifu.Framework.UI.BunifuFlatButton btnViewDefects;
        private AppData appData;
        private System.Windows.Forms.BindingSource tblDefectProductsBindingSource;
        private AppDataTableAdapters.tblDefectProductsTableAdapter tblDefectProductsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn ctgNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pSizeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn detailsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateDataGridViewTextBoxColumn;
    }
}