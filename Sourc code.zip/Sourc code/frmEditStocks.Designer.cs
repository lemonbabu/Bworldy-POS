﻿
namespace ERP
{
    partial class frmEditStocks
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEditStocks));
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            this.tblLyPnlMain = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.cmbProductCtg = new System.Windows.Forms.ComboBox();
            this.cmbProductName = new System.Windows.Forms.ComboBox();
            this.cmbProductSize = new System.Windows.Forms.ComboBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.pnlAddStockTools = new System.Windows.Forms.Panel();
            this.btnClear = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnEditStock = new Bunifu.Framework.UI.BunifuThinButton2();
            this.txtQuantity = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.txtSalePrice = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.txtBuyingPrice = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.pnlAddStockInfo = new System.Windows.Forms.Panel();
            this.txtLSalePrice = new Bunifu.Framework.BunifuCustomTextbox();
            this.txtLPPrice = new Bunifu.Framework.BunifuCustomTextbox();
            this.txtLQun = new Bunifu.Framework.BunifuCustomTextbox();
            this.bunifuLabel5 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel6 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel4 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel3 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel2 = new Bunifu.UI.WinForms.BunifuLabel();
            this.txtCurentStock = new Bunifu.Framework.BunifuCustomTextbox();
            this.txtLDate = new Bunifu.Framework.BunifuCustomTextbox();
            this.bunifuLabel1 = new Bunifu.UI.WinForms.BunifuLabel();
            this.lblTitle = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.tblLyPnlMain.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.pnlAddStockTools.SuspendLayout();
            this.pnlAddStockInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // tblLyPnlMain
            // 
            this.tblLyPnlMain.ColumnCount = 1;
            this.tblLyPnlMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblLyPnlMain.Controls.Add(this.panel1, 0, 1);
            this.tblLyPnlMain.Controls.Add(this.lblTitle, 0, 0);
            this.tblLyPnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblLyPnlMain.ForeColor = System.Drawing.Color.Black;
            this.tblLyPnlMain.Location = new System.Drawing.Point(0, 0);
            this.tblLyPnlMain.Name = "tblLyPnlMain";
            this.tblLyPnlMain.RowCount = 2;
            this.tblLyPnlMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tblLyPnlMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 85F));
            this.tblLyPnlMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblLyPnlMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblLyPnlMain.Size = new System.Drawing.Size(550, 450);
            this.tblLyPnlMain.TabIndex = 10;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 70);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(544, 377);
            this.panel1.TabIndex = 0;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 1, 2);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(544, 377);
            this.tableLayoutPanel1.TabIndex = 12;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 7;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.cmbProductCtg, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.cmbProductName, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.cmbProductSize, 5, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(30, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(483, 49);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // cmbProductCtg
            // 
            this.cmbProductCtg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmbProductCtg.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbProductCtg.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProductCtg.FormattingEnabled = true;
            this.cmbProductCtg.ItemHeight = 21;
            this.cmbProductCtg.Location = new System.Drawing.Point(24, 3);
            this.cmbProductCtg.Name = "cmbProductCtg";
            this.cmbProductCtg.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.cmbProductCtg.Size = new System.Drawing.Size(194, 29);
            this.cmbProductCtg.TabIndex = 1;
            this.cmbProductCtg.Text = " Select a Categorie";
            this.cmbProductCtg.Click += new System.EventHandler(this.cmbProductCtg_Click);
            // 
            // cmbProductName
            // 
            this.cmbProductName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmbProductName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProductName.FormattingEnabled = true;
            this.cmbProductName.Location = new System.Drawing.Point(229, 3);
            this.cmbProductName.Name = "cmbProductName";
            this.cmbProductName.Size = new System.Drawing.Size(144, 29);
            this.cmbProductName.TabIndex = 2;
            this.cmbProductName.Click += new System.EventHandler(this.cmbProductName_Click);
            // 
            // cmbProductSize
            // 
            this.cmbProductSize.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmbProductSize.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProductSize.FormattingEnabled = true;
            this.cmbProductSize.Location = new System.Drawing.Point(384, 3);
            this.cmbProductSize.Name = "cmbProductSize";
            this.cmbProductSize.Size = new System.Drawing.Size(74, 29);
            this.cmbProductSize.TabIndex = 3;
            this.cmbProductSize.SelectedValueChanged += new System.EventHandler(this.cmbProductSize_SelectedValueChanged);
            this.cmbProductSize.Click += new System.EventHandler(this.cmbProductSize_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.tableLayoutPanel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(30, 68);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(483, 287);
            this.panel2.TabIndex = 0;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 5;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 240F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 240F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.pnlAddStockTools, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.pnlAddStockInfo, 3, 1);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 3;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 400F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 95F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(483, 287);
            this.tableLayoutPanel3.TabIndex = 14;
            // 
            // pnlAddStockTools
            // 
            this.pnlAddStockTools.Controls.Add(this.btnClear);
            this.pnlAddStockTools.Controls.Add(this.btnEditStock);
            this.pnlAddStockTools.Controls.Add(this.txtQuantity);
            this.pnlAddStockTools.Controls.Add(this.txtSalePrice);
            this.pnlAddStockTools.Controls.Add(this.txtBuyingPrice);
            this.pnlAddStockTools.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlAddStockTools.Location = new System.Drawing.Point(2, -2);
            this.pnlAddStockTools.Name = "pnlAddStockTools";
            this.pnlAddStockTools.Size = new System.Drawing.Size(234, 394);
            this.pnlAddStockTools.TabIndex = 0;
            // 
            // btnClear
            // 
            this.btnClear.ActiveBorderThickness = 1;
            this.btnClear.ActiveCornerRadius = 1;
            this.btnClear.ActiveFillColor = System.Drawing.Color.Red;
            this.btnClear.ActiveForecolor = System.Drawing.Color.White;
            this.btnClear.ActiveLineColor = System.Drawing.Color.Red;
            this.btnClear.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnClear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnClear.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnClear.BackgroundImage")));
            this.btnClear.ButtonText = "Clear";
            this.btnClear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClear.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.ForeColor = System.Drawing.Color.Red;
            this.btnClear.IdleBorderThickness = 1;
            this.btnClear.IdleCornerRadius = 1;
            this.btnClear.IdleFillColor = System.Drawing.Color.White;
            this.btnClear.IdleForecolor = System.Drawing.Color.DodgerBlue;
            this.btnClear.IdleLineColor = System.Drawing.Color.DodgerBlue;
            this.btnClear.Location = new System.Drawing.Point(28, 209);
            this.btnClear.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 45);
            this.btnClear.TabIndex = 9;
            this.btnClear.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnEditStock
            // 
            this.btnEditStock.ActiveBorderThickness = 1;
            this.btnEditStock.ActiveCornerRadius = 1;
            this.btnEditStock.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnEditStock.ActiveForecolor = System.Drawing.Color.White;
            this.btnEditStock.ActiveLineColor = System.Drawing.Color.DodgerBlue;
            this.btnEditStock.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnEditStock.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnEditStock.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnEditStock.BackgroundImage")));
            this.btnEditStock.ButtonText = "Update ";
            this.btnEditStock.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEditStock.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditStock.ForeColor = System.Drawing.Color.DodgerBlue;
            this.btnEditStock.IdleBorderThickness = 1;
            this.btnEditStock.IdleCornerRadius = 1;
            this.btnEditStock.IdleFillColor = System.Drawing.Color.White;
            this.btnEditStock.IdleForecolor = System.Drawing.Color.DodgerBlue;
            this.btnEditStock.IdleLineColor = System.Drawing.Color.DodgerBlue;
            this.btnEditStock.Location = new System.Drawing.Point(110, 209);
            this.btnEditStock.Margin = new System.Windows.Forms.Padding(4);
            this.btnEditStock.Name = "btnEditStock";
            this.btnEditStock.Size = new System.Drawing.Size(95, 45);
            this.btnEditStock.TabIndex = 8;
            this.btnEditStock.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnEditStock.Click += new System.EventHandler(this.btnEditStock_Click);
            // 
            // txtQuantity
            // 
            this.txtQuantity.AcceptsReturn = false;
            this.txtQuantity.AcceptsTab = false;
            this.txtQuantity.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtQuantity.AnimationSpeed = 200;
            this.txtQuantity.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtQuantity.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtQuantity.BackColor = System.Drawing.Color.Transparent;
            this.txtQuantity.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtQuantity.BackgroundImage")));
            this.txtQuantity.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtQuantity.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.txtQuantity.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtQuantity.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtQuantity.BorderRadius = 1;
            this.txtQuantity.BorderThickness = 1;
            this.txtQuantity.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtQuantity.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtQuantity.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 10F);
            this.txtQuantity.DefaultText = "";
            this.txtQuantity.FillColor = System.Drawing.Color.White;
            this.txtQuantity.HideSelection = true;
            this.txtQuantity.IconLeft = null;
            this.txtQuantity.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtQuantity.IconPadding = 10;
            this.txtQuantity.IconRight = null;
            this.txtQuantity.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtQuantity.Lines = new string[0];
            this.txtQuantity.Location = new System.Drawing.Point(59, 24);
            this.txtQuantity.MaxLength = 32767;
            this.txtQuantity.MinimumSize = new System.Drawing.Size(100, 35);
            this.txtQuantity.Modified = false;
            this.txtQuantity.Multiline = false;
            this.txtQuantity.Name = "txtQuantity";
            stateProperties1.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtQuantity.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.Empty;
            stateProperties2.FillColor = System.Drawing.Color.White;
            stateProperties2.ForeColor = System.Drawing.Color.Empty;
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtQuantity.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtQuantity.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.Silver;
            stateProperties4.FillColor = System.Drawing.Color.White;
            stateProperties4.ForeColor = System.Drawing.Color.Empty;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtQuantity.OnIdleState = stateProperties4;
            this.txtQuantity.PasswordChar = '\0';
            this.txtQuantity.PlaceholderForeColor = System.Drawing.Color.DimGray;
            this.txtQuantity.PlaceholderText = "Quantity";
            this.txtQuantity.ReadOnly = false;
            this.txtQuantity.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtQuantity.SelectedText = "";
            this.txtQuantity.SelectionLength = 0;
            this.txtQuantity.SelectionStart = 0;
            this.txtQuantity.ShortcutsEnabled = true;
            this.txtQuantity.Size = new System.Drawing.Size(113, 35);
            this.txtQuantity.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtQuantity.TabIndex = 5;
            this.txtQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtQuantity.TextMarginBottom = 0;
            this.txtQuantity.TextMarginLeft = 5;
            this.txtQuantity.TextMarginTop = 0;
            this.txtQuantity.TextPlaceholder = "Quantity";
            this.txtQuantity.UseSystemPasswordChar = false;
            this.txtQuantity.WordWrap = true;
            this.txtQuantity.TextChange += new System.EventHandler(this.txtQuantity_TextChange);
            this.txtQuantity.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtQuantity_KeyDown);
            // 
            // txtSalePrice
            // 
            this.txtSalePrice.AcceptsReturn = false;
            this.txtSalePrice.AcceptsTab = false;
            this.txtSalePrice.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtSalePrice.AnimationSpeed = 200;
            this.txtSalePrice.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSalePrice.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSalePrice.BackColor = System.Drawing.Color.Transparent;
            this.txtSalePrice.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtSalePrice.BackgroundImage")));
            this.txtSalePrice.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtSalePrice.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.txtSalePrice.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtSalePrice.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtSalePrice.BorderRadius = 1;
            this.txtSalePrice.BorderThickness = 1;
            this.txtSalePrice.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSalePrice.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSalePrice.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 10F);
            this.txtSalePrice.DefaultText = "";
            this.txtSalePrice.FillColor = System.Drawing.Color.White;
            this.txtSalePrice.HideSelection = true;
            this.txtSalePrice.IconLeft = null;
            this.txtSalePrice.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSalePrice.IconPadding = 10;
            this.txtSalePrice.IconRight = null;
            this.txtSalePrice.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSalePrice.Lines = new string[0];
            this.txtSalePrice.Location = new System.Drawing.Point(59, 130);
            this.txtSalePrice.MaxLength = 32767;
            this.txtSalePrice.MinimumSize = new System.Drawing.Size(100, 35);
            this.txtSalePrice.Modified = false;
            this.txtSalePrice.Multiline = false;
            this.txtSalePrice.Name = "txtSalePrice";
            stateProperties5.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtSalePrice.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.Empty;
            stateProperties6.FillColor = System.Drawing.Color.White;
            stateProperties6.ForeColor = System.Drawing.Color.Empty;
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtSalePrice.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtSalePrice.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.Silver;
            stateProperties8.FillColor = System.Drawing.Color.White;
            stateProperties8.ForeColor = System.Drawing.Color.Empty;
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtSalePrice.OnIdleState = stateProperties8;
            this.txtSalePrice.PasswordChar = '\0';
            this.txtSalePrice.PlaceholderForeColor = System.Drawing.Color.DimGray;
            this.txtSalePrice.PlaceholderText = "Sale Price";
            this.txtSalePrice.ReadOnly = false;
            this.txtSalePrice.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtSalePrice.SelectedText = "";
            this.txtSalePrice.SelectionLength = 0;
            this.txtSalePrice.SelectionStart = 0;
            this.txtSalePrice.ShortcutsEnabled = true;
            this.txtSalePrice.Size = new System.Drawing.Size(113, 35);
            this.txtSalePrice.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtSalePrice.TabIndex = 7;
            this.txtSalePrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtSalePrice.TextMarginBottom = 0;
            this.txtSalePrice.TextMarginLeft = 5;
            this.txtSalePrice.TextMarginTop = 0;
            this.txtSalePrice.TextPlaceholder = "Sale Price";
            this.txtSalePrice.UseSystemPasswordChar = false;
            this.txtSalePrice.WordWrap = true;
            this.txtSalePrice.TextChanged += new System.EventHandler(this.txtSalePrice_TextChanged);
            this.txtSalePrice.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSalePrice_KeyDown);
            // 
            // txtBuyingPrice
            // 
            this.txtBuyingPrice.AcceptsReturn = false;
            this.txtBuyingPrice.AcceptsTab = false;
            this.txtBuyingPrice.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtBuyingPrice.AnimationSpeed = 200;
            this.txtBuyingPrice.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtBuyingPrice.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtBuyingPrice.BackColor = System.Drawing.Color.Transparent;
            this.txtBuyingPrice.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtBuyingPrice.BackgroundImage")));
            this.txtBuyingPrice.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtBuyingPrice.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.txtBuyingPrice.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtBuyingPrice.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtBuyingPrice.BorderRadius = 1;
            this.txtBuyingPrice.BorderThickness = 1;
            this.txtBuyingPrice.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtBuyingPrice.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtBuyingPrice.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 10F);
            this.txtBuyingPrice.DefaultText = "";
            this.txtBuyingPrice.FillColor = System.Drawing.Color.White;
            this.txtBuyingPrice.HideSelection = true;
            this.txtBuyingPrice.IconLeft = null;
            this.txtBuyingPrice.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtBuyingPrice.IconPadding = 10;
            this.txtBuyingPrice.IconRight = null;
            this.txtBuyingPrice.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtBuyingPrice.Lines = new string[0];
            this.txtBuyingPrice.Location = new System.Drawing.Point(59, 77);
            this.txtBuyingPrice.MaxLength = 32767;
            this.txtBuyingPrice.MinimumSize = new System.Drawing.Size(100, 35);
            this.txtBuyingPrice.Modified = false;
            this.txtBuyingPrice.Multiline = false;
            this.txtBuyingPrice.Name = "txtBuyingPrice";
            stateProperties9.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties9.FillColor = System.Drawing.Color.Empty;
            stateProperties9.ForeColor = System.Drawing.Color.Empty;
            stateProperties9.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtBuyingPrice.OnActiveState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.Empty;
            stateProperties10.FillColor = System.Drawing.Color.White;
            stateProperties10.ForeColor = System.Drawing.Color.Empty;
            stateProperties10.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtBuyingPrice.OnDisabledState = stateProperties10;
            stateProperties11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties11.FillColor = System.Drawing.Color.Empty;
            stateProperties11.ForeColor = System.Drawing.Color.Empty;
            stateProperties11.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtBuyingPrice.OnHoverState = stateProperties11;
            stateProperties12.BorderColor = System.Drawing.Color.Silver;
            stateProperties12.FillColor = System.Drawing.Color.White;
            stateProperties12.ForeColor = System.Drawing.Color.Empty;
            stateProperties12.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtBuyingPrice.OnIdleState = stateProperties12;
            this.txtBuyingPrice.PasswordChar = '\0';
            this.txtBuyingPrice.PlaceholderForeColor = System.Drawing.Color.DimGray;
            this.txtBuyingPrice.PlaceholderText = "Buying Price";
            this.txtBuyingPrice.ReadOnly = false;
            this.txtBuyingPrice.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtBuyingPrice.SelectedText = "";
            this.txtBuyingPrice.SelectionLength = 0;
            this.txtBuyingPrice.SelectionStart = 0;
            this.txtBuyingPrice.ShortcutsEnabled = true;
            this.txtBuyingPrice.Size = new System.Drawing.Size(113, 35);
            this.txtBuyingPrice.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtBuyingPrice.TabIndex = 6;
            this.txtBuyingPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtBuyingPrice.TextMarginBottom = 0;
            this.txtBuyingPrice.TextMarginLeft = 5;
            this.txtBuyingPrice.TextMarginTop = 0;
            this.txtBuyingPrice.TextPlaceholder = "Buying Price";
            this.txtBuyingPrice.UseSystemPasswordChar = false;
            this.txtBuyingPrice.WordWrap = true;
            this.txtBuyingPrice.TextChange += new System.EventHandler(this.txtBuyingPrice_TextChange);
            this.txtBuyingPrice.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtBuyingPrice_KeyDown);
            // 
            // pnlAddStockInfo
            // 
            this.pnlAddStockInfo.Controls.Add(this.txtLSalePrice);
            this.pnlAddStockInfo.Controls.Add(this.txtLPPrice);
            this.pnlAddStockInfo.Controls.Add(this.txtLQun);
            this.pnlAddStockInfo.Controls.Add(this.bunifuLabel5);
            this.pnlAddStockInfo.Controls.Add(this.bunifuLabel6);
            this.pnlAddStockInfo.Controls.Add(this.bunifuLabel4);
            this.pnlAddStockInfo.Controls.Add(this.bunifuLabel3);
            this.pnlAddStockInfo.Controls.Add(this.bunifuLabel2);
            this.pnlAddStockInfo.Controls.Add(this.txtCurentStock);
            this.pnlAddStockInfo.Controls.Add(this.txtLDate);
            this.pnlAddStockInfo.Controls.Add(this.bunifuLabel1);
            this.pnlAddStockInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlAddStockInfo.Location = new System.Drawing.Point(247, -2);
            this.pnlAddStockInfo.Name = "pnlAddStockInfo";
            this.pnlAddStockInfo.Size = new System.Drawing.Size(234, 394);
            this.pnlAddStockInfo.TabIndex = 10;
            // 
            // txtLSalePrice
            // 
            this.txtLSalePrice.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtLSalePrice.BorderColor = System.Drawing.Color.SeaGreen;
            this.txtLSalePrice.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLSalePrice.Location = new System.Drawing.Point(128, 142);
            this.txtLSalePrice.Name = "txtLSalePrice";
            this.txtLSalePrice.ReadOnly = true;
            this.txtLSalePrice.Size = new System.Drawing.Size(62, 25);
            this.txtLSalePrice.TabIndex = 26;
            this.txtLSalePrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtLPPrice
            // 
            this.txtLPPrice.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtLPPrice.BorderColor = System.Drawing.Color.SeaGreen;
            this.txtLPPrice.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLPPrice.Location = new System.Drawing.Point(128, 110);
            this.txtLPPrice.Name = "txtLPPrice";
            this.txtLPPrice.ReadOnly = true;
            this.txtLPPrice.Size = new System.Drawing.Size(62, 25);
            this.txtLPPrice.TabIndex = 25;
            this.txtLPPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtLQun
            // 
            this.txtLQun.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtLQun.BorderColor = System.Drawing.Color.SeaGreen;
            this.txtLQun.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLQun.Location = new System.Drawing.Point(128, 78);
            this.txtLQun.Name = "txtLQun";
            this.txtLQun.ReadOnly = true;
            this.txtLQun.Size = new System.Drawing.Size(62, 25);
            this.txtLQun.TabIndex = 24;
            this.txtLQun.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bunifuLabel5
            // 
            this.bunifuLabel5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuLabel5.AutoEllipsis = false;
            this.bunifuLabel5.CursorType = null;
            this.bunifuLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel5.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel5.Location = new System.Drawing.Point(35, 146);
            this.bunifuLabel5.Name = "bunifuLabel5";
            this.bunifuLabel5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel5.Size = new System.Drawing.Size(68, 18);
            this.bunifuLabel5.TabIndex = 23;
            this.bunifuLabel5.Text = "Sale Price:";
            this.bunifuLabel5.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel5.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel6
            // 
            this.bunifuLabel6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuLabel6.AutoEllipsis = false;
            this.bunifuLabel6.CursorType = null;
            this.bunifuLabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel6.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel6.Location = new System.Drawing.Point(35, 114);
            this.bunifuLabel6.Name = "bunifuLabel6";
            this.bunifuLabel6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel6.Size = new System.Drawing.Size(81, 18);
            this.bunifuLabel6.TabIndex = 22;
            this.bunifuLabel6.Text = "Buying Price:";
            this.bunifuLabel6.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel6.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel4
            // 
            this.bunifuLabel4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuLabel4.AutoEllipsis = false;
            this.bunifuLabel4.CursorType = null;
            this.bunifuLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel4.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel4.Location = new System.Drawing.Point(35, 82);
            this.bunifuLabel4.Name = "bunifuLabel4";
            this.bunifuLabel4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel4.Size = new System.Drawing.Size(54, 18);
            this.bunifuLabel4.TabIndex = 21;
            this.bunifuLabel4.Text = "Quantity:";
            this.bunifuLabel4.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel4.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel3
            // 
            this.bunifuLabel3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuLabel3.AutoEllipsis = false;
            this.bunifuLabel3.CursorType = null;
            this.bunifuLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel3.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel3.Location = new System.Drawing.Point(35, 50);
            this.bunifuLabel3.Name = "bunifuLabel3";
            this.bunifuLabel3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel3.Size = new System.Drawing.Size(35, 18);
            this.bunifuLabel3.TabIndex = 20;
            this.bunifuLabel3.Text = "Date:";
            this.bunifuLabel3.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel3.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel2
            // 
            this.bunifuLabel2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuLabel2.AutoEllipsis = false;
            this.bunifuLabel2.CursorType = null;
            this.bunifuLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel2.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel2.Location = new System.Drawing.Point(63, 194);
            this.bunifuLabel2.Name = "bunifuLabel2";
            this.bunifuLabel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel2.Size = new System.Drawing.Size(111, 18);
            this.bunifuLabel2.TabIndex = 19;
            this.bunifuLabel2.Text = "Available Quantity";
            this.bunifuLabel2.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel2.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // txtCurentStock
            // 
            this.txtCurentStock.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtCurentStock.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtCurentStock.BorderColor = System.Drawing.Color.SeaGreen;
            this.txtCurentStock.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCurentStock.Location = new System.Drawing.Point(80, 218);
            this.txtCurentStock.Name = "txtCurentStock";
            this.txtCurentStock.ReadOnly = true;
            this.txtCurentStock.Size = new System.Drawing.Size(77, 25);
            this.txtCurentStock.TabIndex = 18;
            this.txtCurentStock.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtLDate
            // 
            this.txtLDate.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtLDate.BorderColor = System.Drawing.Color.SeaGreen;
            this.txtLDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLDate.Location = new System.Drawing.Point(89, 48);
            this.txtLDate.Name = "txtLDate";
            this.txtLDate.ReadOnly = true;
            this.txtLDate.Size = new System.Drawing.Size(101, 23);
            this.txtLDate.TabIndex = 17;
            this.txtLDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bunifuLabel1
            // 
            this.bunifuLabel1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuLabel1.AutoEllipsis = false;
            this.bunifuLabel1.CursorType = null;
            this.bunifuLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel1.Location = new System.Drawing.Point(35, 9);
            this.bunifuLabel1.Name = "bunifuLabel1";
            this.bunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel1.Size = new System.Drawing.Size(164, 22);
            this.bunifuLabel1.TabIndex = 16;
            this.bunifuLabel1.Text = "Last Stock Inforamtion";
            this.bunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel1.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // lblTitle
            // 
            this.lblTitle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(187, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(176, 67);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "EDIT STOCK";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frmEditStocks
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.ClientSize = new System.Drawing.Size(550, 450);
            this.Controls.Add(this.tblLyPnlMain);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmEditStocks";
            this.Text = "frmEditStocks";
            this.tblLyPnlMain.ResumeLayout(false);
            this.tblLyPnlMain.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.pnlAddStockTools.ResumeLayout(false);
            this.pnlAddStockInfo.ResumeLayout(false);
            this.pnlAddStockInfo.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tblLyPnlMain;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.ComboBox cmbProductCtg;
        private System.Windows.Forms.ComboBox cmbProductName;
        private System.Windows.Forms.ComboBox cmbProductSize;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Panel pnlAddStockTools;
        private Bunifu.Framework.UI.BunifuThinButton2 btnClear;
        private Bunifu.Framework.UI.BunifuThinButton2 btnEditStock;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtQuantity;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtSalePrice;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtBuyingPrice;
        private System.Windows.Forms.Panel pnlAddStockInfo;
        private Bunifu.Framework.BunifuCustomTextbox txtLSalePrice;
        private Bunifu.Framework.BunifuCustomTextbox txtLPPrice;
        private Bunifu.Framework.BunifuCustomTextbox txtLQun;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel5;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel6;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel4;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel3;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel2;
        private Bunifu.Framework.BunifuCustomTextbox txtCurentStock;
        private Bunifu.Framework.BunifuCustomTextbox txtLDate;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel1;
        private Bunifu.Framework.UI.BunifuCustomLabel lblTitle;
    }
}