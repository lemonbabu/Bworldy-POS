﻿
namespace ERP
{
    partial class frmNewSale
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmNewSale));
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties25 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties26 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties27 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties28 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties29 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties30 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties31 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties32 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties33 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties34 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties35 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties36 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges3 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties37 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties38 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges4 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties39 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties40 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties41 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties42 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties43 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties44 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties45 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties46 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties47 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties48 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource2 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.tblLyPnlMain = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tblPnlCustomer = new System.Windows.Forms.TableLayoutPanel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.bunifuCustomLabel10 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel9 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel6 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtCustomerName = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.txtCustomerPhone = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.txtCusAddress = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.btnBack = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.panel6 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtInTotal = new System.Windows.Forms.TextBox();
            this.bunifuCustomLabel18 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtOverallDiscount = new System.Windows.Forms.TextBox();
            this.bunifuCustomLabel17 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.cmbPayMethod = new System.Windows.Forms.ComboBox();
            this.bunifuCustomLabel15 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtDue = new System.Windows.Forms.TextBox();
            this.bunifuCustomLabel12 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtPayment = new System.Windows.Forms.TextBox();
            this.bunifuCustomLabel14 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtDiscount = new System.Windows.Forms.TextBox();
            this.bunifuCustomLabel11 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtTotalAmount = new System.Windows.Forms.TextBox();
            this.bunifuCustomLabel13 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.btnSaleConfirm = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.tblPnlSales = new System.Windows.Forms.TableLayoutPanel();
            this.pnlCntSales = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.pnlProductDetails = new System.Windows.Forms.Panel();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblStock = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel8 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lblDiscount = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel7 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lblPdcDetails = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lblPdcSize = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lblPdcName = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lblCtgName = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lblSalePrice = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel5 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel3 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel4 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.pnlDatagridView = new System.Windows.Forms.Panel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.btnCheckOut = new Bunifu.Framework.UI.BunifuFlatButton();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dataGridViewSale = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.barcodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ctgNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pSizeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantityDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unitPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.discountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.subTotalDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Remove = new System.Windows.Forms.DataGridViewButtonColumn();
            this.tblTempSaleBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mainDataSet = new ERP.mainDataSet();
            this.panel4 = new System.Windows.Forms.Panel();
            this.bunifuLabel1 = new Bunifu.UI.WinForms.BunifuLabel();
            this.txtTotal = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.pnlBarcdeReader = new System.Windows.Forms.Panel();
            this.btnAddCart = new Bunifu.Framework.UI.BunifuFlatButton();
            this.txtBarcode = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.lblTitle = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.tblTempSaleTableAdapter = new ERP.mainDataSetTableAdapters.tblTempSaleTableAdapter();
            this.pnlPrinting = new System.Windows.Forms.Panel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.bunifuCustomLabel16 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.tblLyPnlMain.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tblPnlCustomer.SuspendLayout();
            this.panel5.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel7.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel6.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tblPnlSales.SuspendLayout();
            this.pnlCntSales.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.pnlProductDetails.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.panel2.SuspendLayout();
            this.pnlDatagridView.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSale)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblTempSaleBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mainDataSet)).BeginInit();
            this.panel4.SuspendLayout();
            this.pnlBarcdeReader.SuspendLayout();
            this.pnlPrinting.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.panel8.SuspendLayout();
            this.SuspendLayout();
            // 
            // tblLyPnlMain
            // 
            this.tblLyPnlMain.ColumnCount = 1;
            this.tblLyPnlMain.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblLyPnlMain.Controls.Add(this.panel1, 0, 1);
            this.tblLyPnlMain.Controls.Add(this.lblTitle, 0, 0);
            this.tblLyPnlMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblLyPnlMain.ForeColor = System.Drawing.Color.Black;
            this.tblLyPnlMain.Location = new System.Drawing.Point(0, 0);
            this.tblLyPnlMain.Name = "tblLyPnlMain";
            this.tblLyPnlMain.RowCount = 2;
            this.tblLyPnlMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tblLyPnlMain.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tblLyPnlMain.Size = new System.Drawing.Size(550, 450);
            this.tblLyPnlMain.TabIndex = 11;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tblPnlSales);
            this.panel1.Controls.Add(this.tblPnlCustomer);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 48);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(544, 399);
            this.panel1.TabIndex = 0;
            // 
            // tblPnlCustomer
            // 
            this.tblPnlCustomer.ColumnCount = 3;
            this.tblPnlCustomer.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tblPnlCustomer.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tblPnlCustomer.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tblPnlCustomer.Controls.Add(this.panel5, 1, 1);
            this.tblPnlCustomer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblPnlCustomer.Location = new System.Drawing.Point(0, 0);
            this.tblPnlCustomer.Name = "tblPnlCustomer";
            this.tblPnlCustomer.RowCount = 3;
            this.tblPnlCustomer.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2F));
            this.tblPnlCustomer.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 96F));
            this.tblPnlCustomer.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2F));
            this.tblPnlCustomer.Size = new System.Drawing.Size(544, 399);
            this.tblPnlCustomer.TabIndex = 8;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.tableLayoutPanel1);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(30, 10);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(483, 377);
            this.panel5.TabIndex = 0;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.panel7, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel6, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 377F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(483, 377);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.groupBox1);
            this.panel7.Controls.Add(this.btnBack);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(3, 3);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(235, 371);
            this.panel7.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.bunifuCustomLabel10);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel9);
            this.groupBox1.Controls.Add(this.bunifuCustomLabel6);
            this.groupBox1.Controls.Add(this.txtCustomerName);
            this.groupBox1.Controls.Add(this.txtCustomerPhone);
            this.groupBox1.Controls.Add(this.txtCusAddress);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(0, 13);
            this.groupBox1.MaximumSize = new System.Drawing.Size(300, 300);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(232, 295);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Customer Inforamtions";
            // 
            // bunifuCustomLabel10
            // 
            this.bunifuCustomLabel10.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuCustomLabel10.AutoSize = true;
            this.bunifuCustomLabel10.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel10.Location = new System.Drawing.Point(1, 169);
            this.bunifuCustomLabel10.Name = "bunifuCustomLabel10";
            this.bunifuCustomLabel10.Size = new System.Drawing.Size(65, 19);
            this.bunifuCustomLabel10.TabIndex = 3;
            this.bunifuCustomLabel10.Text = "Address :";
            // 
            // bunifuCustomLabel9
            // 
            this.bunifuCustomLabel9.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuCustomLabel9.AutoSize = true;
            this.bunifuCustomLabel9.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel9.Location = new System.Drawing.Point(11, 113);
            this.bunifuCustomLabel9.Name = "bunifuCustomLabel9";
            this.bunifuCustomLabel9.Size = new System.Drawing.Size(55, 19);
            this.bunifuCustomLabel9.TabIndex = 3;
            this.bunifuCustomLabel9.Text = "Phone :";
            // 
            // bunifuCustomLabel6
            // 
            this.bunifuCustomLabel6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuCustomLabel6.AutoSize = true;
            this.bunifuCustomLabel6.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel6.Location = new System.Drawing.Point(14, 57);
            this.bunifuCustomLabel6.Name = "bunifuCustomLabel6";
            this.bunifuCustomLabel6.Size = new System.Drawing.Size(52, 19);
            this.bunifuCustomLabel6.TabIndex = 3;
            this.bunifuCustomLabel6.Text = "Name :";
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.AcceptsReturn = false;
            this.txtCustomerName.AcceptsTab = false;
            this.txtCustomerName.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtCustomerName.AnimationSpeed = 200;
            this.txtCustomerName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtCustomerName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtCustomerName.BackColor = System.Drawing.Color.Transparent;
            this.txtCustomerName.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtCustomerName.BackgroundImage")));
            this.txtCustomerName.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtCustomerName.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.txtCustomerName.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtCustomerName.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtCustomerName.BorderRadius = 1;
            this.txtCustomerName.BorderThickness = 1;
            this.txtCustomerName.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtCustomerName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCustomerName.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.txtCustomerName.DefaultText = "";
            this.txtCustomerName.FillColor = System.Drawing.Color.White;
            this.txtCustomerName.ForeColor = System.Drawing.Color.Black;
            this.txtCustomerName.HideSelection = true;
            this.txtCustomerName.IconLeft = null;
            this.txtCustomerName.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCustomerName.IconPadding = 10;
            this.txtCustomerName.IconRight = null;
            this.txtCustomerName.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCustomerName.Lines = new string[0];
            this.txtCustomerName.Location = new System.Drawing.Point(72, 52);
            this.txtCustomerName.MaxLength = 32767;
            this.txtCustomerName.MinimumSize = new System.Drawing.Size(100, 35);
            this.txtCustomerName.Modified = false;
            this.txtCustomerName.Multiline = false;
            this.txtCustomerName.Name = "txtCustomerName";
            stateProperties25.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties25.FillColor = System.Drawing.Color.Empty;
            stateProperties25.ForeColor = System.Drawing.Color.Empty;
            stateProperties25.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtCustomerName.OnActiveState = stateProperties25;
            stateProperties26.BorderColor = System.Drawing.Color.Empty;
            stateProperties26.FillColor = System.Drawing.Color.White;
            stateProperties26.ForeColor = System.Drawing.Color.Empty;
            stateProperties26.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtCustomerName.OnDisabledState = stateProperties26;
            stateProperties27.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties27.FillColor = System.Drawing.Color.Empty;
            stateProperties27.ForeColor = System.Drawing.Color.Empty;
            stateProperties27.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtCustomerName.OnHoverState = stateProperties27;
            stateProperties28.BorderColor = System.Drawing.Color.Silver;
            stateProperties28.FillColor = System.Drawing.Color.White;
            stateProperties28.ForeColor = System.Drawing.Color.Black;
            stateProperties28.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtCustomerName.OnIdleState = stateProperties28;
            this.txtCustomerName.PasswordChar = '\0';
            this.txtCustomerName.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtCustomerName.PlaceholderText = "Mr. Jon";
            this.txtCustomerName.ReadOnly = false;
            this.txtCustomerName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCustomerName.SelectedText = "";
            this.txtCustomerName.SelectionLength = 0;
            this.txtCustomerName.SelectionStart = 0;
            this.txtCustomerName.ShortcutsEnabled = true;
            this.txtCustomerName.Size = new System.Drawing.Size(150, 35);
            this.txtCustomerName.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtCustomerName.TabIndex = 0;
            this.txtCustomerName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCustomerName.TextMarginBottom = 0;
            this.txtCustomerName.TextMarginLeft = 0;
            this.txtCustomerName.TextMarginTop = 0;
            this.txtCustomerName.TextPlaceholder = "Mr. Jon";
            this.txtCustomerName.UseSystemPasswordChar = false;
            this.txtCustomerName.WordWrap = true;
            this.txtCustomerName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtCustomerName_KeyDown);
            // 
            // txtCustomerPhone
            // 
            this.txtCustomerPhone.AcceptsReturn = false;
            this.txtCustomerPhone.AcceptsTab = false;
            this.txtCustomerPhone.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtCustomerPhone.AnimationSpeed = 200;
            this.txtCustomerPhone.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtCustomerPhone.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtCustomerPhone.BackColor = System.Drawing.Color.White;
            this.txtCustomerPhone.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtCustomerPhone.BackgroundImage")));
            this.txtCustomerPhone.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtCustomerPhone.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.txtCustomerPhone.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtCustomerPhone.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtCustomerPhone.BorderRadius = 1;
            this.txtCustomerPhone.BorderThickness = 1;
            this.txtCustomerPhone.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtCustomerPhone.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCustomerPhone.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.txtCustomerPhone.DefaultText = "";
            this.txtCustomerPhone.FillColor = System.Drawing.Color.White;
            this.txtCustomerPhone.ForeColor = System.Drawing.Color.Black;
            this.txtCustomerPhone.HideSelection = true;
            this.txtCustomerPhone.IconLeft = null;
            this.txtCustomerPhone.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCustomerPhone.IconPadding = 10;
            this.txtCustomerPhone.IconRight = null;
            this.txtCustomerPhone.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCustomerPhone.Lines = new string[0];
            this.txtCustomerPhone.Location = new System.Drawing.Point(72, 105);
            this.txtCustomerPhone.MaxLength = 32767;
            this.txtCustomerPhone.MinimumSize = new System.Drawing.Size(100, 35);
            this.txtCustomerPhone.Modified = false;
            this.txtCustomerPhone.Multiline = false;
            this.txtCustomerPhone.Name = "txtCustomerPhone";
            stateProperties29.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties29.FillColor = System.Drawing.Color.Empty;
            stateProperties29.ForeColor = System.Drawing.Color.Empty;
            stateProperties29.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtCustomerPhone.OnActiveState = stateProperties29;
            stateProperties30.BorderColor = System.Drawing.Color.Empty;
            stateProperties30.FillColor = System.Drawing.Color.White;
            stateProperties30.ForeColor = System.Drawing.Color.Empty;
            stateProperties30.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtCustomerPhone.OnDisabledState = stateProperties30;
            stateProperties31.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties31.FillColor = System.Drawing.Color.Empty;
            stateProperties31.ForeColor = System.Drawing.Color.Empty;
            stateProperties31.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtCustomerPhone.OnHoverState = stateProperties31;
            stateProperties32.BorderColor = System.Drawing.Color.Silver;
            stateProperties32.FillColor = System.Drawing.Color.White;
            stateProperties32.ForeColor = System.Drawing.Color.Black;
            stateProperties32.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtCustomerPhone.OnIdleState = stateProperties32;
            this.txtCustomerPhone.PasswordChar = '\0';
            this.txtCustomerPhone.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtCustomerPhone.PlaceholderText = "01______";
            this.txtCustomerPhone.ReadOnly = false;
            this.txtCustomerPhone.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCustomerPhone.SelectedText = "";
            this.txtCustomerPhone.SelectionLength = 0;
            this.txtCustomerPhone.SelectionStart = 0;
            this.txtCustomerPhone.ShortcutsEnabled = true;
            this.txtCustomerPhone.Size = new System.Drawing.Size(150, 35);
            this.txtCustomerPhone.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtCustomerPhone.TabIndex = 1;
            this.txtCustomerPhone.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCustomerPhone.TextMarginBottom = 0;
            this.txtCustomerPhone.TextMarginLeft = 0;
            this.txtCustomerPhone.TextMarginTop = 0;
            this.txtCustomerPhone.TextPlaceholder = "01______";
            this.txtCustomerPhone.UseSystemPasswordChar = false;
            this.txtCustomerPhone.WordWrap = true;
            this.txtCustomerPhone.TextChanged += new System.EventHandler(this.txtCustomerPhone_TextChanged);
            this.txtCustomerPhone.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtCustomerPhone_KeyDown);
            // 
            // txtCusAddress
            // 
            this.txtCusAddress.AcceptsReturn = false;
            this.txtCusAddress.AcceptsTab = false;
            this.txtCusAddress.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtCusAddress.AnimationSpeed = 200;
            this.txtCusAddress.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtCusAddress.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtCusAddress.BackColor = System.Drawing.Color.Transparent;
            this.txtCusAddress.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtCusAddress.BackgroundImage")));
            this.txtCusAddress.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtCusAddress.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.txtCusAddress.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtCusAddress.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtCusAddress.BorderRadius = 1;
            this.txtCusAddress.BorderThickness = 1;
            this.txtCusAddress.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtCusAddress.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCusAddress.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.txtCusAddress.DefaultText = "";
            this.txtCusAddress.FillColor = System.Drawing.Color.White;
            this.txtCusAddress.ForeColor = System.Drawing.Color.Black;
            this.txtCusAddress.HideSelection = true;
            this.txtCusAddress.IconLeft = null;
            this.txtCusAddress.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCusAddress.IconPadding = 10;
            this.txtCusAddress.IconRight = null;
            this.txtCusAddress.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCusAddress.Lines = new string[0];
            this.txtCusAddress.Location = new System.Drawing.Point(72, 158);
            this.txtCusAddress.MaxLength = 32767;
            this.txtCusAddress.MinimumSize = new System.Drawing.Size(100, 35);
            this.txtCusAddress.Modified = false;
            this.txtCusAddress.Multiline = true;
            this.txtCusAddress.Name = "txtCusAddress";
            stateProperties33.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties33.FillColor = System.Drawing.Color.Empty;
            stateProperties33.ForeColor = System.Drawing.Color.Empty;
            stateProperties33.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtCusAddress.OnActiveState = stateProperties33;
            stateProperties34.BorderColor = System.Drawing.Color.Empty;
            stateProperties34.FillColor = System.Drawing.Color.White;
            stateProperties34.ForeColor = System.Drawing.Color.Empty;
            stateProperties34.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtCusAddress.OnDisabledState = stateProperties34;
            stateProperties35.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties35.FillColor = System.Drawing.Color.Empty;
            stateProperties35.ForeColor = System.Drawing.Color.Empty;
            stateProperties35.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtCusAddress.OnHoverState = stateProperties35;
            stateProperties36.BorderColor = System.Drawing.Color.Silver;
            stateProperties36.FillColor = System.Drawing.Color.White;
            stateProperties36.ForeColor = System.Drawing.Color.Black;
            stateProperties36.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtCusAddress.OnIdleState = stateProperties36;
            this.txtCusAddress.PasswordChar = '\0';
            this.txtCusAddress.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtCusAddress.PlaceholderText = "00/0B, Gazipur\r\nBangladesh\r\n";
            this.txtCusAddress.ReadOnly = false;
            this.txtCusAddress.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCusAddress.SelectedText = "";
            this.txtCusAddress.SelectionLength = 0;
            this.txtCusAddress.SelectionStart = 0;
            this.txtCusAddress.ShortcutsEnabled = true;
            this.txtCusAddress.Size = new System.Drawing.Size(150, 35);
            this.txtCusAddress.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtCusAddress.TabIndex = 2;
            this.txtCusAddress.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCusAddress.TextMarginBottom = 0;
            this.txtCusAddress.TextMarginLeft = 0;
            this.txtCusAddress.TextMarginTop = 0;
            this.txtCusAddress.TextPlaceholder = "00/0B, Gazipur\r\nBangladesh\r\n";
            this.txtCusAddress.UseSystemPasswordChar = false;
            this.txtCusAddress.WordWrap = true;
            this.txtCusAddress.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtCusAddress_KeyDown);
            // 
            // btnBack
            // 
            this.btnBack.AllowToggling = false;
            this.btnBack.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnBack.AnimationSpeed = 200;
            this.btnBack.AutoGenerateColors = false;
            this.btnBack.BackColor = System.Drawing.Color.Transparent;
            this.btnBack.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(0)))), ((int)(((byte)(10)))));
            this.btnBack.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBack.BackgroundImage")));
            this.btnBack.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnBack.ButtonText = "<< Back";
            this.btnBack.ButtonTextMarginLeft = 0;
            this.btnBack.ColorContrastOnClick = 45;
            this.btnBack.ColorContrastOnHover = 45;
            this.btnBack.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges3.BottomLeft = true;
            borderEdges3.BottomRight = true;
            borderEdges3.TopLeft = true;
            borderEdges3.TopRight = true;
            this.btnBack.CustomizableEdges = borderEdges3;
            this.btnBack.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnBack.DisabledBorderColor = System.Drawing.Color.Empty;
            this.btnBack.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnBack.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnBack.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnBack.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.btnBack.ForeColor = System.Drawing.Color.White;
            this.btnBack.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.btnBack.IconMarginLeft = 11;
            this.btnBack.IconPadding = 10;
            this.btnBack.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.btnBack.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.btnBack.IdleBorderRadius = 3;
            this.btnBack.IdleBorderThickness = 1;
            this.btnBack.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(0)))), ((int)(((byte)(10)))));
            this.btnBack.IdleIconLeftImage = null;
            this.btnBack.IdleIconRightImage = null;
            this.btnBack.IndicateFocus = false;
            this.btnBack.Location = new System.Drawing.Point(82, 314);
            this.btnBack.Name = "btnBack";
            stateProperties37.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties37.BorderRadius = 3;
            stateProperties37.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties37.BorderThickness = 1;
            stateProperties37.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties37.ForeColor = System.Drawing.Color.White;
            stateProperties37.IconLeftImage = null;
            stateProperties37.IconRightImage = null;
            this.btnBack.onHoverState = stateProperties37;
            stateProperties38.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties38.BorderRadius = 3;
            stateProperties38.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties38.BorderThickness = 1;
            stateProperties38.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties38.ForeColor = System.Drawing.Color.White;
            stateProperties38.IconLeftImage = null;
            stateProperties38.IconRightImage = null;
            this.btnBack.OnPressedState = stateProperties38;
            this.btnBack.Size = new System.Drawing.Size(80, 40);
            this.btnBack.TabIndex = 11;
            this.btnBack.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnBack.TextMarginLeft = 0;
            this.btnBack.UseDefaultRadiusAndThickness = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.groupBox2);
            this.panel6.Controls.Add(this.btnSaleConfirm);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(244, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(236, 371);
            this.panel6.TabIndex = 0;
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.txtInTotal);
            this.groupBox2.Controls.Add(this.bunifuCustomLabel18);
            this.groupBox2.Controls.Add(this.txtOverallDiscount);
            this.groupBox2.Controls.Add(this.bunifuCustomLabel17);
            this.groupBox2.Controls.Add(this.cmbPayMethod);
            this.groupBox2.Controls.Add(this.bunifuCustomLabel15);
            this.groupBox2.Controls.Add(this.txtDue);
            this.groupBox2.Controls.Add(this.bunifuCustomLabel12);
            this.groupBox2.Controls.Add(this.txtPayment);
            this.groupBox2.Controls.Add(this.bunifuCustomLabel14);
            this.groupBox2.Controls.Add(this.txtDiscount);
            this.groupBox2.Controls.Add(this.bunifuCustomLabel11);
            this.groupBox2.Controls.Add(this.txtTotalAmount);
            this.groupBox2.Controls.Add(this.bunifuCustomLabel13);
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(3, 13);
            this.groupBox2.MaximumSize = new System.Drawing.Size(300, 300);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(230, 295);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Bill Inforamtions";
            // 
            // txtInTotal
            // 
            this.txtInTotal.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtInTotal.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.txtInTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtInTotal.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInTotal.ForeColor = System.Drawing.SystemColors.Control;
            this.txtInTotal.Location = new System.Drawing.Point(133, 19);
            this.txtInTotal.Name = "txtInTotal";
            this.txtInTotal.ReadOnly = true;
            this.txtInTotal.Size = new System.Drawing.Size(78, 25);
            this.txtInTotal.TabIndex = 17;
            this.txtInTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bunifuCustomLabel18
            // 
            this.bunifuCustomLabel18.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuCustomLabel18.AutoSize = true;
            this.bunifuCustomLabel18.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel18.Location = new System.Drawing.Point(65, 21);
            this.bunifuCustomLabel18.Name = "bunifuCustomLabel18";
            this.bunifuCustomLabel18.Size = new System.Drawing.Size(45, 19);
            this.bunifuCustomLabel18.TabIndex = 16;
            this.bunifuCustomLabel18.Text = "Total :";
            this.bunifuCustomLabel18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtOverallDiscount
            // 
            this.txtOverallDiscount.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtOverallDiscount.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOverallDiscount.ForeColor = System.Drawing.Color.Black;
            this.txtOverallDiscount.Location = new System.Drawing.Point(133, 167);
            this.txtOverallDiscount.Name = "txtOverallDiscount";
            this.txtOverallDiscount.Size = new System.Drawing.Size(78, 25);
            this.txtOverallDiscount.TabIndex = 14;
            this.txtOverallDiscount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtOverallDiscount.TextChanged += new System.EventHandler(this.txtOverallDiscount_TextChanged);
            this.txtOverallDiscount.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtOverallDiscount_KeyDown);
            // 
            // bunifuCustomLabel17
            // 
            this.bunifuCustomLabel17.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuCustomLabel17.AutoSize = true;
            this.bunifuCustomLabel17.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel17.Location = new System.Drawing.Point(6, 171);
            this.bunifuCustomLabel17.Name = "bunifuCustomLabel17";
            this.bunifuCustomLabel17.Size = new System.Drawing.Size(104, 19);
            this.bunifuCustomLabel17.TabIndex = 15;
            this.bunifuCustomLabel17.Text = "Extra Discount :";
            this.bunifuCustomLabel17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cmbPayMethod
            // 
            this.cmbPayMethod.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cmbPayMethod.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPayMethod.FormattingEnabled = true;
            this.cmbPayMethod.ItemHeight = 15;
            this.cmbPayMethod.Items.AddRange(new object[] {
            "Cash",
            "bKash",
            "Rocket",
            "Nagad",
            "Sure Cash",
            "uCash",
            "Card",
            "Bank"});
            this.cmbPayMethod.Location = new System.Drawing.Point(133, 241);
            this.cmbPayMethod.Name = "cmbPayMethod";
            this.cmbPayMethod.Size = new System.Drawing.Size(78, 23);
            this.cmbPayMethod.TabIndex = 13;
            this.cmbPayMethod.Text = "Cash";
            // 
            // bunifuCustomLabel15
            // 
            this.bunifuCustomLabel15.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuCustomLabel15.AutoSize = true;
            this.bunifuCustomLabel15.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel15.Location = new System.Drawing.Point(19, 244);
            this.bunifuCustomLabel15.Name = "bunifuCustomLabel15";
            this.bunifuCustomLabel15.Size = new System.Drawing.Size(91, 19);
            this.bunifuCustomLabel15.TabIndex = 12;
            this.bunifuCustomLabel15.Text = "Pay Method :";
            this.bunifuCustomLabel15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtDue
            // 
            this.txtDue.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtDue.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.txtDue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDue.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDue.ForeColor = System.Drawing.SystemColors.Control;
            this.txtDue.Location = new System.Drawing.Point(133, 204);
            this.txtDue.Name = "txtDue";
            this.txtDue.ReadOnly = true;
            this.txtDue.Size = new System.Drawing.Size(78, 25);
            this.txtDue.TabIndex = 10;
            this.txtDue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bunifuCustomLabel12
            // 
            this.bunifuCustomLabel12.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuCustomLabel12.AutoSize = true;
            this.bunifuCustomLabel12.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel12.Location = new System.Drawing.Point(69, 208);
            this.bunifuCustomLabel12.Name = "bunifuCustomLabel12";
            this.bunifuCustomLabel12.Size = new System.Drawing.Size(41, 19);
            this.bunifuCustomLabel12.TabIndex = 9;
            this.bunifuCustomLabel12.Text = "Due :";
            this.bunifuCustomLabel12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtPayment
            // 
            this.txtPayment.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtPayment.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPayment.ForeColor = System.Drawing.Color.Black;
            this.txtPayment.Location = new System.Drawing.Point(133, 130);
            this.txtPayment.Name = "txtPayment";
            this.txtPayment.Size = new System.Drawing.Size(78, 25);
            this.txtPayment.TabIndex = 3;
            this.txtPayment.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtPayment.TextChanged += new System.EventHandler(this.txtPayment_TextChanged);
            this.txtPayment.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtPayment_KeyDown);
            // 
            // bunifuCustomLabel14
            // 
            this.bunifuCustomLabel14.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuCustomLabel14.AutoSize = true;
            this.bunifuCustomLabel14.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel14.Location = new System.Drawing.Point(40, 134);
            this.bunifuCustomLabel14.Name = "bunifuCustomLabel14";
            this.bunifuCustomLabel14.Size = new System.Drawing.Size(70, 19);
            this.bunifuCustomLabel14.TabIndex = 7;
            this.bunifuCustomLabel14.Text = "Payment :";
            this.bunifuCustomLabel14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtDiscount
            // 
            this.txtDiscount.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtDiscount.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.txtDiscount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtDiscount.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiscount.ForeColor = System.Drawing.SystemColors.Control;
            this.txtDiscount.Location = new System.Drawing.Point(133, 56);
            this.txtDiscount.Name = "txtDiscount";
            this.txtDiscount.ReadOnly = true;
            this.txtDiscount.Size = new System.Drawing.Size(78, 25);
            this.txtDiscount.TabIndex = 6;
            this.txtDiscount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bunifuCustomLabel11
            // 
            this.bunifuCustomLabel11.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuCustomLabel11.AutoSize = true;
            this.bunifuCustomLabel11.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel11.Location = new System.Drawing.Point(5, 59);
            this.bunifuCustomLabel11.Name = "bunifuCustomLabel11";
            this.bunifuCustomLabel11.Size = new System.Drawing.Size(105, 19);
            this.bunifuCustomLabel11.TabIndex = 5;
            this.bunifuCustomLabel11.Text = "Fixed Discount :";
            this.bunifuCustomLabel11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTotalAmount
            // 
            this.txtTotalAmount.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtTotalAmount.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.txtTotalAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTotalAmount.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalAmount.ForeColor = System.Drawing.SystemColors.Control;
            this.txtTotalAmount.Location = new System.Drawing.Point(133, 93);
            this.txtTotalAmount.Name = "txtTotalAmount";
            this.txtTotalAmount.ReadOnly = true;
            this.txtTotalAmount.Size = new System.Drawing.Size(78, 25);
            this.txtTotalAmount.TabIndex = 9;
            this.txtTotalAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bunifuCustomLabel13
            // 
            this.bunifuCustomLabel13.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuCustomLabel13.AutoSize = true;
            this.bunifuCustomLabel13.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel13.Location = new System.Drawing.Point(38, 96);
            this.bunifuCustomLabel13.Name = "bunifuCustomLabel13";
            this.bunifuCustomLabel13.Size = new System.Drawing.Size(72, 19);
            this.bunifuCustomLabel13.TabIndex = 3;
            this.bunifuCustomLabel13.Text = "Sub Total :";
            this.bunifuCustomLabel13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnSaleConfirm
            // 
            this.btnSaleConfirm.AllowToggling = false;
            this.btnSaleConfirm.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnSaleConfirm.AnimationSpeed = 200;
            this.btnSaleConfirm.AutoGenerateColors = false;
            this.btnSaleConfirm.BackColor = System.Drawing.Color.Transparent;
            this.btnSaleConfirm.BackColor1 = System.Drawing.Color.DodgerBlue;
            this.btnSaleConfirm.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSaleConfirm.BackgroundImage")));
            this.btnSaleConfirm.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnSaleConfirm.ButtonText = "Confirm";
            this.btnSaleConfirm.ButtonTextMarginLeft = 0;
            this.btnSaleConfirm.ColorContrastOnClick = 45;
            this.btnSaleConfirm.ColorContrastOnHover = 45;
            this.btnSaleConfirm.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges4.BottomLeft = true;
            borderEdges4.BottomRight = true;
            borderEdges4.TopLeft = true;
            borderEdges4.TopRight = true;
            this.btnSaleConfirm.CustomizableEdges = borderEdges4;
            this.btnSaleConfirm.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnSaleConfirm.DisabledBorderColor = System.Drawing.Color.Empty;
            this.btnSaleConfirm.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnSaleConfirm.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnSaleConfirm.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnSaleConfirm.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.btnSaleConfirm.ForeColor = System.Drawing.Color.White;
            this.btnSaleConfirm.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.btnSaleConfirm.IconMarginLeft = 11;
            this.btnSaleConfirm.IconPadding = 10;
            this.btnSaleConfirm.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.btnSaleConfirm.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.btnSaleConfirm.IdleBorderRadius = 3;
            this.btnSaleConfirm.IdleBorderThickness = 1;
            this.btnSaleConfirm.IdleFillColor = System.Drawing.Color.DodgerBlue;
            this.btnSaleConfirm.IdleIconLeftImage = null;
            this.btnSaleConfirm.IdleIconRightImage = null;
            this.btnSaleConfirm.IndicateFocus = false;
            this.btnSaleConfirm.Location = new System.Drawing.Point(62, 314);
            this.btnSaleConfirm.Name = "btnSaleConfirm";
            stateProperties39.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties39.BorderRadius = 3;
            stateProperties39.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties39.BorderThickness = 1;
            stateProperties39.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties39.ForeColor = System.Drawing.Color.White;
            stateProperties39.IconLeftImage = null;
            stateProperties39.IconRightImage = null;
            this.btnSaleConfirm.onHoverState = stateProperties39;
            stateProperties40.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties40.BorderRadius = 3;
            stateProperties40.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties40.BorderThickness = 1;
            stateProperties40.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties40.ForeColor = System.Drawing.Color.White;
            stateProperties40.IconLeftImage = null;
            stateProperties40.IconRightImage = null;
            this.btnSaleConfirm.OnPressedState = stateProperties40;
            this.btnSaleConfirm.Size = new System.Drawing.Size(110, 40);
            this.btnSaleConfirm.TabIndex = 4;
            this.btnSaleConfirm.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSaleConfirm.TextMarginLeft = 0;
            this.btnSaleConfirm.UseDefaultRadiusAndThickness = true;
            this.btnSaleConfirm.Click += new System.EventHandler(this.btnSaleConfirm_Click);
            // 
            // tblPnlSales
            // 
            this.tblPnlSales.ColumnCount = 3;
            this.tblPnlSales.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tblPnlSales.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tblPnlSales.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tblPnlSales.Controls.Add(this.pnlCntSales, 1, 1);
            this.tblPnlSales.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblPnlSales.Location = new System.Drawing.Point(0, 0);
            this.tblPnlSales.Name = "tblPnlSales";
            this.tblPnlSales.RowCount = 3;
            this.tblPnlSales.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 1F));
            this.tblPnlSales.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 97F));
            this.tblPnlSales.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 2F));
            this.tblPnlSales.Size = new System.Drawing.Size(544, 399);
            this.tblPnlSales.TabIndex = 7;
            // 
            // pnlCntSales
            // 
            this.pnlCntSales.Controls.Add(this.tableLayoutPanel2);
            this.pnlCntSales.Controls.Add(this.pnlBarcdeReader);
            this.pnlCntSales.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlCntSales.Location = new System.Drawing.Point(30, 6);
            this.pnlCntSales.Name = "pnlCntSales";
            this.pnlCntSales.Size = new System.Drawing.Size(483, 381);
            this.pnlCntSales.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 190F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Controls.Add(this.pnlProductDetails, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.pnlDatagridView, 1, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 70);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(483, 311);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // pnlProductDetails
            // 
            this.pnlProductDetails.Controls.Add(this.tableLayoutPanel5);
            this.pnlProductDetails.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlProductDetails.Location = new System.Drawing.Point(3, 3);
            this.pnlProductDetails.Name = "pnlProductDetails";
            this.pnlProductDetails.Size = new System.Drawing.Size(184, 305);
            this.pnlProductDetails.TabIndex = 0;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 1;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel5.Controls.Add(this.panel2, 0, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(184, 305);
            this.tableLayoutPanel5.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lblStock);
            this.panel2.Controls.Add(this.bunifuCustomLabel8);
            this.panel2.Controls.Add(this.lblDiscount);
            this.panel2.Controls.Add(this.bunifuCustomLabel7);
            this.panel2.Controls.Add(this.lblPdcDetails);
            this.panel2.Controls.Add(this.lblPdcSize);
            this.panel2.Controls.Add(this.lblPdcName);
            this.panel2.Controls.Add(this.lblCtgName);
            this.panel2.Controls.Add(this.lblSalePrice);
            this.panel2.Controls.Add(this.bunifuCustomLabel5);
            this.panel2.Controls.Add(this.bunifuCustomLabel3);
            this.panel2.Controls.Add(this.bunifuCustomLabel4);
            this.panel2.Controls.Add(this.bunifuCustomLabel2);
            this.panel2.Controls.Add(this.bunifuCustomLabel1);
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(194, 267);
            this.panel2.TabIndex = 0;
            // 
            // lblStock
            // 
            this.lblStock.AccessibleName = "lblDiscount";
            this.lblStock.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblStock.AutoSize = true;
            this.lblStock.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStock.ForeColor = System.Drawing.Color.Crimson;
            this.lblStock.Location = new System.Drawing.Point(88, 195);
            this.lblStock.Name = "lblStock";
            this.lblStock.Size = new System.Drawing.Size(19, 21);
            this.lblStock.TabIndex = 13;
            this.lblStock.Text = "0";
            this.lblStock.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // bunifuCustomLabel8
            // 
            this.bunifuCustomLabel8.AccessibleName = "lblDiscount";
            this.bunifuCustomLabel8.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuCustomLabel8.AutoSize = true;
            this.bunifuCustomLabel8.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel8.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel8.Location = new System.Drawing.Point(29, 195);
            this.bunifuCustomLabel8.Name = "bunifuCustomLabel8";
            this.bunifuCustomLabel8.Size = new System.Drawing.Size(54, 21);
            this.bunifuCustomLabel8.TabIndex = 12;
            this.bunifuCustomLabel8.Text = "Stock: ";
            this.bunifuCustomLabel8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblDiscount
            // 
            this.lblDiscount.AccessibleName = "lblDiscount";
            this.lblDiscount.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblDiscount.AutoSize = true;
            this.lblDiscount.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDiscount.ForeColor = System.Drawing.Color.LimeGreen;
            this.lblDiscount.Location = new System.Drawing.Point(88, 169);
            this.lblDiscount.Name = "lblDiscount";
            this.lblDiscount.Size = new System.Drawing.Size(19, 21);
            this.lblDiscount.TabIndex = 11;
            this.lblDiscount.Text = "0";
            this.lblDiscount.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // bunifuCustomLabel7
            // 
            this.bunifuCustomLabel7.AccessibleName = "lblDiscount";
            this.bunifuCustomLabel7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuCustomLabel7.AutoSize = true;
            this.bunifuCustomLabel7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel7.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel7.Location = new System.Drawing.Point(5, 169);
            this.bunifuCustomLabel7.Name = "bunifuCustomLabel7";
            this.bunifuCustomLabel7.Size = new System.Drawing.Size(78, 21);
            this.bunifuCustomLabel7.TabIndex = 10;
            this.bunifuCustomLabel7.Text = "Discount: ";
            this.bunifuCustomLabel7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPdcDetails
            // 
            this.lblPdcDetails.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblPdcDetails.AutoSize = true;
            this.lblPdcDetails.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPdcDetails.ForeColor = System.Drawing.Color.LimeGreen;
            this.lblPdcDetails.Location = new System.Drawing.Point(88, 143);
            this.lblPdcDetails.Name = "lblPdcDetails";
            this.lblPdcDetails.Size = new System.Drawing.Size(19, 21);
            this.lblPdcDetails.TabIndex = 9;
            this.lblPdcDetails.Text = "0";
            this.lblPdcDetails.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblPdcSize
            // 
            this.lblPdcSize.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblPdcSize.AutoSize = true;
            this.lblPdcSize.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPdcSize.ForeColor = System.Drawing.Color.LimeGreen;
            this.lblPdcSize.Location = new System.Drawing.Point(88, 117);
            this.lblPdcSize.Name = "lblPdcSize";
            this.lblPdcSize.Size = new System.Drawing.Size(19, 21);
            this.lblPdcSize.TabIndex = 8;
            this.lblPdcSize.Text = "0";
            this.lblPdcSize.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblPdcName
            // 
            this.lblPdcName.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblPdcName.AutoSize = true;
            this.lblPdcName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPdcName.ForeColor = System.Drawing.Color.LimeGreen;
            this.lblPdcName.Location = new System.Drawing.Point(88, 91);
            this.lblPdcName.Name = "lblPdcName";
            this.lblPdcName.Size = new System.Drawing.Size(19, 21);
            this.lblPdcName.TabIndex = 7;
            this.lblPdcName.Text = "0";
            this.lblPdcName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblCtgName
            // 
            this.lblCtgName.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblCtgName.AutoSize = true;
            this.lblCtgName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCtgName.ForeColor = System.Drawing.Color.LimeGreen;
            this.lblCtgName.Location = new System.Drawing.Point(88, 65);
            this.lblCtgName.Name = "lblCtgName";
            this.lblCtgName.Size = new System.Drawing.Size(19, 21);
            this.lblCtgName.TabIndex = 6;
            this.lblCtgName.Text = "0";
            this.lblCtgName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblSalePrice
            // 
            this.lblSalePrice.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblSalePrice.AutoSize = true;
            this.lblSalePrice.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalePrice.ForeColor = System.Drawing.Color.LimeGreen;
            this.lblSalePrice.Location = new System.Drawing.Point(88, 39);
            this.lblSalePrice.Name = "lblSalePrice";
            this.lblSalePrice.Size = new System.Drawing.Size(19, 21);
            this.lblSalePrice.TabIndex = 5;
            this.lblSalePrice.Text = "0";
            this.lblSalePrice.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // bunifuCustomLabel5
            // 
            this.bunifuCustomLabel5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuCustomLabel5.AutoSize = true;
            this.bunifuCustomLabel5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel5.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel5.Location = new System.Drawing.Point(-1, 39);
            this.bunifuCustomLabel5.Name = "bunifuCustomLabel5";
            this.bunifuCustomLabel5.Size = new System.Drawing.Size(84, 21);
            this.bunifuCustomLabel5.TabIndex = 4;
            this.bunifuCustomLabel5.Text = "Sale Price: ";
            this.bunifuCustomLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bunifuCustomLabel3
            // 
            this.bunifuCustomLabel3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuCustomLabel3.AutoSize = true;
            this.bunifuCustomLabel3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel3.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel3.Location = new System.Drawing.Point(19, 143);
            this.bunifuCustomLabel3.Name = "bunifuCustomLabel3";
            this.bunifuCustomLabel3.Size = new System.Drawing.Size(64, 21);
            this.bunifuCustomLabel3.TabIndex = 3;
            this.bunifuCustomLabel3.Text = "Details: ";
            this.bunifuCustomLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bunifuCustomLabel4
            // 
            this.bunifuCustomLabel4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuCustomLabel4.AutoSize = true;
            this.bunifuCustomLabel4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel4.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel4.Location = new System.Drawing.Point(38, 117);
            this.bunifuCustomLabel4.Name = "bunifuCustomLabel4";
            this.bunifuCustomLabel4.Size = new System.Drawing.Size(45, 21);
            this.bunifuCustomLabel4.TabIndex = 2;
            this.bunifuCustomLabel4.Text = "Size: ";
            this.bunifuCustomLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(24, 91);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(59, 21);
            this.bunifuCustomLabel2.TabIndex = 1;
            this.bunifuCustomLabel2.Text = "Name: ";
            this.bunifuCustomLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(-1, 65);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(84, 21);
            this.bunifuCustomLabel1.TabIndex = 0;
            this.bunifuCustomLabel1.Text = "Categorie: ";
            this.bunifuCustomLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlDatagridView
            // 
            this.pnlDatagridView.Controls.Add(this.tableLayoutPanel4);
            this.pnlDatagridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlDatagridView.Location = new System.Drawing.Point(193, 3);
            this.pnlDatagridView.Name = "pnlDatagridView";
            this.pnlDatagridView.Size = new System.Drawing.Size(287, 305);
            this.pnlDatagridView.TabIndex = 1;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Controls.Add(this.btnCheckOut, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.panel3, 0, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(287, 305);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // btnCheckOut
            // 
            this.btnCheckOut.Active = false;
            this.btnCheckOut.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(180)))), ((int)(((byte)(0)))));
            this.btnCheckOut.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnCheckOut.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCheckOut.BorderRadius = 0;
            this.btnCheckOut.ButtonText = "Check Out >>";
            this.btnCheckOut.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCheckOut.DisabledColor = System.Drawing.Color.Gray;
            this.btnCheckOut.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnCheckOut.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCheckOut.Iconcolor = System.Drawing.Color.Transparent;
            this.btnCheckOut.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnCheckOut.Iconimage")));
            this.btnCheckOut.Iconimage_right = null;
            this.btnCheckOut.Iconimage_right_Selected = null;
            this.btnCheckOut.Iconimage_Selected = null;
            this.btnCheckOut.IconMarginLeft = 0;
            this.btnCheckOut.IconMarginRight = 0;
            this.btnCheckOut.IconRightVisible = true;
            this.btnCheckOut.IconRightZoom = 0D;
            this.btnCheckOut.IconVisible = true;
            this.btnCheckOut.IconZoom = 100D;
            this.btnCheckOut.IsTab = false;
            this.btnCheckOut.Location = new System.Drawing.Point(134, 263);
            this.btnCheckOut.Name = "btnCheckOut";
            this.btnCheckOut.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnCheckOut.OnHovercolor = System.Drawing.Color.DeepSkyBlue;
            this.btnCheckOut.OnHoverTextColor = System.Drawing.Color.White;
            this.btnCheckOut.selected = false;
            this.btnCheckOut.Size = new System.Drawing.Size(150, 39);
            this.btnCheckOut.TabIndex = 0;
            this.btnCheckOut.Text = "Check Out >>";
            this.btnCheckOut.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCheckOut.Textcolor = System.Drawing.Color.White;
            this.btnCheckOut.TextFont = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCheckOut.Click += new System.EventHandler(this.btnCheckOut_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.dataGridViewSale);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(3, 3);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(281, 254);
            this.panel3.TabIndex = 1;
            // 
            // dataGridViewSale
            // 
            this.dataGridViewSale.AllowCustomTheming = true;
            this.dataGridViewSale.AllowUserToAddRows = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(226)))), ((int)(((byte)(199)))));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewSale.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewSale.AutoGenerateColumns = false;
            this.dataGridViewSale.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewSale.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewSale.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dataGridViewSale.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.ForestGreen;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewSale.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridViewSale.ColumnHeadersHeight = 40;
            this.dataGridViewSale.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.pIdDataGridViewTextBoxColumn,
            this.barcodeDataGridViewTextBoxColumn,
            this.ctgNameDataGridViewTextBoxColumn,
            this.pNameDataGridViewTextBoxColumn,
            this.pSizeDataGridViewTextBoxColumn,
            this.quantityDataGridViewTextBoxColumn,
            this.unitPriceDataGridViewTextBoxColumn,
            this.discountDataGridViewTextBoxColumn,
            this.subTotalDataGridViewTextBoxColumn,
            this.Remove});
            this.dataGridViewSale.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(199)))), ((int)(((byte)(226)))), ((int)(((byte)(199)))));
            this.dataGridViewSale.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.dataGridViewSale.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewSale.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(122)))), ((int)(((byte)(185)))), ((int)(((byte)(122)))));
            this.dataGridViewSale.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.White;
            this.dataGridViewSale.CurrentTheme.BackColor = System.Drawing.Color.ForestGreen;
            this.dataGridViewSale.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(220)))), ((int)(((byte)(188)))));
            this.dataGridViewSale.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.ForestGreen;
            this.dataGridViewSale.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
            this.dataGridViewSale.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.dataGridViewSale.CurrentTheme.Name = null;
            this.dataGridViewSale.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(231)))), ((int)(((byte)(210)))));
            this.dataGridViewSale.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.dataGridViewSale.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewSale.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(122)))), ((int)(((byte)(185)))), ((int)(((byte)(122)))));
            this.dataGridViewSale.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.White;
            this.dataGridViewSale.DataSource = this.tblTempSaleBindingSource;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(231)))), ((int)(((byte)(210)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(122)))), ((int)(((byte)(185)))), ((int)(((byte)(122)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewSale.DefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridViewSale.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewSale.EnableHeadersVisualStyles = false;
            this.dataGridViewSale.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(220)))), ((int)(((byte)(188)))));
            this.dataGridViewSale.HeaderBackColor = System.Drawing.Color.ForestGreen;
            this.dataGridViewSale.HeaderBgColor = System.Drawing.Color.Empty;
            this.dataGridViewSale.HeaderForeColor = System.Drawing.Color.White;
            this.dataGridViewSale.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewSale.Name = "dataGridViewSale";
            this.dataGridViewSale.ReadOnly = true;
            this.dataGridViewSale.RowHeadersVisible = false;
            this.dataGridViewSale.RowHeadersWidth = 35;
            this.dataGridViewSale.RowTemplate.Height = 40;
            this.dataGridViewSale.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewSale.Size = new System.Drawing.Size(281, 222);
            this.dataGridViewSale.TabIndex = 0;
            this.dataGridViewSale.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.ForestGreen;
            this.dataGridViewSale.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewSale_CellContentClick);
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            this.idDataGridViewTextBoxColumn.Visible = false;
            // 
            // pIdDataGridViewTextBoxColumn
            // 
            this.pIdDataGridViewTextBoxColumn.DataPropertyName = "pId";
            this.pIdDataGridViewTextBoxColumn.HeaderText = "pId";
            this.pIdDataGridViewTextBoxColumn.Name = "pIdDataGridViewTextBoxColumn";
            this.pIdDataGridViewTextBoxColumn.ReadOnly = true;
            this.pIdDataGridViewTextBoxColumn.Visible = false;
            // 
            // barcodeDataGridViewTextBoxColumn
            // 
            this.barcodeDataGridViewTextBoxColumn.DataPropertyName = "barcode";
            this.barcodeDataGridViewTextBoxColumn.HeaderText = "barcode";
            this.barcodeDataGridViewTextBoxColumn.Name = "barcodeDataGridViewTextBoxColumn";
            this.barcodeDataGridViewTextBoxColumn.ReadOnly = true;
            this.barcodeDataGridViewTextBoxColumn.Visible = false;
            // 
            // ctgNameDataGridViewTextBoxColumn
            // 
            this.ctgNameDataGridViewTextBoxColumn.DataPropertyName = "ctgName";
            this.ctgNameDataGridViewTextBoxColumn.FillWeight = 80F;
            this.ctgNameDataGridViewTextBoxColumn.HeaderText = "Ctg";
            this.ctgNameDataGridViewTextBoxColumn.Name = "ctgNameDataGridViewTextBoxColumn";
            this.ctgNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.ctgNameDataGridViewTextBoxColumn.ToolTipText = "Categorie";
            // 
            // pNameDataGridViewTextBoxColumn
            // 
            this.pNameDataGridViewTextBoxColumn.DataPropertyName = "pName";
            this.pNameDataGridViewTextBoxColumn.FillWeight = 80F;
            this.pNameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.pNameDataGridViewTextBoxColumn.Name = "pNameDataGridViewTextBoxColumn";
            this.pNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.pNameDataGridViewTextBoxColumn.ToolTipText = "Product Name";
            // 
            // pSizeDataGridViewTextBoxColumn
            // 
            this.pSizeDataGridViewTextBoxColumn.DataPropertyName = "pSize";
            this.pSizeDataGridViewTextBoxColumn.FillWeight = 60F;
            this.pSizeDataGridViewTextBoxColumn.HeaderText = "Size";
            this.pSizeDataGridViewTextBoxColumn.Name = "pSizeDataGridViewTextBoxColumn";
            this.pSizeDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // quantityDataGridViewTextBoxColumn
            // 
            this.quantityDataGridViewTextBoxColumn.DataPropertyName = "quantity";
            this.quantityDataGridViewTextBoxColumn.FillWeight = 70F;
            this.quantityDataGridViewTextBoxColumn.HeaderText = "Qty";
            this.quantityDataGridViewTextBoxColumn.Name = "quantityDataGridViewTextBoxColumn";
            this.quantityDataGridViewTextBoxColumn.ReadOnly = true;
            this.quantityDataGridViewTextBoxColumn.ToolTipText = "Quantity";
            // 
            // unitPriceDataGridViewTextBoxColumn
            // 
            this.unitPriceDataGridViewTextBoxColumn.DataPropertyName = "unitPrice";
            this.unitPriceDataGridViewTextBoxColumn.FillWeight = 70F;
            this.unitPriceDataGridViewTextBoxColumn.HeaderText = "Unit Price";
            this.unitPriceDataGridViewTextBoxColumn.Name = "unitPriceDataGridViewTextBoxColumn";
            this.unitPriceDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // discountDataGridViewTextBoxColumn
            // 
            this.discountDataGridViewTextBoxColumn.DataPropertyName = "discount";
            this.discountDataGridViewTextBoxColumn.FillWeight = 80F;
            this.discountDataGridViewTextBoxColumn.HeaderText = "Disc.";
            this.discountDataGridViewTextBoxColumn.Name = "discountDataGridViewTextBoxColumn";
            this.discountDataGridViewTextBoxColumn.ReadOnly = true;
            this.discountDataGridViewTextBoxColumn.ToolTipText = "Discount";
            // 
            // subTotalDataGridViewTextBoxColumn
            // 
            this.subTotalDataGridViewTextBoxColumn.DataPropertyName = "subTotal";
            this.subTotalDataGridViewTextBoxColumn.FillWeight = 70F;
            this.subTotalDataGridViewTextBoxColumn.HeaderText = "Sub Total";
            this.subTotalDataGridViewTextBoxColumn.Name = "subTotalDataGridViewTextBoxColumn";
            this.subTotalDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // Remove
            // 
            this.Remove.FillWeight = 70F;
            this.Remove.HeaderText = "Remove";
            this.Remove.Name = "Remove";
            this.Remove.ReadOnly = true;
            this.Remove.Text = "Remove";
            this.Remove.UseColumnTextForButtonValue = true;
            // 
            // tblTempSaleBindingSource
            // 
            this.tblTempSaleBindingSource.DataMember = "tblTempSale";
            this.tblTempSaleBindingSource.DataSource = this.mainDataSet;
            // 
            // mainDataSet
            // 
            this.mainDataSet.DataSetName = "mainDataSet";
            this.mainDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.bunifuLabel1);
            this.panel4.Controls.Add(this.txtTotal);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel4.Location = new System.Drawing.Point(0, 222);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(281, 32);
            this.panel4.TabIndex = 0;
            // 
            // bunifuLabel1
            // 
            this.bunifuLabel1.AutoEllipsis = false;
            this.bunifuLabel1.CursorType = null;
            this.bunifuLabel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.bunifuLabel1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel1.Location = new System.Drawing.Point(142, 0);
            this.bunifuLabel1.Name = "bunifuLabel1";
            this.bunifuLabel1.Padding = new System.Windows.Forms.Padding(0, 5, 0, 0);
            this.bunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel1.Size = new System.Drawing.Size(39, 32);
            this.bunifuLabel1.TabIndex = 1;
            this.bunifuLabel1.Text = "Total:   ";
            this.bunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuLabel1.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // txtTotal
            // 
            this.txtTotal.AcceptsReturn = false;
            this.txtTotal.AcceptsTab = false;
            this.txtTotal.AnimationSpeed = 200;
            this.txtTotal.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtTotal.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtTotal.BackColor = System.Drawing.Color.Transparent;
            this.txtTotal.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtTotal.BackgroundImage")));
            this.txtTotal.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtTotal.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.txtTotal.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtTotal.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtTotal.BorderRadius = 1;
            this.txtTotal.BorderThickness = 1;
            this.txtTotal.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtTotal.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTotal.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.txtTotal.DefaultText = "";
            this.txtTotal.Dock = System.Windows.Forms.DockStyle.Right;
            this.txtTotal.FillColor = System.Drawing.Color.White;
            this.txtTotal.HideSelection = true;
            this.txtTotal.IconLeft = null;
            this.txtTotal.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTotal.IconPadding = 10;
            this.txtTotal.IconRight = null;
            this.txtTotal.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTotal.Lines = new string[0];
            this.txtTotal.Location = new System.Drawing.Point(181, 0);
            this.txtTotal.MaxLength = 32767;
            this.txtTotal.MinimumSize = new System.Drawing.Size(100, 35);
            this.txtTotal.Modified = false;
            this.txtTotal.Multiline = false;
            this.txtTotal.Name = "txtTotal";
            stateProperties41.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties41.FillColor = System.Drawing.Color.Empty;
            stateProperties41.ForeColor = System.Drawing.Color.Empty;
            stateProperties41.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtTotal.OnActiveState = stateProperties41;
            stateProperties42.BorderColor = System.Drawing.Color.Empty;
            stateProperties42.FillColor = System.Drawing.Color.White;
            stateProperties42.ForeColor = System.Drawing.Color.Empty;
            stateProperties42.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtTotal.OnDisabledState = stateProperties42;
            stateProperties43.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties43.FillColor = System.Drawing.Color.Empty;
            stateProperties43.ForeColor = System.Drawing.Color.Empty;
            stateProperties43.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtTotal.OnHoverState = stateProperties43;
            stateProperties44.BorderColor = System.Drawing.Color.Silver;
            stateProperties44.FillColor = System.Drawing.Color.White;
            stateProperties44.ForeColor = System.Drawing.Color.Empty;
            stateProperties44.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtTotal.OnIdleState = stateProperties44;
            this.txtTotal.PasswordChar = '\0';
            this.txtTotal.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtTotal.PlaceholderText = "Total";
            this.txtTotal.ReadOnly = true;
            this.txtTotal.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtTotal.SelectedText = "";
            this.txtTotal.SelectionLength = 0;
            this.txtTotal.SelectionStart = 0;
            this.txtTotal.ShortcutsEnabled = true;
            this.txtTotal.Size = new System.Drawing.Size(100, 35);
            this.txtTotal.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtTotal.TabIndex = 0;
            this.txtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtTotal.TextMarginBottom = 0;
            this.txtTotal.TextMarginLeft = 5;
            this.txtTotal.TextMarginTop = 0;
            this.txtTotal.TextPlaceholder = "Total";
            this.txtTotal.UseSystemPasswordChar = false;
            this.txtTotal.WordWrap = true;
            // 
            // pnlBarcdeReader
            // 
            this.pnlBarcdeReader.Controls.Add(this.btnAddCart);
            this.pnlBarcdeReader.Controls.Add(this.txtBarcode);
            this.pnlBarcdeReader.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlBarcdeReader.Location = new System.Drawing.Point(0, 0);
            this.pnlBarcdeReader.Name = "pnlBarcdeReader";
            this.pnlBarcdeReader.Size = new System.Drawing.Size(483, 70);
            this.pnlBarcdeReader.TabIndex = 0;
            // 
            // btnAddCart
            // 
            this.btnAddCart.Active = false;
            this.btnAddCart.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(180)))), ((int)(((byte)(0)))));
            this.btnAddCart.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnAddCart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnAddCart.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAddCart.BorderRadius = 0;
            this.btnAddCart.ButtonText = "Add Cart";
            this.btnAddCart.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddCart.DisabledColor = System.Drawing.Color.Gray;
            this.btnAddCart.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddCart.Iconcolor = System.Drawing.Color.Transparent;
            this.btnAddCart.Iconimage = global::ERP.Properties.Resources.add_shopping_cart_60px;
            this.btnAddCart.Iconimage_right = null;
            this.btnAddCart.Iconimage_right_Selected = null;
            this.btnAddCart.Iconimage_Selected = null;
            this.btnAddCart.IconMarginLeft = 0;
            this.btnAddCart.IconMarginRight = 0;
            this.btnAddCart.IconRightVisible = true;
            this.btnAddCart.IconRightZoom = 0D;
            this.btnAddCart.IconVisible = true;
            this.btnAddCart.IconZoom = 100D;
            this.btnAddCart.IsTab = false;
            this.btnAddCart.Location = new System.Drawing.Point(318, 20);
            this.btnAddCart.Name = "btnAddCart";
            this.btnAddCart.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(204)))));
            this.btnAddCart.OnHovercolor = System.Drawing.Color.DeepSkyBlue;
            this.btnAddCart.OnHoverTextColor = System.Drawing.Color.White;
            this.btnAddCart.selected = false;
            this.btnAddCart.Size = new System.Drawing.Size(114, 35);
            this.btnAddCart.TabIndex = 1;
            this.btnAddCart.Text = "Add Cart";
            this.btnAddCart.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddCart.Textcolor = System.Drawing.Color.White;
            this.btnAddCart.TextFont = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddCart.Click += new System.EventHandler(this.btnAddCart_Click);
            // 
            // txtBarcode
            // 
            this.txtBarcode.AcceptsReturn = false;
            this.txtBarcode.AcceptsTab = false;
            this.txtBarcode.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtBarcode.AnimationSpeed = 200;
            this.txtBarcode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtBarcode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtBarcode.BackColor = System.Drawing.Color.Transparent;
            this.txtBarcode.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtBarcode.BackgroundImage")));
            this.txtBarcode.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtBarcode.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.txtBarcode.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtBarcode.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtBarcode.BorderRadius = 1;
            this.txtBarcode.BorderThickness = 1;
            this.txtBarcode.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtBarcode.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtBarcode.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 12F);
            this.txtBarcode.DefaultText = "";
            this.txtBarcode.FillColor = System.Drawing.Color.White;
            this.txtBarcode.HideSelection = true;
            this.txtBarcode.IconLeft = null;
            this.txtBarcode.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtBarcode.IconPadding = 10;
            this.txtBarcode.IconRight = null;
            this.txtBarcode.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtBarcode.Lines = new string[0];
            this.txtBarcode.Location = new System.Drawing.Point(21, 20);
            this.txtBarcode.MaxLength = 32767;
            this.txtBarcode.MinimumSize = new System.Drawing.Size(100, 35);
            this.txtBarcode.Modified = false;
            this.txtBarcode.Multiline = false;
            this.txtBarcode.Name = "txtBarcode";
            stateProperties45.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties45.FillColor = System.Drawing.Color.Empty;
            stateProperties45.ForeColor = System.Drawing.Color.Empty;
            stateProperties45.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtBarcode.OnActiveState = stateProperties45;
            stateProperties46.BorderColor = System.Drawing.Color.Empty;
            stateProperties46.FillColor = System.Drawing.Color.White;
            stateProperties46.ForeColor = System.Drawing.Color.Empty;
            stateProperties46.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtBarcode.OnDisabledState = stateProperties46;
            stateProperties47.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties47.FillColor = System.Drawing.Color.Empty;
            stateProperties47.ForeColor = System.Drawing.Color.Empty;
            stateProperties47.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtBarcode.OnHoverState = stateProperties47;
            stateProperties48.BorderColor = System.Drawing.Color.Silver;
            stateProperties48.FillColor = System.Drawing.Color.White;
            stateProperties48.ForeColor = System.Drawing.Color.Empty;
            stateProperties48.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtBarcode.OnIdleState = stateProperties48;
            this.txtBarcode.PasswordChar = '\0';
            this.txtBarcode.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtBarcode.PlaceholderText = "Scan Barcode";
            this.txtBarcode.ReadOnly = false;
            this.txtBarcode.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtBarcode.SelectedText = "";
            this.txtBarcode.SelectionLength = 0;
            this.txtBarcode.SelectionStart = 0;
            this.txtBarcode.ShortcutsEnabled = true;
            this.txtBarcode.Size = new System.Drawing.Size(278, 35);
            this.txtBarcode.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtBarcode.TabIndex = 2;
            this.txtBarcode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtBarcode.TextMarginBottom = 0;
            this.txtBarcode.TextMarginLeft = 5;
            this.txtBarcode.TextMarginTop = 0;
            this.txtBarcode.TextPlaceholder = "Scan Barcode";
            this.txtBarcode.UseSystemPasswordChar = false;
            this.txtBarcode.WordWrap = true;
            this.txtBarcode.TextChanged += new System.EventHandler(this.txtBarcode_TextChanged);
            this.txtBarcode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtBarcode_KeyDown);
            // 
            // lblTitle
            // 
            this.lblTitle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI Semibold", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(198, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(154, 45);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "NEW SALE";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tblTempSaleTableAdapter
            // 
            this.tblTempSaleTableAdapter.ClearBeforeFill = true;
            // 
            // pnlPrinting
            // 
            this.pnlPrinting.Controls.Add(this.tableLayoutPanel3);
            this.pnlPrinting.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlPrinting.Location = new System.Drawing.Point(0, 0);
            this.pnlPrinting.Name = "pnlPrinting";
            this.pnlPrinting.Size = new System.Drawing.Size(550, 450);
            this.pnlPrinting.TabIndex = 12;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 3;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel3.Controls.Add(this.bunifuCustomLabel16, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.panel8, 1, 2);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 4;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 85F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(550, 450);
            this.tableLayoutPanel3.TabIndex = 4;
            // 
            // bunifuCustomLabel16
            // 
            this.bunifuCustomLabel16.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.bunifuCustomLabel16.AutoSize = true;
            this.bunifuCustomLabel16.Font = new System.Drawing.Font("Segoe UI", 22F);
            this.bunifuCustomLabel16.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel16.Location = new System.Drawing.Point(186, 0);
            this.bunifuCustomLabel16.Name = "bunifuCustomLabel16";
            this.bunifuCustomLabel16.Size = new System.Drawing.Size(177, 44);
            this.bunifuCustomLabel16.TabIndex = 2;
            this.bunifuCustomLabel16.Text = "PRINT VIEW";
            this.bunifuCustomLabel16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.reportViewer1);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel8.Location = new System.Drawing.Point(30, 52);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(489, 372);
            this.panel8.TabIndex = 1;
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource2.Name = "DataSet1";
            reportDataSource2.Value = null;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource2);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "ERP.Reports.Memo.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.ServerReport.BearerToken = null;
            this.reportViewer1.Size = new System.Drawing.Size(489, 372);
            this.reportViewer1.TabIndex = 0;
            // 
            // frmNewSale
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.ClientSize = new System.Drawing.Size(550, 450);
            this.Controls.Add(this.tblLyPnlMain);
            this.Controls.Add(this.pnlPrinting);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MinimumSize = new System.Drawing.Size(415, 340);
            this.Name = "frmNewSale";
            this.Text = "frmNewSale";
            this.Load += new System.EventHandler(this.frmNewSale_Load);
            this.tblLyPnlMain.ResumeLayout(false);
            this.tblLyPnlMain.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tblPnlCustomer.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tblPnlSales.ResumeLayout(false);
            this.pnlCntSales.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.pnlProductDetails.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.pnlDatagridView.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSale)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblTempSaleBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mainDataSet)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.pnlBarcdeReader.ResumeLayout(false);
            this.pnlPrinting.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tblLyPnlMain;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tblPnlSales;
        private System.Windows.Forms.Panel pnlCntSales;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel pnlProductDetails;
        private System.Windows.Forms.Panel pnlDatagridView;
        private Bunifu.UI.WinForms.BunifuDataGridView dataGridViewSale;
        private System.Windows.Forms.Panel pnlBarcdeReader;
        private Bunifu.Framework.UI.BunifuCustomLabel lblTitle;
        private Bunifu.Framework.UI.BunifuFlatButton btnCheckOut;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtBarcode;
        private Bunifu.Framework.UI.BunifuFlatButton btnAddCart;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Panel panel2;
        private Bunifu.Framework.UI.BunifuCustomLabel lblPdcDetails;
        private Bunifu.Framework.UI.BunifuCustomLabel lblPdcSize;
        private Bunifu.Framework.UI.BunifuCustomLabel lblPdcName;
        private Bunifu.Framework.UI.BunifuCustomLabel lblCtgName;
        private Bunifu.Framework.UI.BunifuCustomLabel lblSalePrice;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel5;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel3;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel4;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuCustomLabel lblDiscount;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel7;
        private Bunifu.Framework.UI.BunifuCustomLabel lblStock;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel8;
        private mainDataSet mainDataSet;
        private System.Windows.Forms.BindingSource tblTempSaleBindingSource;
        private mainDataSetTableAdapters.tblTempSaleTableAdapter tblTempSaleTableAdapter;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel1;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtTotal;
        private System.Windows.Forms.TableLayoutPanel tblPnlCustomer;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.GroupBox groupBox1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel10;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel9;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel6;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtCustomerName;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtCustomerPhone;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtCusAddress;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.GroupBox groupBox2;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel13;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnSaleConfirm;
        private System.Windows.Forms.TextBox txtDue;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel12;
        private System.Windows.Forms.TextBox txtPayment;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel14;
        private System.Windows.Forms.TextBox txtDiscount;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel11;
        private System.Windows.Forms.TextBox txtTotalAmount;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnBack;
        private System.Windows.Forms.ComboBox cmbPayMethod;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel15;
        private System.Windows.Forms.Panel pnlPrinting;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel16;
        private System.Windows.Forms.Panel panel8;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.TextBox txtOverallDiscount;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel17;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn barcodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ctgNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pSizeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantityDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn unitPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn discountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn subTotalDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewButtonColumn Remove;
        private System.Windows.Forms.TextBox txtInTotal;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel18;
    }
}