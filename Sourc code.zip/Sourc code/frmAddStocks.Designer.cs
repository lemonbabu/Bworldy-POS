﻿
namespace ERP
{
    partial class frmAddStocks
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAddStocks));
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.tblPnlStocks = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.cmbProductCtg = new System.Windows.Forms.ComboBox();
            this.cmbProductName = new System.Windows.Forms.ComboBox();
            this.cmbProductSize = new System.Windows.Forms.ComboBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.pnlAddStockInfo = new System.Windows.Forms.Panel();
            this.txtLSalePrice = new Bunifu.Framework.BunifuCustomTextbox();
            this.txtLPPrice = new Bunifu.Framework.BunifuCustomTextbox();
            this.txtLQun = new Bunifu.Framework.BunifuCustomTextbox();
            this.bunifuLabel5 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel6 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel4 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel3 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel2 = new Bunifu.UI.WinForms.BunifuLabel();
            this.txtCurentStock = new Bunifu.Framework.BunifuCustomTextbox();
            this.txtLDate = new Bunifu.Framework.BunifuCustomTextbox();
            this.bunifuLabel1 = new Bunifu.UI.WinForms.BunifuLabel();
            this.pnlAddStockTools = new System.Windows.Forms.Panel();
            this.btnClear = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btnAddStock = new Bunifu.Framework.UI.BunifuThinButton2();
            this.txtQuantity = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.txtSalePrice = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.txtBuyingPrice = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.lblTitle = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.tblPnlBarcodeGenerate = new System.Windows.Forms.TableLayoutPanel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.bunifuLabel7 = new Bunifu.UI.WinForms.BunifuLabel();
            this.txtBarcodeQuantity = new Bunifu.Framework.BunifuCustomTextbox();
            this.btnGenerate = new Bunifu.Framework.UI.BunifuThinButton2();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.txtCtgProductBarcode = new System.Windows.Forms.TextBox();
            this.txtNameProductBarcode = new System.Windows.Forms.TextBox();
            this.txtSizeProductBarcode = new System.Windows.Forms.TextBox();
            this.pnlBarcode = new System.Windows.Forms.Panel();
            this.btnBarcodePrint = new Bunifu.Framework.UI.BunifuThinButton2();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.pnlReport = new System.Windows.Forms.Panel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.appData1 = new ERP.AppData();
            this.BarcodeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.AppData = new ERP.AppData();
            this.tblPnlStocks.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.pnlAddStockInfo.SuspendLayout();
            this.pnlAddStockTools.SuspendLayout();
            this.tblPnlBarcodeGenerate.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.pnlBarcode.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnlReport.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.appData1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BarcodeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.AppData)).BeginInit();
            this.SuspendLayout();
            // 
            // tblPnlStocks
            // 
            this.tblPnlStocks.ColumnCount = 1;
            this.tblPnlStocks.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblPnlStocks.Controls.Add(this.panel1, 0, 1);
            this.tblPnlStocks.Controls.Add(this.lblTitle, 0, 0);
            this.tblPnlStocks.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblPnlStocks.ForeColor = System.Drawing.Color.Black;
            this.tblPnlStocks.Location = new System.Drawing.Point(0, 0);
            this.tblPnlStocks.Name = "tblPnlStocks";
            this.tblPnlStocks.RowCount = 2;
            this.tblPnlStocks.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tblPnlStocks.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 85F));
            this.tblPnlStocks.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblPnlStocks.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblPnlStocks.Size = new System.Drawing.Size(550, 450);
            this.tblPnlStocks.TabIndex = 10;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 70);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(544, 377);
            this.panel1.TabIndex = 0;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.555555F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 88.88889F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.555555F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 1, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(544, 377);
            this.tableLayoutPanel1.TabIndex = 12;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 7;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.cmbProductCtg, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.cmbProductName, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.cmbProductSize, 5, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(33, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(477, 50);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // cmbProductCtg
            // 
            this.cmbProductCtg.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmbProductCtg.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbProductCtg.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProductCtg.FormattingEnabled = true;
            this.cmbProductCtg.ItemHeight = 21;
            this.cmbProductCtg.Location = new System.Drawing.Point(21, 3);
            this.cmbProductCtg.Name = "cmbProductCtg";
            this.cmbProductCtg.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.cmbProductCtg.Size = new System.Drawing.Size(194, 29);
            this.cmbProductCtg.TabIndex = 1;
            this.cmbProductCtg.Text = " Select a Categorie";
            this.cmbProductCtg.Click += new System.EventHandler(this.cmbProductCtg_Click);
            // 
            // cmbProductName
            // 
            this.cmbProductName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmbProductName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProductName.FormattingEnabled = true;
            this.cmbProductName.Location = new System.Drawing.Point(226, 3);
            this.cmbProductName.Name = "cmbProductName";
            this.cmbProductName.Size = new System.Drawing.Size(144, 29);
            this.cmbProductName.TabIndex = 2;
            this.cmbProductName.Click += new System.EventHandler(this.cmbProductName_Click);
            // 
            // cmbProductSize
            // 
            this.cmbProductSize.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cmbProductSize.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbProductSize.FormattingEnabled = true;
            this.cmbProductSize.Location = new System.Drawing.Point(381, 3);
            this.cmbProductSize.Name = "cmbProductSize";
            this.cmbProductSize.Size = new System.Drawing.Size(74, 29);
            this.cmbProductSize.TabIndex = 3;
            this.cmbProductSize.SelectedValueChanged += new System.EventHandler(this.cmbProductSize_SelectedValueChanged);
            this.cmbProductSize.Click += new System.EventHandler(this.cmbProductSize_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.tableLayoutPanel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(33, 59);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(477, 276);
            this.panel2.TabIndex = 0;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 5;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 230F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 230F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.pnlAddStockInfo, 3, 1);
            this.tableLayoutPanel3.Controls.Add(this.pnlAddStockTools, 1, 1);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 3;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 400F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 95F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(477, 276);
            this.tableLayoutPanel3.TabIndex = 14;
            // 
            // pnlAddStockInfo
            // 
            this.pnlAddStockInfo.Controls.Add(this.txtLSalePrice);
            this.pnlAddStockInfo.Controls.Add(this.txtLPPrice);
            this.pnlAddStockInfo.Controls.Add(this.txtLQun);
            this.pnlAddStockInfo.Controls.Add(this.bunifuLabel5);
            this.pnlAddStockInfo.Controls.Add(this.bunifuLabel6);
            this.pnlAddStockInfo.Controls.Add(this.bunifuLabel4);
            this.pnlAddStockInfo.Controls.Add(this.bunifuLabel3);
            this.pnlAddStockInfo.Controls.Add(this.bunifuLabel2);
            this.pnlAddStockInfo.Controls.Add(this.txtCurentStock);
            this.pnlAddStockInfo.Controls.Add(this.txtLDate);
            this.pnlAddStockInfo.Controls.Add(this.bunifuLabel1);
            this.pnlAddStockInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlAddStockInfo.Location = new System.Drawing.Point(244, -3);
            this.pnlAddStockInfo.Name = "pnlAddStockInfo";
            this.pnlAddStockInfo.Size = new System.Drawing.Size(224, 394);
            this.pnlAddStockInfo.TabIndex = 1;
            // 
            // txtLSalePrice
            // 
            this.txtLSalePrice.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtLSalePrice.BorderColor = System.Drawing.Color.SeaGreen;
            this.txtLSalePrice.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLSalePrice.Location = new System.Drawing.Point(130, 159);
            this.txtLSalePrice.Name = "txtLSalePrice";
            this.txtLSalePrice.ReadOnly = true;
            this.txtLSalePrice.Size = new System.Drawing.Size(62, 25);
            this.txtLSalePrice.TabIndex = 26;
            this.txtLSalePrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtLPPrice
            // 
            this.txtLPPrice.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtLPPrice.BorderColor = System.Drawing.Color.SeaGreen;
            this.txtLPPrice.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLPPrice.Location = new System.Drawing.Point(130, 122);
            this.txtLPPrice.Name = "txtLPPrice";
            this.txtLPPrice.ReadOnly = true;
            this.txtLPPrice.Size = new System.Drawing.Size(62, 25);
            this.txtLPPrice.TabIndex = 25;
            this.txtLPPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtLQun
            // 
            this.txtLQun.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtLQun.BorderColor = System.Drawing.Color.SeaGreen;
            this.txtLQun.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLQun.Location = new System.Drawing.Point(130, 85);
            this.txtLQun.Name = "txtLQun";
            this.txtLQun.ReadOnly = true;
            this.txtLQun.Size = new System.Drawing.Size(62, 25);
            this.txtLQun.TabIndex = 24;
            this.txtLQun.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bunifuLabel5
            // 
            this.bunifuLabel5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuLabel5.AutoEllipsis = false;
            this.bunifuLabel5.CursorType = null;
            this.bunifuLabel5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel5.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel5.Location = new System.Drawing.Point(37, 163);
            this.bunifuLabel5.Name = "bunifuLabel5";
            this.bunifuLabel5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel5.Size = new System.Drawing.Size(68, 18);
            this.bunifuLabel5.TabIndex = 23;
            this.bunifuLabel5.Text = "Sale Price:";
            this.bunifuLabel5.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel5.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel6
            // 
            this.bunifuLabel6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuLabel6.AutoEllipsis = false;
            this.bunifuLabel6.CursorType = null;
            this.bunifuLabel6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel6.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel6.Location = new System.Drawing.Point(37, 126);
            this.bunifuLabel6.Name = "bunifuLabel6";
            this.bunifuLabel6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel6.Size = new System.Drawing.Size(81, 18);
            this.bunifuLabel6.TabIndex = 22;
            this.bunifuLabel6.Text = "Buying Price:";
            this.bunifuLabel6.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel6.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel4
            // 
            this.bunifuLabel4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuLabel4.AutoEllipsis = false;
            this.bunifuLabel4.CursorType = null;
            this.bunifuLabel4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel4.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel4.Location = new System.Drawing.Point(37, 89);
            this.bunifuLabel4.Name = "bunifuLabel4";
            this.bunifuLabel4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel4.Size = new System.Drawing.Size(54, 18);
            this.bunifuLabel4.TabIndex = 21;
            this.bunifuLabel4.Text = "Quantity:";
            this.bunifuLabel4.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel4.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel3
            // 
            this.bunifuLabel3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuLabel3.AutoEllipsis = false;
            this.bunifuLabel3.CursorType = null;
            this.bunifuLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel3.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel3.Location = new System.Drawing.Point(37, 52);
            this.bunifuLabel3.Name = "bunifuLabel3";
            this.bunifuLabel3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel3.Size = new System.Drawing.Size(35, 18);
            this.bunifuLabel3.TabIndex = 20;
            this.bunifuLabel3.Text = "Date:";
            this.bunifuLabel3.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel3.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel2
            // 
            this.bunifuLabel2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuLabel2.AutoEllipsis = false;
            this.bunifuLabel2.CursorType = null;
            this.bunifuLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel2.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel2.Location = new System.Drawing.Point(65, 200);
            this.bunifuLabel2.Name = "bunifuLabel2";
            this.bunifuLabel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel2.Size = new System.Drawing.Size(111, 18);
            this.bunifuLabel2.TabIndex = 19;
            this.bunifuLabel2.Text = "Available Quantity";
            this.bunifuLabel2.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel2.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // txtCurentStock
            // 
            this.txtCurentStock.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtCurentStock.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtCurentStock.BorderColor = System.Drawing.Color.SeaGreen;
            this.txtCurentStock.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCurentStock.Location = new System.Drawing.Point(82, 225);
            this.txtCurentStock.Name = "txtCurentStock";
            this.txtCurentStock.ReadOnly = true;
            this.txtCurentStock.Size = new System.Drawing.Size(77, 25);
            this.txtCurentStock.TabIndex = 18;
            this.txtCurentStock.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtLDate
            // 
            this.txtLDate.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtLDate.BorderColor = System.Drawing.Color.SeaGreen;
            this.txtLDate.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLDate.Location = new System.Drawing.Point(91, 50);
            this.txtLDate.Name = "txtLDate";
            this.txtLDate.ReadOnly = true;
            this.txtLDate.Size = new System.Drawing.Size(101, 23);
            this.txtLDate.TabIndex = 17;
            this.txtLDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bunifuLabel1
            // 
            this.bunifuLabel1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuLabel1.AutoEllipsis = false;
            this.bunifuLabel1.CursorType = null;
            this.bunifuLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel1.Location = new System.Drawing.Point(35, 17);
            this.bunifuLabel1.Name = "bunifuLabel1";
            this.bunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel1.Size = new System.Drawing.Size(164, 22);
            this.bunifuLabel1.TabIndex = 16;
            this.bunifuLabel1.Text = "Last Stock Inforamtion";
            this.bunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel1.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // pnlAddStockTools
            // 
            this.pnlAddStockTools.Controls.Add(this.btnClear);
            this.pnlAddStockTools.Controls.Add(this.btnAddStock);
            this.pnlAddStockTools.Controls.Add(this.txtQuantity);
            this.pnlAddStockTools.Controls.Add(this.txtSalePrice);
            this.pnlAddStockTools.Controls.Add(this.txtBuyingPrice);
            this.pnlAddStockTools.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlAddStockTools.Location = new System.Drawing.Point(9, -3);
            this.pnlAddStockTools.Name = "pnlAddStockTools";
            this.pnlAddStockTools.Size = new System.Drawing.Size(224, 394);
            this.pnlAddStockTools.TabIndex = 0;
            // 
            // btnClear
            // 
            this.btnClear.ActiveBorderThickness = 1;
            this.btnClear.ActiveCornerRadius = 1;
            this.btnClear.ActiveFillColor = System.Drawing.Color.Red;
            this.btnClear.ActiveForecolor = System.Drawing.Color.White;
            this.btnClear.ActiveLineColor = System.Drawing.Color.Red;
            this.btnClear.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnClear.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnClear.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnClear.BackgroundImage")));
            this.btnClear.ButtonText = "Clear";
            this.btnClear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClear.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClear.ForeColor = System.Drawing.Color.Red;
            this.btnClear.IdleBorderThickness = 1;
            this.btnClear.IdleCornerRadius = 1;
            this.btnClear.IdleFillColor = System.Drawing.Color.White;
            this.btnClear.IdleForecolor = System.Drawing.Color.DodgerBlue;
            this.btnClear.IdleLineColor = System.Drawing.Color.DodgerBlue;
            this.btnClear.Location = new System.Drawing.Point(19, 194);
            this.btnClear.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 45);
            this.btnClear.TabIndex = 8;
            this.btnClear.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnAddStock
            // 
            this.btnAddStock.ActiveBorderThickness = 1;
            this.btnAddStock.ActiveCornerRadius = 1;
            this.btnAddStock.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnAddStock.ActiveForecolor = System.Drawing.Color.White;
            this.btnAddStock.ActiveLineColor = System.Drawing.Color.DodgerBlue;
            this.btnAddStock.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnAddStock.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnAddStock.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAddStock.BackgroundImage")));
            this.btnAddStock.ButtonText = "Add Stock";
            this.btnAddStock.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddStock.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddStock.ForeColor = System.Drawing.Color.DodgerBlue;
            this.btnAddStock.IdleBorderThickness = 1;
            this.btnAddStock.IdleCornerRadius = 1;
            this.btnAddStock.IdleFillColor = System.Drawing.Color.White;
            this.btnAddStock.IdleForecolor = System.Drawing.Color.DodgerBlue;
            this.btnAddStock.IdleLineColor = System.Drawing.Color.DodgerBlue;
            this.btnAddStock.Location = new System.Drawing.Point(103, 194);
            this.btnAddStock.Margin = new System.Windows.Forms.Padding(4);
            this.btnAddStock.Name = "btnAddStock";
            this.btnAddStock.Size = new System.Drawing.Size(95, 45);
            this.btnAddStock.TabIndex = 7;
            this.btnAddStock.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAddStock.Click += new System.EventHandler(this.btnAddStock_Click);
            // 
            // txtQuantity
            // 
            this.txtQuantity.AcceptsReturn = false;
            this.txtQuantity.AcceptsTab = false;
            this.txtQuantity.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtQuantity.AnimationSpeed = 200;
            this.txtQuantity.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtQuantity.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtQuantity.BackColor = System.Drawing.Color.Transparent;
            this.txtQuantity.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtQuantity.BackgroundImage")));
            this.txtQuantity.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtQuantity.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.txtQuantity.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtQuantity.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtQuantity.BorderRadius = 1;
            this.txtQuantity.BorderThickness = 1;
            this.txtQuantity.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtQuantity.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtQuantity.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 10F);
            this.txtQuantity.DefaultText = "";
            this.txtQuantity.FillColor = System.Drawing.Color.White;
            this.txtQuantity.HideSelection = true;
            this.txtQuantity.IconLeft = null;
            this.txtQuantity.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtQuantity.IconPadding = 10;
            this.txtQuantity.IconRight = null;
            this.txtQuantity.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtQuantity.Lines = new string[0];
            this.txtQuantity.Location = new System.Drawing.Point(51, 33);
            this.txtQuantity.MaxLength = 32767;
            this.txtQuantity.MinimumSize = new System.Drawing.Size(100, 35);
            this.txtQuantity.Modified = false;
            this.txtQuantity.Multiline = false;
            this.txtQuantity.Name = "txtQuantity";
            stateProperties1.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtQuantity.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.Empty;
            stateProperties2.FillColor = System.Drawing.Color.White;
            stateProperties2.ForeColor = System.Drawing.Color.Empty;
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtQuantity.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtQuantity.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.Silver;
            stateProperties4.FillColor = System.Drawing.Color.White;
            stateProperties4.ForeColor = System.Drawing.Color.Empty;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtQuantity.OnIdleState = stateProperties4;
            this.txtQuantity.PasswordChar = '\0';
            this.txtQuantity.PlaceholderForeColor = System.Drawing.Color.DimGray;
            this.txtQuantity.PlaceholderText = "Quantity";
            this.txtQuantity.ReadOnly = false;
            this.txtQuantity.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtQuantity.SelectedText = "";
            this.txtQuantity.SelectionLength = 0;
            this.txtQuantity.SelectionStart = 0;
            this.txtQuantity.ShortcutsEnabled = true;
            this.txtQuantity.Size = new System.Drawing.Size(113, 35);
            this.txtQuantity.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtQuantity.TabIndex = 4;
            this.txtQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtQuantity.TextMarginBottom = 0;
            this.txtQuantity.TextMarginLeft = 5;
            this.txtQuantity.TextMarginTop = 0;
            this.txtQuantity.TextPlaceholder = "Quantity";
            this.txtQuantity.UseSystemPasswordChar = false;
            this.txtQuantity.WordWrap = true;
            this.txtQuantity.TextChange += new System.EventHandler(this.txtQuantity_TextChange);
            this.txtQuantity.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtQuantity_KeyDown);
            // 
            // txtSalePrice
            // 
            this.txtSalePrice.AcceptsReturn = false;
            this.txtSalePrice.AcceptsTab = false;
            this.txtSalePrice.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtSalePrice.AnimationSpeed = 200;
            this.txtSalePrice.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtSalePrice.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtSalePrice.BackColor = System.Drawing.Color.Transparent;
            this.txtSalePrice.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtSalePrice.BackgroundImage")));
            this.txtSalePrice.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtSalePrice.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.txtSalePrice.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtSalePrice.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtSalePrice.BorderRadius = 1;
            this.txtSalePrice.BorderThickness = 1;
            this.txtSalePrice.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtSalePrice.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSalePrice.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 10F);
            this.txtSalePrice.DefaultText = "";
            this.txtSalePrice.FillColor = System.Drawing.Color.White;
            this.txtSalePrice.HideSelection = true;
            this.txtSalePrice.IconLeft = null;
            this.txtSalePrice.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSalePrice.IconPadding = 10;
            this.txtSalePrice.IconRight = null;
            this.txtSalePrice.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtSalePrice.Lines = new string[0];
            this.txtSalePrice.Location = new System.Drawing.Point(51, 135);
            this.txtSalePrice.MaxLength = 32767;
            this.txtSalePrice.MinimumSize = new System.Drawing.Size(100, 35);
            this.txtSalePrice.Modified = false;
            this.txtSalePrice.Multiline = false;
            this.txtSalePrice.Name = "txtSalePrice";
            stateProperties5.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtSalePrice.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.Empty;
            stateProperties6.FillColor = System.Drawing.Color.White;
            stateProperties6.ForeColor = System.Drawing.Color.Empty;
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtSalePrice.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtSalePrice.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.Silver;
            stateProperties8.FillColor = System.Drawing.Color.White;
            stateProperties8.ForeColor = System.Drawing.Color.Empty;
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtSalePrice.OnIdleState = stateProperties8;
            this.txtSalePrice.PasswordChar = '\0';
            this.txtSalePrice.PlaceholderForeColor = System.Drawing.Color.DimGray;
            this.txtSalePrice.PlaceholderText = "Sale Price";
            this.txtSalePrice.ReadOnly = false;
            this.txtSalePrice.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtSalePrice.SelectedText = "";
            this.txtSalePrice.SelectionLength = 0;
            this.txtSalePrice.SelectionStart = 0;
            this.txtSalePrice.ShortcutsEnabled = true;
            this.txtSalePrice.Size = new System.Drawing.Size(113, 35);
            this.txtSalePrice.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtSalePrice.TabIndex = 6;
            this.txtSalePrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtSalePrice.TextMarginBottom = 0;
            this.txtSalePrice.TextMarginLeft = 5;
            this.txtSalePrice.TextMarginTop = 0;
            this.txtSalePrice.TextPlaceholder = "Sale Price";
            this.txtSalePrice.UseSystemPasswordChar = false;
            this.txtSalePrice.WordWrap = true;
            this.txtSalePrice.TextChange += new System.EventHandler(this.txtSalePrice_TextChange);
            this.txtSalePrice.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSalePrice_KeyDown);
            // 
            // txtBuyingPrice
            // 
            this.txtBuyingPrice.AcceptsReturn = false;
            this.txtBuyingPrice.AcceptsTab = false;
            this.txtBuyingPrice.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtBuyingPrice.AnimationSpeed = 200;
            this.txtBuyingPrice.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtBuyingPrice.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtBuyingPrice.BackColor = System.Drawing.Color.Transparent;
            this.txtBuyingPrice.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtBuyingPrice.BackgroundImage")));
            this.txtBuyingPrice.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtBuyingPrice.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.txtBuyingPrice.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtBuyingPrice.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtBuyingPrice.BorderRadius = 1;
            this.txtBuyingPrice.BorderThickness = 1;
            this.txtBuyingPrice.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtBuyingPrice.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtBuyingPrice.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 10F);
            this.txtBuyingPrice.DefaultText = "";
            this.txtBuyingPrice.FillColor = System.Drawing.Color.White;
            this.txtBuyingPrice.HideSelection = true;
            this.txtBuyingPrice.IconLeft = null;
            this.txtBuyingPrice.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtBuyingPrice.IconPadding = 10;
            this.txtBuyingPrice.IconRight = null;
            this.txtBuyingPrice.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtBuyingPrice.Lines = new string[0];
            this.txtBuyingPrice.Location = new System.Drawing.Point(51, 84);
            this.txtBuyingPrice.MaxLength = 32767;
            this.txtBuyingPrice.MinimumSize = new System.Drawing.Size(100, 35);
            this.txtBuyingPrice.Modified = false;
            this.txtBuyingPrice.Multiline = false;
            this.txtBuyingPrice.Name = "txtBuyingPrice";
            stateProperties9.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties9.FillColor = System.Drawing.Color.Empty;
            stateProperties9.ForeColor = System.Drawing.Color.Empty;
            stateProperties9.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtBuyingPrice.OnActiveState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.Empty;
            stateProperties10.FillColor = System.Drawing.Color.White;
            stateProperties10.ForeColor = System.Drawing.Color.Empty;
            stateProperties10.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtBuyingPrice.OnDisabledState = stateProperties10;
            stateProperties11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties11.FillColor = System.Drawing.Color.Empty;
            stateProperties11.ForeColor = System.Drawing.Color.Empty;
            stateProperties11.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtBuyingPrice.OnHoverState = stateProperties11;
            stateProperties12.BorderColor = System.Drawing.Color.Silver;
            stateProperties12.FillColor = System.Drawing.Color.White;
            stateProperties12.ForeColor = System.Drawing.Color.Empty;
            stateProperties12.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtBuyingPrice.OnIdleState = stateProperties12;
            this.txtBuyingPrice.PasswordChar = '\0';
            this.txtBuyingPrice.PlaceholderForeColor = System.Drawing.Color.DimGray;
            this.txtBuyingPrice.PlaceholderText = "Buying Price";
            this.txtBuyingPrice.ReadOnly = false;
            this.txtBuyingPrice.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtBuyingPrice.SelectedText = "";
            this.txtBuyingPrice.SelectionLength = 0;
            this.txtBuyingPrice.SelectionStart = 0;
            this.txtBuyingPrice.ShortcutsEnabled = true;
            this.txtBuyingPrice.Size = new System.Drawing.Size(113, 35);
            this.txtBuyingPrice.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtBuyingPrice.TabIndex = 5;
            this.txtBuyingPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtBuyingPrice.TextMarginBottom = 0;
            this.txtBuyingPrice.TextMarginLeft = 5;
            this.txtBuyingPrice.TextMarginTop = 0;
            this.txtBuyingPrice.TextPlaceholder = "Buying Price";
            this.txtBuyingPrice.UseSystemPasswordChar = false;
            this.txtBuyingPrice.WordWrap = true;
            this.txtBuyingPrice.TextChange += new System.EventHandler(this.txtBuyingPrice_TextChange);
            this.txtBuyingPrice.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtBuyingPrice_KeyDown);
            // 
            // lblTitle
            // 
            this.lblTitle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(150, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(250, 67);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "ADD NEW STOCK";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tblPnlBarcodeGenerate
            // 
            this.tblPnlBarcodeGenerate.ColumnCount = 1;
            this.tblPnlBarcodeGenerate.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblPnlBarcodeGenerate.Controls.Add(this.panel3, 0, 1);
            this.tblPnlBarcodeGenerate.Controls.Add(this.bunifuCustomLabel1, 0, 0);
            this.tblPnlBarcodeGenerate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblPnlBarcodeGenerate.ForeColor = System.Drawing.Color.Black;
            this.tblPnlBarcodeGenerate.Location = new System.Drawing.Point(0, 0);
            this.tblPnlBarcodeGenerate.Name = "tblPnlBarcodeGenerate";
            this.tblPnlBarcodeGenerate.RowCount = 3;
            this.tblPnlBarcodeGenerate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tblPnlBarcodeGenerate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 85F));
            this.tblPnlBarcodeGenerate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblPnlBarcodeGenerate.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tblPnlBarcodeGenerate.Size = new System.Drawing.Size(550, 450);
            this.tblPnlBarcodeGenerate.TabIndex = 11;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.tableLayoutPanel5);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(3, 67);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(544, 359);
            this.panel3.TabIndex = 0;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 3;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.555555F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 88.88889F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5.555555F));
            this.tableLayoutPanel5.Controls.Add(this.panel4, 1, 1);
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanel6, 1, 0);
            this.tableLayoutPanel5.Controls.Add(this.pnlBarcode, 1, 2);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 4;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(544, 359);
            this.tableLayoutPanel5.TabIndex = 12;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.bunifuLabel7);
            this.panel4.Controls.Add(this.txtBarcodeQuantity);
            this.panel4.Controls.Add(this.btnGenerate);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(33, 50);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(477, 39);
            this.panel4.TabIndex = 0;
            // 
            // bunifuLabel7
            // 
            this.bunifuLabel7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bunifuLabel7.AutoEllipsis = false;
            this.bunifuLabel7.CursorType = null;
            this.bunifuLabel7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel7.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel7.Location = new System.Drawing.Point(59, 6);
            this.bunifuLabel7.Name = "bunifuLabel7";
            this.bunifuLabel7.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel7.Size = new System.Drawing.Size(133, 23);
            this.bunifuLabel7.TabIndex = 19;
            this.bunifuLabel7.Text = "Available Quantity:";
            this.bunifuLabel7.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel7.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // txtBarcodeQuantity
            // 
            this.txtBarcodeQuantity.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtBarcodeQuantity.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.txtBarcodeQuantity.BorderColor = System.Drawing.Color.SeaGreen;
            this.txtBarcodeQuantity.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBarcodeQuantity.Location = new System.Drawing.Point(198, 4);
            this.txtBarcodeQuantity.Name = "txtBarcodeQuantity";
            this.txtBarcodeQuantity.Size = new System.Drawing.Size(77, 29);
            this.txtBarcodeQuantity.TabIndex = 18;
            this.txtBarcodeQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnGenerate
            // 
            this.btnGenerate.ActiveBorderThickness = 1;
            this.btnGenerate.ActiveCornerRadius = 10;
            this.btnGenerate.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnGenerate.ActiveForecolor = System.Drawing.Color.White;
            this.btnGenerate.ActiveLineColor = System.Drawing.Color.DodgerBlue;
            this.btnGenerate.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnGenerate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.btnGenerate.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnGenerate.BackgroundImage")));
            this.btnGenerate.ButtonText = "Generate";
            this.btnGenerate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGenerate.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenerate.ForeColor = System.Drawing.Color.DodgerBlue;
            this.btnGenerate.IdleBorderThickness = 1;
            this.btnGenerate.IdleCornerRadius = 10;
            this.btnGenerate.IdleFillColor = System.Drawing.Color.White;
            this.btnGenerate.IdleForecolor = System.Drawing.Color.DodgerBlue;
            this.btnGenerate.IdleLineColor = System.Drawing.Color.DodgerBlue;
            this.btnGenerate.Location = new System.Drawing.Point(319, -4);
            this.btnGenerate.Margin = new System.Windows.Forms.Padding(4);
            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.Size = new System.Drawing.Size(95, 45);
            this.btnGenerate.TabIndex = 8;
            this.btnGenerate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 7;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 220F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 150F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 5F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Controls.Add(this.txtCtgProductBarcode, 1, 0);
            this.tableLayoutPanel6.Controls.Add(this.txtNameProductBarcode, 3, 0);
            this.tableLayoutPanel6.Controls.Add(this.txtSizeProductBarcode, 5, 0);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(33, 3);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 2;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(477, 41);
            this.tableLayoutPanel6.TabIndex = 0;
            // 
            // txtCtgProductBarcode
            // 
            this.txtCtgProductBarcode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtCtgProductBarcode.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCtgProductBarcode.Location = new System.Drawing.Point(11, 3);
            this.txtCtgProductBarcode.Name = "txtCtgProductBarcode";
            this.txtCtgProductBarcode.ReadOnly = true;
            this.txtCtgProductBarcode.Size = new System.Drawing.Size(214, 29);
            this.txtCtgProductBarcode.TabIndex = 4;
            // 
            // txtNameProductBarcode
            // 
            this.txtNameProductBarcode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtNameProductBarcode.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNameProductBarcode.Location = new System.Drawing.Point(236, 3);
            this.txtNameProductBarcode.Name = "txtNameProductBarcode";
            this.txtNameProductBarcode.ReadOnly = true;
            this.txtNameProductBarcode.Size = new System.Drawing.Size(144, 29);
            this.txtNameProductBarcode.TabIndex = 5;
            // 
            // txtSizeProductBarcode
            // 
            this.txtSizeProductBarcode.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.txtSizeProductBarcode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtSizeProductBarcode.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSizeProductBarcode.Location = new System.Drawing.Point(391, 3);
            this.txtSizeProductBarcode.Name = "txtSizeProductBarcode";
            this.txtSizeProductBarcode.ReadOnly = true;
            this.txtSizeProductBarcode.Size = new System.Drawing.Size(74, 29);
            this.txtSizeProductBarcode.TabIndex = 6;
            // 
            // pnlBarcode
            // 
            this.pnlBarcode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.pnlBarcode.Controls.Add(this.btnBarcodePrint);
            this.pnlBarcode.Controls.Add(this.pictureBox1);
            this.pnlBarcode.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlBarcode.Location = new System.Drawing.Point(33, 95);
            this.pnlBarcode.Name = "pnlBarcode";
            this.pnlBarcode.Size = new System.Drawing.Size(477, 229);
            this.pnlBarcode.TabIndex = 0;
            // 
            // btnBarcodePrint
            // 
            this.btnBarcodePrint.ActiveBorderThickness = 1;
            this.btnBarcodePrint.ActiveCornerRadius = 10;
            this.btnBarcodePrint.ActiveFillColor = System.Drawing.Color.DodgerBlue;
            this.btnBarcodePrint.ActiveForecolor = System.Drawing.Color.White;
            this.btnBarcodePrint.ActiveLineColor = System.Drawing.Color.DodgerBlue;
            this.btnBarcodePrint.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnBarcodePrint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnBarcodePrint.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBarcodePrint.BackgroundImage")));
            this.btnBarcodePrint.ButtonText = "Print >>";
            this.btnBarcodePrint.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBarcodePrint.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBarcodePrint.ForeColor = System.Drawing.Color.DodgerBlue;
            this.btnBarcodePrint.IdleBorderThickness = 1;
            this.btnBarcodePrint.IdleCornerRadius = 10;
            this.btnBarcodePrint.IdleFillColor = System.Drawing.Color.White;
            this.btnBarcodePrint.IdleForecolor = System.Drawing.Color.DodgerBlue;
            this.btnBarcodePrint.IdleLineColor = System.Drawing.Color.DodgerBlue;
            this.btnBarcodePrint.Location = new System.Drawing.Point(187, 100);
            this.btnBarcodePrint.Margin = new System.Windows.Forms.Padding(5);
            this.btnBarcodePrint.Name = "btnBarcodePrint";
            this.btnBarcodePrint.Size = new System.Drawing.Size(97, 42);
            this.btnBarcodePrint.TabIndex = 10;
            this.btnBarcodePrint.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnBarcodePrint.Click += new System.EventHandler(this.btnBarcodePrint_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.pictureBox1.Location = new System.Drawing.Point(176, 52);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(120, 40);
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Segoe UI", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(127, 0);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(296, 64);
            this.bunifuCustomLabel1.TabIndex = 1;
            this.bunifuCustomLabel1.Text = "BARCODE GENERATE";
            this.bunifuCustomLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlReport
            // 
            this.pnlReport.Controls.Add(this.tableLayoutPanel4);
            this.pnlReport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlReport.Location = new System.Drawing.Point(0, 0);
            this.pnlReport.Name = "pnlReport";
            this.pnlReport.Size = new System.Drawing.Size(550, 450);
            this.pnlReport.TabIndex = 14;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 3;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel4.Controls.Add(this.bunifuCustomLabel2, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.reportViewer1, 1, 1);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 3;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(550, 450);
            this.tableLayoutPanel4.TabIndex = 12;
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Segoe UI", 22F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(127, 0);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(296, 67);
            this.bunifuCustomLabel2.TabIndex = 2;
            this.bunifuCustomLabel2.Text = "BARCODE GENERATE";
            this.bunifuCustomLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.reportViewer1.DocumentMapWidth = 33;
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = null;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "ERP.Reports.Report1.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(58, 70);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.ServerReport.BearerToken = null;
            this.reportViewer1.Size = new System.Drawing.Size(434, 331);
            this.reportViewer1.TabIndex = 3;
            // 
            // appData1
            // 
            this.appData1.DataSetName = "AppData";
            this.appData1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // AppData
            // 
            this.AppData.DataSetName = "AppData";
            this.AppData.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // frmAddStocks
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.ClientSize = new System.Drawing.Size(550, 450);
            this.Controls.Add(this.tblPnlStocks);
            this.Controls.Add(this.tblPnlBarcodeGenerate);
            this.Controls.Add(this.pnlReport);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmAddStocks";
            this.Text = "frmAddStocks";
            this.tblPnlStocks.ResumeLayout(false);
            this.tblPnlStocks.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.pnlAddStockInfo.ResumeLayout(false);
            this.pnlAddStockInfo.PerformLayout();
            this.pnlAddStockTools.ResumeLayout(false);
            this.tblPnlBarcodeGenerate.ResumeLayout(false);
            this.tblPnlBarcodeGenerate.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.pnlBarcode.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnlReport.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.appData1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BarcodeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.AppData)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tblPnlStocks;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.ComboBox cmbProductCtg;
        private System.Windows.Forms.ComboBox cmbProductName;
        private System.Windows.Forms.ComboBox cmbProductSize;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Panel pnlAddStockInfo;
        private Bunifu.Framework.BunifuCustomTextbox txtLSalePrice;
        private Bunifu.Framework.BunifuCustomTextbox txtLPPrice;
        private Bunifu.Framework.BunifuCustomTextbox txtLQun;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel5;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel6;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel4;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel3;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel2;
        private Bunifu.Framework.BunifuCustomTextbox txtCurentStock;
        private Bunifu.Framework.BunifuCustomTextbox txtLDate;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel1;
        private System.Windows.Forms.Panel pnlAddStockTools;
        private Bunifu.Framework.UI.BunifuThinButton2 btnClear;
        private Bunifu.Framework.UI.BunifuThinButton2 btnAddStock;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtQuantity;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtSalePrice;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtBuyingPrice;
        private Bunifu.Framework.UI.BunifuCustomLabel lblTitle;
        private System.Windows.Forms.TableLayoutPanel tblPnlBarcodeGenerate;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Panel panel4;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel7;
        private Bunifu.Framework.BunifuCustomTextbox txtBarcodeQuantity;
        private Bunifu.Framework.UI.BunifuThinButton2 btnGenerate;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.Panel pnlBarcode;
        private Bunifu.Framework.UI.BunifuThinButton2 btnBarcodePrint;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private System.Windows.Forms.Panel pnlReport;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.TextBox txtCtgProductBarcode;
        private System.Windows.Forms.TextBox txtNameProductBarcode;
        private System.Windows.Forms.TextBox txtSizeProductBarcode;
        private AppData appData1;
        private System.Windows.Forms.BindingSource BarcodeBindingSource;
        private AppData AppData;
    }
}