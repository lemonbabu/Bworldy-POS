﻿
namespace ERP
{
    partial class frmDuePayment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDuePayment));
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties1 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties2 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties3 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties4 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties5 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties6 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties7 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties stateProperties8 = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges1 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges2 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.StateProperties();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lblTitle = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtCstPhone = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.txtCstName = new Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox();
            this.btnSearch = new Bunifu.Framework.UI.BunifuFlatButton();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.pnlDuePay = new System.Windows.Forms.Panel();
            this.btnReset = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.txtDuePay = new System.Windows.Forms.TextBox();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.btnDueSubmit = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.txtDue = new System.Windows.Forms.TextBox();
            this.bunifuCustomLabel12 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtPayment = new System.Windows.Forms.TextBox();
            this.bunifuCustomLabel14 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtDiscount = new System.Windows.Forms.TextBox();
            this.bunifuCustomLabel11 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.txtTotalAmount = new System.Windows.Forms.TextBox();
            this.bunifuCustomLabel13 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.pnlGridView = new System.Windows.Forms.Panel();
            this.dataGridViewDuePayment = new Bunifu.UI.WinForms.BunifuDataGridView();
            this.saleIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cstIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cstNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cstPhoneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalAmntDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.discountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.overallDiscount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paidAmntDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dueAmntDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Pay = new System.Windows.Forms.DataGridViewButtonColumn();
            this.tblDuePaymentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.appData = new ERP.AppData();
            this.tblDuePaymentTableAdapter = new ERP.AppDataTableAdapters.tblDuePaymentTableAdapter();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.pnlDuePay.SuspendLayout();
            this.pnlGridView.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDuePayment)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblDuePaymentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.appData)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 90F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.Controls.Add(this.lblTitle, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 1, 2);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(550, 450);
            this.tableLayoutPanel1.TabIndex = 3;
            // 
            // lblTitle
            // 
            this.lblTitle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 22F);
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(168, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(212, 60);
            this.lblTitle.TabIndex = 2;
            this.lblTitle.Text = "DUE PAYMENT";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtCstPhone);
            this.panel1.Controls.Add(this.txtCstName);
            this.panel1.Controls.Add(this.btnSearch);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(30, 63);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(489, 39);
            this.panel1.TabIndex = 3;
            // 
            // txtCstPhone
            // 
            this.txtCstPhone.AcceptsReturn = false;
            this.txtCstPhone.AcceptsTab = false;
            this.txtCstPhone.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtCstPhone.AnimationSpeed = 200;
            this.txtCstPhone.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtCstPhone.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtCstPhone.BackColor = System.Drawing.Color.Transparent;
            this.txtCstPhone.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtCstPhone.BackgroundImage")));
            this.txtCstPhone.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtCstPhone.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.txtCstPhone.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtCstPhone.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtCstPhone.BorderRadius = 1;
            this.txtCstPhone.BorderThickness = 1;
            this.txtCstPhone.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtCstPhone.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCstPhone.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.txtCstPhone.DefaultText = "";
            this.txtCstPhone.FillColor = System.Drawing.Color.White;
            this.txtCstPhone.HideSelection = true;
            this.txtCstPhone.IconLeft = null;
            this.txtCstPhone.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCstPhone.IconPadding = 10;
            this.txtCstPhone.IconRight = null;
            this.txtCstPhone.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCstPhone.Lines = new string[0];
            this.txtCstPhone.Location = new System.Drawing.Point(200, 0);
            this.txtCstPhone.MaxLength = 32767;
            this.txtCstPhone.MinimumSize = new System.Drawing.Size(100, 35);
            this.txtCstPhone.Modified = false;
            this.txtCstPhone.Multiline = false;
            this.txtCstPhone.Name = "txtCstPhone";
            stateProperties1.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties1.FillColor = System.Drawing.Color.Empty;
            stateProperties1.ForeColor = System.Drawing.Color.Empty;
            stateProperties1.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtCstPhone.OnActiveState = stateProperties1;
            stateProperties2.BorderColor = System.Drawing.Color.Empty;
            stateProperties2.FillColor = System.Drawing.Color.White;
            stateProperties2.ForeColor = System.Drawing.Color.Empty;
            stateProperties2.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtCstPhone.OnDisabledState = stateProperties2;
            stateProperties3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties3.FillColor = System.Drawing.Color.Empty;
            stateProperties3.ForeColor = System.Drawing.Color.Empty;
            stateProperties3.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtCstPhone.OnHoverState = stateProperties3;
            stateProperties4.BorderColor = System.Drawing.Color.Silver;
            stateProperties4.FillColor = System.Drawing.Color.White;
            stateProperties4.ForeColor = System.Drawing.Color.Empty;
            stateProperties4.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtCstPhone.OnIdleState = stateProperties4;
            this.txtCstPhone.PasswordChar = '\0';
            this.txtCstPhone.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtCstPhone.PlaceholderText = "Phone";
            this.txtCstPhone.ReadOnly = false;
            this.txtCstPhone.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCstPhone.SelectedText = "";
            this.txtCstPhone.SelectionLength = 0;
            this.txtCstPhone.SelectionStart = 0;
            this.txtCstPhone.ShortcutsEnabled = true;
            this.txtCstPhone.Size = new System.Drawing.Size(132, 35);
            this.txtCstPhone.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtCstPhone.TabIndex = 5;
            this.txtCstPhone.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCstPhone.TextMarginBottom = 0;
            this.txtCstPhone.TextMarginLeft = 5;
            this.txtCstPhone.TextMarginTop = 0;
            this.txtCstPhone.TextPlaceholder = "Phone";
            this.txtCstPhone.UseSystemPasswordChar = false;
            this.txtCstPhone.WordWrap = true;
            this.txtCstPhone.TextChanged += new System.EventHandler(this.txtCstPhone_TextChanged);
            this.txtCstPhone.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtCstPhone_KeyDown);
            // 
            // txtCstName
            // 
            this.txtCstName.AcceptsReturn = false;
            this.txtCstName.AcceptsTab = false;
            this.txtCstName.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.txtCstName.AnimationSpeed = 200;
            this.txtCstName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtCstName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtCstName.BackColor = System.Drawing.Color.Transparent;
            this.txtCstName.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtCstName.BackgroundImage")));
            this.txtCstName.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.txtCstName.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.txtCstName.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.txtCstName.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtCstName.BorderRadius = 1;
            this.txtCstName.BorderThickness = 1;
            this.txtCstName.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtCstName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCstName.DefaultFont = new System.Drawing.Font("Segoe UI Semibold", 9.75F);
            this.txtCstName.DefaultText = "";
            this.txtCstName.FillColor = System.Drawing.Color.White;
            this.txtCstName.HideSelection = true;
            this.txtCstName.IconLeft = null;
            this.txtCstName.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCstName.IconPadding = 10;
            this.txtCstName.IconRight = null;
            this.txtCstName.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCstName.Lines = new string[0];
            this.txtCstName.Location = new System.Drawing.Point(3, 0);
            this.txtCstName.MaxLength = 32767;
            this.txtCstName.MinimumSize = new System.Drawing.Size(100, 35);
            this.txtCstName.Modified = false;
            this.txtCstName.Multiline = false;
            this.txtCstName.Name = "txtCstName";
            stateProperties5.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties5.FillColor = System.Drawing.Color.Empty;
            stateProperties5.ForeColor = System.Drawing.Color.Empty;
            stateProperties5.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtCstName.OnActiveState = stateProperties5;
            stateProperties6.BorderColor = System.Drawing.Color.Empty;
            stateProperties6.FillColor = System.Drawing.Color.White;
            stateProperties6.ForeColor = System.Drawing.Color.Empty;
            stateProperties6.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtCstName.OnDisabledState = stateProperties6;
            stateProperties7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties7.FillColor = System.Drawing.Color.Empty;
            stateProperties7.ForeColor = System.Drawing.Color.Empty;
            stateProperties7.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtCstName.OnHoverState = stateProperties7;
            stateProperties8.BorderColor = System.Drawing.Color.Silver;
            stateProperties8.FillColor = System.Drawing.Color.White;
            stateProperties8.ForeColor = System.Drawing.Color.Empty;
            stateProperties8.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtCstName.OnIdleState = stateProperties8;
            this.txtCstName.PasswordChar = '\0';
            this.txtCstName.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.txtCstName.PlaceholderText = "Customer Name";
            this.txtCstName.ReadOnly = false;
            this.txtCstName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCstName.SelectedText = "";
            this.txtCstName.SelectionLength = 0;
            this.txtCstName.SelectionStart = 0;
            this.txtCstName.ShortcutsEnabled = true;
            this.txtCstName.Size = new System.Drawing.Size(176, 35);
            this.txtCstName.Style = Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox._Style.Bunifu;
            this.txtCstName.TabIndex = 2;
            this.txtCstName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtCstName.TextMarginBottom = 0;
            this.txtCstName.TextMarginLeft = 5;
            this.txtCstName.TextMarginTop = 0;
            this.txtCstName.TextPlaceholder = "Customer Name";
            this.txtCstName.UseSystemPasswordChar = false;
            this.txtCstName.WordWrap = true;
            this.txtCstName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtCstName_KeyDown);
            // 
            // btnSearch
            // 
            this.btnSearch.Active = false;
            this.btnSearch.Activecolor = System.Drawing.Color.RoyalBlue;
            this.btnSearch.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.btnSearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnSearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSearch.BorderRadius = 0;
            this.btnSearch.ButtonText = "Search";
            this.btnSearch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSearch.DisabledColor = System.Drawing.Color.Gray;
            this.btnSearch.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.btnSearch.Iconcolor = System.Drawing.Color.Transparent;
            this.btnSearch.Iconimage = global::ERP.Properties.Resources.search_25px;
            this.btnSearch.Iconimage_right = null;
            this.btnSearch.Iconimage_right_Selected = null;
            this.btnSearch.Iconimage_Selected = null;
            this.btnSearch.IconMarginLeft = 0;
            this.btnSearch.IconMarginRight = 0;
            this.btnSearch.IconRightVisible = true;
            this.btnSearch.IconRightZoom = 0D;
            this.btnSearch.IconVisible = true;
            this.btnSearch.IconZoom = 55D;
            this.btnSearch.IsTab = false;
            this.btnSearch.Location = new System.Drawing.Point(353, -4);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnSearch.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnSearch.OnHoverTextColor = System.Drawing.Color.White;
            this.btnSearch.selected = false;
            this.btnSearch.Size = new System.Drawing.Size(102, 39);
            this.btnSearch.TabIndex = 4;
            this.btnSearch.Text = "Search";
            this.btnSearch.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSearch.Textcolor = System.Drawing.Color.White;
            this.btnSearch.TextFont = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.tableLayoutPanel2.Controls.Add(this.pnlDuePay, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.pnlGridView, 1, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(30, 108);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(489, 318);
            this.tableLayoutPanel2.TabIndex = 4;
            // 
            // pnlDuePay
            // 
            this.pnlDuePay.Controls.Add(this.btnReset);
            this.pnlDuePay.Controls.Add(this.txtDuePay);
            this.pnlDuePay.Controls.Add(this.bunifuCustomLabel1);
            this.pnlDuePay.Controls.Add(this.btnDueSubmit);
            this.pnlDuePay.Controls.Add(this.txtDue);
            this.pnlDuePay.Controls.Add(this.bunifuCustomLabel12);
            this.pnlDuePay.Controls.Add(this.txtPayment);
            this.pnlDuePay.Controls.Add(this.bunifuCustomLabel14);
            this.pnlDuePay.Controls.Add(this.txtDiscount);
            this.pnlDuePay.Controls.Add(this.bunifuCustomLabel11);
            this.pnlDuePay.Controls.Add(this.txtTotalAmount);
            this.pnlDuePay.Controls.Add(this.bunifuCustomLabel13);
            this.pnlDuePay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlDuePay.Location = new System.Drawing.Point(3, 3);
            this.pnlDuePay.Name = "pnlDuePay";
            this.pnlDuePay.Size = new System.Drawing.Size(189, 312);
            this.pnlDuePay.TabIndex = 2;
            // 
            // btnReset
            // 
            this.btnReset.AllowToggling = false;
            this.btnReset.AnimationSpeed = 200;
            this.btnReset.AutoGenerateColors = false;
            this.btnReset.BackColor = System.Drawing.Color.Transparent;
            this.btnReset.BackColor1 = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(0)))), ((int)(((byte)(10)))));
            this.btnReset.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnReset.BackgroundImage")));
            this.btnReset.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnReset.ButtonText = "Reset";
            this.btnReset.ButtonTextMarginLeft = 0;
            this.btnReset.ColorContrastOnClick = 45;
            this.btnReset.ColorContrastOnHover = 45;
            this.btnReset.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges1.BottomLeft = true;
            borderEdges1.BottomRight = true;
            borderEdges1.TopLeft = true;
            borderEdges1.TopRight = true;
            this.btnReset.CustomizableEdges = borderEdges1;
            this.btnReset.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnReset.DisabledBorderColor = System.Drawing.Color.Empty;
            this.btnReset.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnReset.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnReset.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnReset.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.btnReset.ForeColor = System.Drawing.Color.White;
            this.btnReset.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.btnReset.IconMarginLeft = 0;
            this.btnReset.IconPadding = 0;
            this.btnReset.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.btnReset.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.btnReset.IdleBorderRadius = 3;
            this.btnReset.IdleBorderThickness = 1;
            this.btnReset.IdleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(0)))), ((int)(((byte)(10)))));
            this.btnReset.IdleIconLeftImage = null;
            this.btnReset.IdleIconRightImage = null;
            this.btnReset.IndicateFocus = false;
            this.btnReset.Location = new System.Drawing.Point(8, 248);
            this.btnReset.Name = "btnReset";
            stateProperties9.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties9.BorderRadius = 3;
            stateProperties9.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties9.BorderThickness = 1;
            stateProperties9.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties9.ForeColor = System.Drawing.Color.White;
            stateProperties9.IconLeftImage = null;
            stateProperties9.IconRightImage = null;
            this.btnReset.onHoverState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties10.BorderRadius = 3;
            stateProperties10.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties10.BorderThickness = 1;
            stateProperties10.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties10.ForeColor = System.Drawing.Color.White;
            stateProperties10.IconLeftImage = null;
            stateProperties10.IconRightImage = null;
            this.btnReset.OnPressedState = stateProperties10;
            this.btnReset.Size = new System.Drawing.Size(75, 40);
            this.btnReset.TabIndex = 22;
            this.btnReset.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnReset.TextMarginLeft = 0;
            this.btnReset.UseDefaultRadiusAndThickness = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // txtDuePay
            // 
            this.txtDuePay.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDuePay.ForeColor = System.Drawing.Color.Black;
            this.txtDuePay.Location = new System.Drawing.Point(112, 199);
            this.txtDuePay.Name = "txtDuePay";
            this.txtDuePay.Size = new System.Drawing.Size(65, 25);
            this.txtDuePay.TabIndex = 21;
            this.txtDuePay.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtDuePay.TextChanged += new System.EventHandler(this.txtDuePay_TextChanged);
            this.txtDuePay.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtDuePay_KeyDown);
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(3, 202);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(99, 19);
            this.bunifuCustomLabel1.TabIndex = 20;
            this.bunifuCustomLabel1.Text = "Due Payment :";
            this.bunifuCustomLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnDueSubmit
            // 
            this.btnDueSubmit.AllowToggling = false;
            this.btnDueSubmit.AnimationSpeed = 200;
            this.btnDueSubmit.AutoGenerateColors = false;
            this.btnDueSubmit.BackColor = System.Drawing.Color.Transparent;
            this.btnDueSubmit.BackColor1 = System.Drawing.Color.DodgerBlue;
            this.btnDueSubmit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnDueSubmit.BackgroundImage")));
            this.btnDueSubmit.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnDueSubmit.ButtonText = "Confirm";
            this.btnDueSubmit.ButtonTextMarginLeft = 0;
            this.btnDueSubmit.ColorContrastOnClick = 45;
            this.btnDueSubmit.ColorContrastOnHover = 45;
            this.btnDueSubmit.Cursor = System.Windows.Forms.Cursors.Hand;
            borderEdges2.BottomLeft = true;
            borderEdges2.BottomRight = true;
            borderEdges2.TopLeft = true;
            borderEdges2.TopRight = true;
            this.btnDueSubmit.CustomizableEdges = borderEdges2;
            this.btnDueSubmit.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnDueSubmit.DisabledBorderColor = System.Drawing.Color.Empty;
            this.btnDueSubmit.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnDueSubmit.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnDueSubmit.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnDueSubmit.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold);
            this.btnDueSubmit.ForeColor = System.Drawing.Color.White;
            this.btnDueSubmit.IconLeftCursor = System.Windows.Forms.Cursors.Hand;
            this.btnDueSubmit.IconMarginLeft = 0;
            this.btnDueSubmit.IconPadding = 0;
            this.btnDueSubmit.IconRightCursor = System.Windows.Forms.Cursors.Hand;
            this.btnDueSubmit.IdleBorderColor = System.Drawing.Color.DodgerBlue;
            this.btnDueSubmit.IdleBorderRadius = 3;
            this.btnDueSubmit.IdleBorderThickness = 1;
            this.btnDueSubmit.IdleFillColor = System.Drawing.Color.DodgerBlue;
            this.btnDueSubmit.IdleIconLeftImage = null;
            this.btnDueSubmit.IdleIconRightImage = null;
            this.btnDueSubmit.IndicateFocus = false;
            this.btnDueSubmit.Location = new System.Drawing.Point(92, 248);
            this.btnDueSubmit.Name = "btnDueSubmit";
            stateProperties11.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties11.BorderRadius = 3;
            stateProperties11.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties11.BorderThickness = 1;
            stateProperties11.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties11.ForeColor = System.Drawing.Color.White;
            stateProperties11.IconLeftImage = null;
            stateProperties11.IconRightImage = null;
            this.btnDueSubmit.onHoverState = stateProperties11;
            stateProperties12.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties12.BorderRadius = 3;
            stateProperties12.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            stateProperties12.BorderThickness = 1;
            stateProperties12.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            stateProperties12.ForeColor = System.Drawing.Color.White;
            stateProperties12.IconLeftImage = null;
            stateProperties12.IconRightImage = null;
            this.btnDueSubmit.OnPressedState = stateProperties12;
            this.btnDueSubmit.Size = new System.Drawing.Size(89, 40);
            this.btnDueSubmit.TabIndex = 19;
            this.btnDueSubmit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDueSubmit.TextMarginLeft = 0;
            this.btnDueSubmit.UseDefaultRadiusAndThickness = true;
            this.btnDueSubmit.Click += new System.EventHandler(this.btnDueSubmit_Click);
            // 
            // txtDue
            // 
            this.txtDue.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.txtDue.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDue.ForeColor = System.Drawing.Color.White;
            this.txtDue.Location = new System.Drawing.Point(111, 141);
            this.txtDue.Name = "txtDue";
            this.txtDue.ReadOnly = true;
            this.txtDue.Size = new System.Drawing.Size(65, 25);
            this.txtDue.TabIndex = 18;
            this.txtDue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bunifuCustomLabel12
            // 
            this.bunifuCustomLabel12.AutoSize = true;
            this.bunifuCustomLabel12.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel12.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel12.Location = new System.Drawing.Point(60, 141);
            this.bunifuCustomLabel12.Name = "bunifuCustomLabel12";
            this.bunifuCustomLabel12.Size = new System.Drawing.Size(41, 19);
            this.bunifuCustomLabel12.TabIndex = 16;
            this.bunifuCustomLabel12.Text = "Due :";
            this.bunifuCustomLabel12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtPayment
            // 
            this.txtPayment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.txtPayment.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPayment.ForeColor = System.Drawing.Color.White;
            this.txtPayment.Location = new System.Drawing.Point(111, 103);
            this.txtPayment.Name = "txtPayment";
            this.txtPayment.ReadOnly = true;
            this.txtPayment.Size = new System.Drawing.Size(65, 25);
            this.txtPayment.TabIndex = 11;
            this.txtPayment.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bunifuCustomLabel14
            // 
            this.bunifuCustomLabel14.AutoSize = true;
            this.bunifuCustomLabel14.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel14.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel14.Location = new System.Drawing.Point(31, 104);
            this.bunifuCustomLabel14.Name = "bunifuCustomLabel14";
            this.bunifuCustomLabel14.Size = new System.Drawing.Size(70, 19);
            this.bunifuCustomLabel14.TabIndex = 15;
            this.bunifuCustomLabel14.Text = "Payment :";
            this.bunifuCustomLabel14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtDiscount
            // 
            this.txtDiscount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.txtDiscount.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiscount.ForeColor = System.Drawing.Color.White;
            this.txtDiscount.Location = new System.Drawing.Point(111, 65);
            this.txtDiscount.Name = "txtDiscount";
            this.txtDiscount.ReadOnly = true;
            this.txtDiscount.Size = new System.Drawing.Size(65, 25);
            this.txtDiscount.TabIndex = 14;
            this.txtDiscount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bunifuCustomLabel11
            // 
            this.bunifuCustomLabel11.AutoSize = true;
            this.bunifuCustomLabel11.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel11.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel11.Location = new System.Drawing.Point(31, 67);
            this.bunifuCustomLabel11.Name = "bunifuCustomLabel11";
            this.bunifuCustomLabel11.Size = new System.Drawing.Size(70, 19);
            this.bunifuCustomLabel11.TabIndex = 13;
            this.bunifuCustomLabel11.Text = "Discount :";
            this.bunifuCustomLabel11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtTotalAmount
            // 
            this.txtTotalAmount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(49)))), ((int)(((byte)(49)))), ((int)(((byte)(49)))));
            this.txtTotalAmount.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalAmount.ForeColor = System.Drawing.Color.White;
            this.txtTotalAmount.Location = new System.Drawing.Point(111, 27);
            this.txtTotalAmount.Name = "txtTotalAmount";
            this.txtTotalAmount.ReadOnly = true;
            this.txtTotalAmount.Size = new System.Drawing.Size(65, 25);
            this.txtTotalAmount.TabIndex = 17;
            this.txtTotalAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // bunifuCustomLabel13
            // 
            this.bunifuCustomLabel13.AutoSize = true;
            this.bunifuCustomLabel13.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel13.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel13.Location = new System.Drawing.Point(56, 30);
            this.bunifuCustomLabel13.Name = "bunifuCustomLabel13";
            this.bunifuCustomLabel13.Size = new System.Drawing.Size(45, 19);
            this.bunifuCustomLabel13.TabIndex = 12;
            this.bunifuCustomLabel13.Text = "Total :";
            this.bunifuCustomLabel13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlGridView
            // 
            this.pnlGridView.Controls.Add(this.dataGridViewDuePayment);
            this.pnlGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlGridView.Location = new System.Drawing.Point(198, 3);
            this.pnlGridView.Name = "pnlGridView";
            this.pnlGridView.Size = new System.Drawing.Size(288, 312);
            this.pnlGridView.TabIndex = 1;
            // 
            // dataGridViewDuePayment
            // 
            this.dataGridViewDuePayment.AllowCustomTheming = true;
            this.dataGridViewDuePayment.AllowUserToAddRows = false;
            this.dataGridViewDuePayment.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(236)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewDuePayment.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewDuePayment.AutoGenerateColumns = false;
            this.dataGridViewDuePayment.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewDuePayment.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(18)))), ((int)(((byte)(18)))), ((int)(((byte)(18)))));
            this.dataGridViewDuePayment.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewDuePayment.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleHorizontal;
            this.dataGridViewDuePayment.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.MediumSeaGreen;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewDuePayment.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewDuePayment.ColumnHeadersHeight = 40;
            this.dataGridViewDuePayment.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.saleIdDataGridViewTextBoxColumn,
            this.cstIdDataGridViewTextBoxColumn,
            this.cstNameDataGridViewTextBoxColumn,
            this.cstPhoneDataGridViewTextBoxColumn,
            this.totalAmntDataGridViewTextBoxColumn,
            this.discountDataGridViewTextBoxColumn,
            this.overallDiscount,
            this.paidAmntDataGridViewTextBoxColumn,
            this.dueAmntDataGridViewTextBoxColumn,
            this.Pay});
            this.dataGridViewDuePayment.CurrentTheme.AlternatingRowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(206)))), ((int)(((byte)(236)))), ((int)(((byte)(219)))));
            this.dataGridViewDuePayment.CurrentTheme.AlternatingRowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.dataGridViewDuePayment.CurrentTheme.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewDuePayment.CurrentTheme.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(209)))), ((int)(((byte)(169)))));
            this.dataGridViewDuePayment.CurrentTheme.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridViewDuePayment.CurrentTheme.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.dataGridViewDuePayment.CurrentTheme.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(232)))), ((int)(((byte)(212)))));
            this.dataGridViewDuePayment.CurrentTheme.HeaderStyle.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.dataGridViewDuePayment.CurrentTheme.HeaderStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 10F);
            this.dataGridViewDuePayment.CurrentTheme.HeaderStyle.ForeColor = System.Drawing.Color.White;
            this.dataGridViewDuePayment.CurrentTheme.Name = null;
            this.dataGridViewDuePayment.CurrentTheme.RowsStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(226)))));
            this.dataGridViewDuePayment.CurrentTheme.RowsStyle.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            this.dataGridViewDuePayment.CurrentTheme.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewDuePayment.CurrentTheme.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(209)))), ((int)(((byte)(169)))));
            this.dataGridViewDuePayment.CurrentTheme.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridViewDuePayment.DataSource = this.tblDuePaymentBindingSource;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(216)))), ((int)(((byte)(239)))), ((int)(((byte)(226)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI Semibold", 8F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(209)))), ((int)(((byte)(169)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewDuePayment.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewDuePayment.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewDuePayment.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dataGridViewDuePayment.EnableHeadersVisualStyles = false;
            this.dataGridViewDuePayment.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(232)))), ((int)(((byte)(212)))));
            this.dataGridViewDuePayment.HeaderBackColor = System.Drawing.Color.MediumSeaGreen;
            this.dataGridViewDuePayment.HeaderBgColor = System.Drawing.Color.Empty;
            this.dataGridViewDuePayment.HeaderForeColor = System.Drawing.Color.White;
            this.dataGridViewDuePayment.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewDuePayment.Name = "dataGridViewDuePayment";
            this.dataGridViewDuePayment.ReadOnly = true;
            this.dataGridViewDuePayment.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dataGridViewDuePayment.RowHeadersVisible = false;
            this.dataGridViewDuePayment.RowTemplate.Height = 40;
            this.dataGridViewDuePayment.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewDuePayment.Size = new System.Drawing.Size(288, 312);
            this.dataGridViewDuePayment.TabIndex = 1;
            this.dataGridViewDuePayment.Theme = Bunifu.UI.WinForms.BunifuDataGridView.PresetThemes.MediumSeaGreen;
            this.dataGridViewDuePayment.VirtualMode = true;
            this.dataGridViewDuePayment.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewDuePayment_CellContentClick);
            // 
            // saleIdDataGridViewTextBoxColumn
            // 
            this.saleIdDataGridViewTextBoxColumn.DataPropertyName = "saleId";
            this.saleIdDataGridViewTextBoxColumn.FillWeight = 60F;
            this.saleIdDataGridViewTextBoxColumn.HeaderText = "Sale Id";
            this.saleIdDataGridViewTextBoxColumn.Name = "saleIdDataGridViewTextBoxColumn";
            this.saleIdDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // cstIdDataGridViewTextBoxColumn
            // 
            this.cstIdDataGridViewTextBoxColumn.DataPropertyName = "cstId";
            this.cstIdDataGridViewTextBoxColumn.HeaderText = "cstId";
            this.cstIdDataGridViewTextBoxColumn.Name = "cstIdDataGridViewTextBoxColumn";
            this.cstIdDataGridViewTextBoxColumn.ReadOnly = true;
            this.cstIdDataGridViewTextBoxColumn.Visible = false;
            // 
            // cstNameDataGridViewTextBoxColumn
            // 
            this.cstNameDataGridViewTextBoxColumn.DataPropertyName = "cstName";
            this.cstNameDataGridViewTextBoxColumn.HeaderText = "Name";
            this.cstNameDataGridViewTextBoxColumn.Name = "cstNameDataGridViewTextBoxColumn";
            this.cstNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // cstPhoneDataGridViewTextBoxColumn
            // 
            this.cstPhoneDataGridViewTextBoxColumn.DataPropertyName = "cstPhone";
            this.cstPhoneDataGridViewTextBoxColumn.FillWeight = 70F;
            this.cstPhoneDataGridViewTextBoxColumn.HeaderText = "Phone";
            this.cstPhoneDataGridViewTextBoxColumn.Name = "cstPhoneDataGridViewTextBoxColumn";
            this.cstPhoneDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // totalAmntDataGridViewTextBoxColumn
            // 
            this.totalAmntDataGridViewTextBoxColumn.DataPropertyName = "totalAmnt";
            this.totalAmntDataGridViewTextBoxColumn.FillWeight = 60F;
            this.totalAmntDataGridViewTextBoxColumn.HeaderText = "Total Amnt";
            this.totalAmntDataGridViewTextBoxColumn.Name = "totalAmntDataGridViewTextBoxColumn";
            this.totalAmntDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // discountDataGridViewTextBoxColumn
            // 
            this.discountDataGridViewTextBoxColumn.DataPropertyName = "discount";
            this.discountDataGridViewTextBoxColumn.FillWeight = 60F;
            this.discountDataGridViewTextBoxColumn.HeaderText = "Disc.";
            this.discountDataGridViewTextBoxColumn.Name = "discountDataGridViewTextBoxColumn";
            this.discountDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // overallDiscount
            // 
            this.overallDiscount.DataPropertyName = "overallDiscount";
            this.overallDiscount.HeaderText = "Ex. Disc.";
            this.overallDiscount.Name = "overallDiscount";
            this.overallDiscount.ReadOnly = true;
            this.overallDiscount.ToolTipText = "Extra discount";
            // 
            // paidAmntDataGridViewTextBoxColumn
            // 
            this.paidAmntDataGridViewTextBoxColumn.DataPropertyName = "paidAmnt";
            this.paidAmntDataGridViewTextBoxColumn.FillWeight = 60F;
            this.paidAmntDataGridViewTextBoxColumn.HeaderText = "Paid Amnt";
            this.paidAmntDataGridViewTextBoxColumn.Name = "paidAmntDataGridViewTextBoxColumn";
            this.paidAmntDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dueAmntDataGridViewTextBoxColumn
            // 
            this.dueAmntDataGridViewTextBoxColumn.DataPropertyName = "dueAmnt";
            this.dueAmntDataGridViewTextBoxColumn.FillWeight = 60F;
            this.dueAmntDataGridViewTextBoxColumn.HeaderText = "Due Amnt";
            this.dueAmntDataGridViewTextBoxColumn.Name = "dueAmntDataGridViewTextBoxColumn";
            this.dueAmntDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // Pay
            // 
            this.Pay.FillWeight = 50F;
            this.Pay.HeaderText = "Pay";
            this.Pay.Name = "Pay";
            this.Pay.ReadOnly = true;
            this.Pay.Text = "Pay";
            this.Pay.ToolTipText = "Show Payment Information";
            this.Pay.UseColumnTextForButtonValue = true;
            // 
            // tblDuePaymentBindingSource
            // 
            this.tblDuePaymentBindingSource.DataMember = "tblDuePayment";
            this.tblDuePaymentBindingSource.DataSource = this.appData;
            // 
            // appData
            // 
            this.appData.DataSetName = "AppData";
            this.appData.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblDuePaymentTableAdapter
            // 
            this.tblDuePaymentTableAdapter.ClearBeforeFill = true;
            // 
            // frmDuePayment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.ClientSize = new System.Drawing.Size(550, 450);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmDuePayment";
            this.Text = "frmDuePayment";
            this.Load += new System.EventHandler(this.frmDuePayment_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.pnlDuePay.ResumeLayout(false);
            this.pnlDuePay.PerformLayout();
            this.pnlGridView.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDuePayment)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblDuePaymentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.appData)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private Bunifu.Framework.UI.BunifuCustomLabel lblTitle;
        private System.Windows.Forms.Panel panel1;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtCstPhone;
        private Bunifu.UI.WinForms.BunifuTextbox.BunifuTextBox txtCstName;
        private Bunifu.Framework.UI.BunifuFlatButton btnSearch;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Panel pnlDuePay;
        private System.Windows.Forms.Panel pnlGridView;
        private Bunifu.UI.WinForms.BunifuDataGridView dataGridViewDuePayment;
        private System.Windows.Forms.TextBox txtDue;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel12;
        private System.Windows.Forms.TextBox txtPayment;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel14;
        private System.Windows.Forms.TextBox txtDiscount;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel11;
        private System.Windows.Forms.TextBox txtTotalAmount;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel13;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnReset;
        private System.Windows.Forms.TextBox txtDuePay;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnDueSubmit;
        private AppData appData;
        private System.Windows.Forms.BindingSource tblDuePaymentBindingSource;
        private AppDataTableAdapters.tblDuePaymentTableAdapter tblDuePaymentTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn saleIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cstIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cstNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cstPhoneDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalAmntDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn discountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn overallDiscount;
        private System.Windows.Forms.DataGridViewTextBoxColumn paidAmntDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dueAmntDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewButtonColumn Pay;
    }
}